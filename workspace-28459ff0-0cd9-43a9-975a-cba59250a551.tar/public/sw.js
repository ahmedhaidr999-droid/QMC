// Service Worker — إشعارات Push + تحديث فوري + كاش ذكي للأصول الثابتة فقط
const VERSION = "v1.0.1";
const SHELL_CACHE = `shell-${VERSION}`;
const ASSETS_CACHE = `assets-${VERSION}`;

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE).then((cache) => cache.addAll(["/icons/icon-192.png", "/icons/badge-72.png"]))
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      // تنظيف كاش النسخ القديمة
      const keys = await caches.keys();
      await Promise.all(
        keys.filter((k) => ![SHELL_CACHE, ASSETS_CACHE].includes(k)).map((k) => caches.delete(k))
      );
      await self.clients.claim();
    })()
  );
});

// استراتيجية الجلب:
// - الأصول الثابتة (_next/static, icons): شبكة أولاً مع كاش احتياطي (يضمن أحدث نسخة ويحافظ على العمل دون اتصال)
// - صفحات التنقل: شبكة أولاً مع صفحة عدم الاتصال
// - الـ API: شبكة فقط — لا نخزّن بيانات الحضور محلياً
self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (url.pathname.startsWith("/api/")) return; // شبكة فقط

  if (url.pathname.startsWith("/_next/static") || url.pathname.startsWith("/icons/")) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(ASSETS_CACHE);
        try {
          const res = await fetch(request);
          if (res.ok) cache.put(request, res.clone());
          return res;
        } catch {
          const hit = await cache.match(request);
          if (hit) return hit;
          throw new Error("offline");
        }
      })()
    );
    return;
  }

  if (request.mode === "navigate") {
    event.respondWith(
      (async () => {
        try {
          return await fetch(request);
        } catch {
          const cache = await caches.open(SHELL_CACHE);
          const fallback = await cache.match("/offline.html");
          return (
            fallback ||
            new Response(
              `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>لا يوجد اتصال</title><style>body{font-family:system-ui;display:flex;min-height:100vh;align-items:center;justify-content:center;background:#f8fafc;color:#0f172a}div{text-align:center;padding:2rem}h1{color:#16a34a}</style></head><body><div><h1>📴 لا يوجد اتصال</h1><p>تحقق من الاتصال بالإنترنت ثم أعد المحاولة</p></div></body></html>`,
              { headers: { "Content-Type": "text/html; charset=utf-8" } }
            )
          );
        }
      })()
    );
  }
});

// ===== إشعارات Push =====
self.addEventListener("push", (event) => {
  let d = {};
  try {
    d = event.data ? event.data.json() : {};
  } catch {
    d = { title: event.data?.text() ?? "تبليغ جديد" };
  }
  event.waitUntil(
    self.registration.showNotification(d.title || "📢 تبليغ جديد", {
      body: d.body || "",
      icon: "/icons/icon-192.png",
      badge: "/icons/badge-72.png",
      dir: "rtl",
      lang: "ar",
      tag: d.tag || "college",
      renotify: true,
      data: { url: d.url || "/" },
    })
  );
});

// فتح الإشعار → التركيز على النافذة أو فتح رابط جديد
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = event.notification.data?.url || "/";
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((list) => {
      for (const c of list) {
        if ("focus" in c) {
          c.navigate(url);
          return c.focus();
        }
      }
      return self.clients.openWindow(url);
    })
  );
});

// ===== التحديث الفوري =====
self.addEventListener("message", (event) => {
  if (event.data === "SKIP_WAITING") self.skipWaiting();
});
