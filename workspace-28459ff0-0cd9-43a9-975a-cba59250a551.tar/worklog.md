# سجل العمل المشترك — نظام إدارة الكلية

> **تعليمات لكل وكيل:** اقرأ هذا الملف قبل البدء، وعند الانتهاء أضف قسمك في الأسفل بالقالب المحدد.

---
Task ID: 1
Agent: الرئيسي (Z.ai Code)
Task: البنية الأساسية الكاملة — قاعدة البيانات، المصادقة، الصلاحيات، جميع مسارات API، الهيكل العام، الدخول، لوحة التحكم، PWA

Work Log:
- قراءة البرومبت من upload/college-management-prompt.md وتكييفه للبيئة (SQLite بدل PostgreSQL، مسار واحد / بدل مسارات متعددة — SPA بالموجّه #/hash)
- تثبيت: bcryptjs, qrcode, jsbarcode, jsqr, exceljs, web-push, jose + توليد مفاتيح VAPID في .env
- prisma/schema.prisma كامل: Role, Permission, RolePermission, UserPermissionOverride, AppSetting, User, Stage, Branch, StudentProfile, Subject, SubjectInstructor, Lecture, LectureFile, ClassSession, Attendance, Announcement, AnnouncementRead, PushSubscription, Notification, AuditLog (String بدل Enums وJson لأن SQLite)
- prisma/seed.ts: أدوار + صلاحيات (20) + مصفوفة DEFAULT_MATRIX + حسابات (owner/dean/inst1/inst2/student1-8) + مرحلتان + 3 فروع + 4 مواد + 6 محاضرات Markdown + جلسات وحضور وتبليغات — تشغيل: bun prisma/seed.ts
- scripts/gen-icons.ts: أيقونات PWA (192/512/maskable/badge/apple) في public/icons/
- src/lib/constants.ts: كل الثوابت والتسميات العربية + DEFAULT_MATRIX
- src/lib/auth.ts: جلسة JWT (jose) بكوكي HttpOnly + bcryptjs (تكلفة 12) + loadUser مع assignedSubjectIds
- src/lib/rbac.ts: getScope/can/hasAny/subjectWhere/sessionWhere + كاش 30 ثانية + invalidateRbacCache
- src/lib/api.ts: HttpError + handle + requireAuth + requirePermission + rateLimit + writeAudit + getClientIp
- src/lib/attendance/qr-token.ts: QR متغيّر TOTP-like (30 ث، HMAC-SHA256، timingSafeEqual، ±1 نافذة)
- src/lib/attendance/matrix.ts: buildMatrix (نِسَب، حرمان >25%)
- src/lib/excel/attendance.ts: تصدير xlsx RTL ملون + تحليل الاستيراد
- src/lib/push/server.ts: resolveAudience + createInAppNotifications + sendPushToUsers (web-push) + broadcastAnnouncement
- src/lib/date-fmt.ts: تواريخ بتوقيت آسيا/بغداد
- كل مسارات API (مختبرة بـ curl): auth (login/logout/me/change-password), stages, branches, subjects (+instructors عبر PATCH), lectures (+files upload/download في db/uploads خارج public), attendance/sessions (+open/close/scan/manual/undo), attendance/records/[id] PATCH (سبب إلزامي + تدقيق), my/qr, my/attendance, announcements (+[id]/read), notifications, push/subscribe, admin/users (+import Excel), admin/permissions (PUT بقيد OWNER فقط + منع سحب permissions.manage من المالك + إبطال كاش), admin/audit, reports/dashboard, reports/attendance, export/attendance (xlsx), import/attendance (preview بفروقات + apply)
- الواجهة: globals.css (أخضر/أزرق فاتح/أبيض، radius 14px، dark mode)، layout.tsx (Cairo، RTL، metadata، appleWebApp)، manifest.ts، public/sw.js (push + notificationclick + skipWaiting + كاش أصول فقط)، AppShell (سايدبار يمين حاسوب + BottomNav هاتف + هيدر متدرج)، NotificationBell (poll 30s)، PwaBits (شريط تحديث + تثبيت + دليل iOS)، LoginView (بطاقات حسابات تجريبية للدخول بنقرة)، ChangePasswordView، DashboardView (3 نسخ حسب الدور)، SettingsView، page.tsx (SPA router)
- Stubs جاهزة لكل الواجهات المفوّضة للوكلاء (named exports + نفس الـ props)

Stage Summary:
- كل الـ backend يعمل ومختبَر: دخول، RBAC (403 للطلاب على المسح والتعديل)، قيود المالك (400 عند سحب permissions.manage، 403 للعميد على تعديل المصفوفة)، QR متغيّر (صالح ±30ث، مرفوض بعد 90ث)، منع التكرار (duplicate:true)، تراجع، UID ثابت، تعديل بسبب إلزامي + تدقيق، تصدير xlsx (7.5KB)، استيراد بمعاينة فروقات ثم تطبيق
- حسابات: owner@college.edu/Owner@123 — dean/Dean@123 — inst1/Inst@123 — student1/StAdmin@123 — student2/Student@123
- dev server يعمل على 3000 (bun run dev)
- **المطلوب من الوكلاء: استبدال ملفات الـ stubs فقط بتنفيذ كامل وعدم تعديل أي ملف آخر إلا ما يُذكر في مهمتك**

---
Task ID: 2-c
Agent: announcements-views-builder
Task: واجهة التبليغات

Work Log:
- قراءة worklog.md و docs/api-contract.md + فحص مسارات API للتبليغات/المراحل/الفروع/المواد ومكونات ui-bits و ui الموجودة
- استبدال stub بتنفيذ كامل في src/components/app/views/announcements/AnnouncementsView.tsx فقط (بدون props)
- القائمة: useQuery على GET /api/announcements — بطاقة لكل تبليغ (عنوان bold + 📌 إن pinned + PriorityBadge + شارة «جديد» sky عند !isRead + نص line-clamp-3 قابل للتوسيع بالنقر + الناشر + fmtDateTime + جمهور عربي «الكل/مرحلة: X/فرع: X/مادة: X»)
- النقر على البطاقة يفتح Dialog بالنص الكامل ويستدعي POST /api/announcements/{id}/read مع تحسين isRead محلياً عبر setQueryData (بلا refetch)
- فلاتر: أزرار سريعة (الكل/غير المقروءة/المثبّتة مع الأعداد) + Select أولوية + EmptyState مخصص بزر إزالة التصفية
- إنشاء لمن يملك announcements.create: نموذج (عنوان/نص/أولوية RadioGroup/تثبيت Switch/جمهور RadioGroup) مع قوائم متتالية مرحلة←فرع←مادة (جلب عند الحاجة فقط + تصفير التبعيات)؛ نجاح: toast «تم النشر لـ {recipients} مستخدماً» + إبطال كاش؛ خطأ: e.message — ملاحظة داخل النموذج عن حدود جمهور التدريسي/الطالب المسؤول
- تعديل/حذف: قائمة DropdownMenu ثلاث نقاط تظهر فقط لصاحب التبليغ أو OWNER/DEAN مع hasScope المناسب؛ تعديل بنفس النموذج معبأ (PATCH — الجمهور للقراءة فقط)، حذف بتأكيد AlertDialog
- حالات: LoadingRows / EmptyState «لا توجد تبليغات بعد» / ErrorState مع onRetry — تجاوب من 360px وأهداف لمس ≥44px هاتفياً
- إصلاح react-hooks/set-state-in-effect: نقل النموذج لمكوّن AnnouncementForm يُركَّب عند فتح Dialog فقط (حالة ابتدائية من props بلا useEffect) — سجل عمل مفصل في agent-ctx/2-c-announcements-views-builder.md

Stage Summary:
- الملف يجتاز bunx eslint و tsc --noEmit بصفر أخطاء/تحذيرات، GET / = 200 وdev.log بلا أخطاء ترجمة
- تم التحقق فعلياً من أشكال الاستجابات بـ curl بكوكي دخول: إنشاء (recipients) → read → PATCH → DELETE تعمل بنفس payloads الواجهة، و403 «ليست لديك صلاحية» للتدريسي خارج نطاقه تُعرض عبر toast كما هي
- لم يُعدَّل أي ملف خارج AnnouncementsView.tsx (الأخطاء المتبقية في lint/tsc من ملفات وكلاء آخرين: PwaBits/StagesView/MyQrView/PermissionsView/AppShell/مسارات api قديمة)

---
Task ID: 2-b
Agent: attendance-views-builder
Task: واجهات الحضور والباركود
Work Log:
- قراءة worklog وapi-contract وفحص أشكال الاستجابات الفعلية بـ curl (sessions/session-detail/subjects/my-qr/my-attendance/reports/export/import)
- SessionsView: قائمة الجلسات (مادة/تاريخ fmtDate+fmtTime/قاعة/شارة حالة sky-emerald-muted/عدد المسجلين) + إنشاء بحوار كامل (مادة Select، تاريخ date، وقتا time، قاعة، lateAfterMin) لمن يملك attendance.session.manage + أزرار الماسح/فتح (toast بعدد الطلاب من res.count)/إغلاق حسب status + فلترة Select بالمادة + كل الحالات
- ScannerView: كاميرا environment عبر getUserMedia + حلقة rAF مع jsQR على canvas مخفي (تصغير 640px) وdebounce 1.5s مطلق بين الإرسالات — أصوات Web Audio (880Hz/150ms نجاح + vibrate(80)، منخفض مزدوج للمكرر، square للخطأ) — بطاقة نتيجة كبيرة (framer-motion) 3 ثوانٍ: اسم/رقم/حضور أخضر أو تأخير برتقالي، رمادية للمكرر، حمراء برسالة السيرفر — حقل USB مخفي inputMode=none مركّز دائماً (Enter يرسل ثم يفرغ) — تسجيل يدوي بحوار بحث محلي (الغائبون أولاً) — آخر الممسوحين مع تراجع (markedById هو المستخدم أو attendance.edit) — إحصاءات حاضر/متأخر/غائب/مجاز — إغلاق الجلسة بAlertDialog — رسالة لطيفة عند فشل الكاميرا — تنظيف كامل (stop tracks + cancel rAF + close AudioContext)
- ReportsView: Select مادة (الافتراضي ?subject= أو الأولى) + فلاتر من/إلى/بحث (useDeferredValue) + مصفوفة ملونة بالرموز + أعمدة نهائية (نسبة bold) + صفوف atRisk حمراء بأيقونة + تنبيه علوي بعدد المعرضين + تثبيت أول عمودين sticky + دليل رموز + تصدير window.open لمن يملك attendance.export + استيراد (ملف + سبب إلزامي + معاينة فروقات + أخطاء + تطبيق بAlertDialog) لمن يملك attendance.import
- MyQrView: QR متغيّر dataURL (280/420) + عدّاد دائري SVG مشتق من dataUpdatedAt يعيد الجلب عند الصفر (opacity transition أثناء التجديد) + تكبير بحوار أبيض + تلميح السطوع + قسم البطاقة المطبوعة (canvas Code128 height60 fontSize16 + QR ثابت + نافذة طباعة أنيقة RTL بdocument.write ثم print) + تنويه التجدد كل 30 ثانية
- MyAttendanceView: بطاقة لكل مادة (نسبة كبيرة ملونة أخضر/برتقالي/أحمر + شريط + 4 إحصاءات + شارة حرمان + جدول جلسات بmax-h وتمرير) + EmptyState
- إصلاح ملاحظة eslint الجديدة (react-hooks/set-state-in-effect) في MyQrView بجعل العدّاد مشتقاً من dataUpdatedAt بدل setState في effect — eslint لمجلد attendance صفر أخطاء
- اختبار شامل: curl لكل الـ endpoints (200) + دورة scan كاملة (نجاح/مكرر/تراجع) + استيراد preview بملف حقيقي + إنشاء جلسة، ثم فحص بالمتصفح الفعلي (agent-browser) لكل الصفحات الخمس بدون أي خطأ console

Stage Summary:
- الملفات الخمسة مكتملة ومختبرة فعلياً: GET / = 200 وdev.log نظيف بلا أخطاء ترجمة، وكل تدفقات الحضور (مسح/يدوي/تراجع/فتح/إغلاق/تصدير/استيراد/باركود/تقارير) تعمل من الواجهة
- تفصيل العمل موثق في agent-ctx/2-b-attendance-views-builder.md
---
Task ID: 2-a
Agent: academic-views-builder
Task: واجهات الهيكل الأكاديمي (المراحل/الفروع/المواد/صفحة المادة)
Work Log:
- قراءة worklog.md و docs/api-contract.md ثم فحص كل الـ endpoints المطلوبة بـ curl — اكتشاف 3 أخطاء 500 جاهزة تكسر متطلبات المهمة (رغم أنها خارج ملفاتي): GET /api/lectures (include لعلاقة createdBy غير موجودة على نموذج Lecture) وGET /api/subjects/{id} (_count على علاقة students غير موجودة) وGET /api/files/{id} (findUnique على حقل url غير فريد) — أُصلحت بإصلاحات جراحية دنيا موثقة أدناه مع الحفاظ على نفس عقود الاستجابة
- hotfix (3 أسطر تقريباً لكل ملف): lectures/route.ts يجلب أسماء المنشئين دفعة واحدة بuser.findMany + خريطة؛ lectures/[id]/route.ts يحذف include ويمرر اسم المنشئ للserialize بعد جلبه منفرداً؛ subjects/[id]/route.ts يحذف students:true من _count (studentsCount يُحسب أصلاً بسطر منفصل)؛ files/[id]/route.ts findFirst بدل findUnique — لم يتغير أي شكل استجابة
- تثبيت remark-gfm لدعم جداول Markdown (المطلوب في عرض المحاضرات)
- StagesView.tsx: وضعان — قائمة المراحل (بطاقات: اسم/رقم/فروع/طلاب → /stages/{id}) وصفحة مرحلة (فروعها → /branches/{id}) — Breadcrumb كامل قابل للنقر — CRUD كامل لمن يملك structure.manage: إضافة مرحلة (اسم + رقم Select 1-10)، تعديل/حذف بطاقة (AlertDialog برسالة خطأ السيرفر مثل «لا يمكن حذف مرحلة تضم طلاباً»)، إضافة فرع/تعديله/حذفه داخل صفحة المرحلة — Skeleton/EmptyState/ErrorState/Toast لكل عملية
- SubjectsView.tsx: مواد الفرع مع Breadcrumb (الرئيسية/المراحل/{المرحلة}/{الفرع}) + StatCards — بطاقات (code/الاسم/الفصل/أسماء التدريسيين/عدد المحاضرات والجلسات → /subjects/{id}) — CRUD لصاحب structure.manage + نافذة إسناد التدريسيين (checkbox من /api/admin/users?role=INSTRUCTOR مع بحث ثم PATCH instructorIds)
- SubjectView.tsx: رأس (اسم/رمز/فرع/مرحلة + badges التدريسيين + 4 StatCards) و3 تبويبات:
  • المحاضرات: قائمة مرتبة بالأسبوع (نوع badge نظري/عملي + الأسبوع + مسودة للمنشورة false + المنشئ والتاريخ + ملفات بروابط تنزيل وأحجام KB/MB + زر فيديو) — عارض Dialog شبه ملء الشاشة (max-w-3xl) بReactMarkdown+remarkGym مع تنسيق يدوي (جداول بحدود، pre بخلفية muted، قوائم ps-6) — إنشاء/تعديل بحوار فيه محرر Markdown (كتابة + معاينة حية بتبويب) + رفع ملفات multipart (file+lectureId) من داخل التعديل + مفتاح نشر Switch — حذف بتأكيد
  • جلسات الحضور: بطاقات (يوم/تاريخ/وقت/قاعة/حالة/مسجلون/دقائق التأخير) + إنشاء جلسة (date/time/time/قاعة/تأخير) لمن يملك attendance.session.manage + «فتح الماسح» → /scan/{id} (بتحقق attendance.scan) + «المصفوفة» → /reports?subject=
  • الطلاب: studentsCount + زر «عرض الطلاب» (users.manage) يفتح Dialog بقائمة طلاب الفرع (جلب من admin/users?role=STUDENT مع فلترة branchName + بحث محلي بالاسم/الرقم الجامعي)
- كل الأزرار الحساسة مقيدة بhasScope — كل النوافذ تُركَّب عند الفتح فقط (حالة ابتدائية من props) لتفادي react-hooks/set-state-in-effect
- اختبار شامل: curl لدورات CRUD كاملة (مرحلة/فرع/مادة/محاضرة/ملف/جلسة مع الحذف والتأكيدات) ثم agent-browser بجلسة معزولة: دخول owner → المراحل → مرحلة → فرع → مادة → التبويبات الثلاثة → إنشاء محاضرة بمحتوى Markdown (جداول/قوائم/أكواد) والمعاينة → رفع PDF فعلي (نجح، وملف txt مرفوض بنوع غير مدعوم كما يجب) → تنزيل 200 → حذف بتأكيد → إنشاء جلسة (تظهر مجدولة بمواعيدها) — لا أخطاء console
- lint: صفر أخطاء في ملفاتي الثلاثة (المتبقي PwaBits لوكيل آخر)، tsc --noEmit صفر أخطاء في ملفاتي — GET / = 200 وdev.log نظيف — حُذفت بيانات الاختبار (الجلسة والملف والمحاضرة) وأعيدت القاعدة لحالتها الأصلية

Stage Summary:
- الملفات الثلاثة (StagesView/SubjectsView/SubjectView) مكتملة الوظائف والصلاحيات والحالات ومختبرة فعلياً من الواجهة والمتصفح
- تنبيه للمنسق: أُجبرت على 4 إصلاحات hotfix خارج ملفاتي (src/app/api/lectures/route.ts و lectures/[id]/route.ts و subjects/[id]/route.ts و files/[id]/route.ts) لأن endpoints كانت ترجع 500 مخالفة لعقد الـ API الموثق — التعديلات دنيا ومحفوظة الأشكال، وأُوصى بمراجعتها في الدمج
- تفصيل موثق في agent-ctx/2-a-academic-views-builder.md

---
Task ID: 2-d
Agent: admin-views-builder (انتهت مهلته بعد كتابة الملفات — أكمل الرئيسي التحقق)
Task: واجهات الإدارة (المستخدمون/الصلاحيات/التدقيق)

Work Log:
- كُتب UsersView.tsx (868 سطر): جدول متجاوب + بحث debounce + فلترة دور + إنشاء/تعديل + إعادة تعيين كلمة مرور مع عرض tempPassword ونسخها + توليد باركود + تعطيل/حذف + إحصاءات
- كُتب PermissionsView.tsx (426 سطر): مصفوفة أدوار×صلاحيات مجمّعة بأقسام + Select نطاق لكل خلية + تتبع تعديلات بحدود amber + diff قبل الحفظ + إعادة الافتراضي + تعطيل خلية permissions.manage/OWNER
- كُتب AuditView.tsx (431 سطر): قائمة زمنية بأيقونات حسب النوع + Dialog تفاصيل قبل/بعد JSON منسق + فلترة بالفعل والفاعل
- تحقق الرئيسي: named exports مطابقة، لا بقايا stubs، الصفحة 200، lint نظيف

Stage Summary:
- كل الواجهات الإدارية الثلاث مكتملة وجاهزة للاختبار E2E

---
Task ID: 3-5
Agent: الرئيسي (Z.ai Code)
Task: التكامل النهائي + إصلاحات + اختبار E2E شامل + التوثيق

Work Log:
- إصلاح موجّه الـ hash: فصل الاستعلام (?subject=) عن مقاطع المسار + hashQuery()
- إصلاح sw.js: استراتيجية شبكة-أولاً للأصول بدل كاش-أولاً (كانت تعطّل تحديثات dev) + رفع الإصدار v1.0.1
- إصلاحات أنواع TypeScript شاملة: استيراد useState في AppShell، ReadableStream في files/[id]، UserFormDialog props اختيارية، DashboardView subjectId، excel cells، announcements resourceOf — tsc نظيف 100% لـ src/
- تحسين الجوال: زر "المزيد" يفتح Sheet بقائمة كل الصفحات (بدل الانتقال للإعدادات فقط)
- إضافة واجهة استيراد المستخدمين Excel كاملة في UsersView (قالب + معاينة بجدول ملون + تأكيد + تطبيق) — مختبرة E2E: استيراد سارة/محمود بنجاح ودخولهما بكلمة المرور المبدئية مع إجبار التغيير
- اختبار E2E شامل بـ agent-browser:
  * المالك: لوحة كاملة بالأرقام والحرمان، مراحل→فروع→مواد→محاضرات (Markdown+ملفات)، تقارير مصفوفة، تبليغات (نشر لـ12 مستخدماً)، مستخدمون، مصفوفة صلاحيات، تدقيق، إعدادات
  * التدريسي: لوحته، جلساته، فتح جلسة، الماسح (تسجيل يدوي + تراجع + إحصاءات)، رسالة الجلسة المغلقة
  * الطالب: لوحته، باركودي (QR يتجدد فعلياً بعد 30 ثانية — تحقق بمقارنة الصور، باركود Code128، بطاقة طباعة)، حضوري بنِسَب وتحذير حرمان
  * إجبار تغيير كلمة المرور: إعادة تعيين كمالك → دخول بكلمة مؤقتة → شاشة الإجبار → التغيير → الدخول
  * الجوال 375px: شريط سفلي 5 عناصر + قائمة كاملة + هيدر لاصق
- VLM تحقق بصري: لوحة المالك، المصفوفة، صفحة الصلاحيات، الجوال — منظم RTL بلا مشاكل جوهرية
- lint PASS نهائي + tsc نظيف + 0 أخطاء API
- كتابة README.md بالعربية + Dockerfile + .env.example

Stage Summary:
- النظام مكتمل ومختبَر: كل معايير القبول الرئيسية تحققت (صلاحيات 403/400، QR متجدد ±30ث، منع تكرار، سبب إلزامي، Excel RTL، استهداف جمهور، PWA)
- جاهز للمعاينة من لوحة المعاينة بحسابات البذرة
