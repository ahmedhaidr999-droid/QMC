# 🎓 نظام إدارة الكلية — Next.js 16 + PWA

نظام ويب احترافي متكامل لإدارة الكلية/الجامعة، يعمل على الحاسوب والهاتف كتطبيق **PWA قابل للتثبيت** (Android و iOS)، بواجهة **عربية RTL كاملة** وهوية بصرية (أخضر + أزرق فاتح + أبيض).

## ✨ الميزات

| المجال | التفاصيل |
|---|---|
| 🔐 المصادقة | دخول بجلسة JWT (كوكي HttpOnly) + bcrypt (تكلفة 12) + إجبار تغيير كلمة المرور عند أول دخول + حد محاولات (5/دقيقة) |
| 🛡️ صلاحيات ديناميكية | مصفوفة (دور × صلاحية × نطاق: NONE/OWN/ASSIGNED/BRANCH/STAGE/ALL) مخزنة في قاعدة البيانات — **المالك فقط** يعدّلها من واجهة مخصصة مع معاينة الفروقات، وقيد لا يُكسر (لا يُسحب `permissions.manage` من المالك) |
| 📷 حضور بالباركود | **QR متغيّر** لكل طالب يتجدد كل 30 ثانية (HMAC-SHA256 خوارزمية شبيهة بـ TOTP) + باركود Code128 ثابت للبطاقة المطبوعة + دعم قارئ USB + ماسح كاميرا بأصوات واهتزاز |
| 📊 تقارير الحضور | مصفوفة (طلاب × جلسات) بخلايا ملونة + نسب + تنبيه الحرمان (>25% غياب) + تصدير/استيراد Excel RTL ملون مع معاينة الفروقات قبل التطبيق |
| 🏫 هيكل أكاديمي | مرحلة ← فرع تدريسي ← مادة ← محاضرات (Markdown + ملفات + فيديو) مع إسناد التدريسيين |
| 📢 تبليغات | استهداف (الكل/مرحلة/فرع/مادة) + أولويات + تثبيت + **Web Push (VAPID)** + إشعارات داخل التطبيق بجرس وعدّاد |
| 📱 PWA | تثبيت على الهاتف + شريط تحديث فوري (skipWaiting) + دليل iOS + Service Worker (شبكة أولاً للأصول + صفحة عدم اتصال) |
| 🧾 سجل تدقيق | كل تعديل حساس (حضور/صلاحيات/مستخدمون) يُسجَّل بـ قبل/بعد + السبب + IP |

## 🏃 التشغيل (تطوير)

```bash
bun install          # تثبيت الحزم
bun run db:push      # إنشاء قاعدة البيانات SQLite (db/custom.db)
bun prisma/seed.ts   # البذرة: أدوار + صلاحيات + حسابات + بيانات تجريبية
bun run dev          # التشغيل على http://localhost:3000
```

## 👤 الحسابات التجريبية (من البذرة)

| الدور | البريد | كلمة المرور |
|---|---|---|
| مالك النظام | `owner@college.edu` | `Owner@123` |
| عميد الكلية | `dean@college.edu` | `Dean@123` |
| تدريسي | `inst1@college.edu` | `Inst@123` |
| طالب مسؤول | `student1@college.edu` | `StAdmin@123` |
| طالب | `student2@college.edu` | `Student@123` |

> ⚠️ غيّر كلمات المرور فور النشر الحقيقي (متغيرات البيئة في `.env`).

## 🔧 متغيرات البيئة (`.env`)

```env
DATABASE_URL=file:./db/custom.db
AUTH_SECRET=<سر عشوائي طويل>
OWNER_EMAIL=owner@college.edu
OWNER_PASSWORD=<غيّرها فوراً>
NEXT_PUBLIC_VAPID_PUBLIC_KEY=<npx web-push generate-vapid-keys>
VAPID_PRIVATE_KEY=...
VAPID_SUBJECT=mailto:admin@college.edu
APP_TIMEZONE=Asia/Baghdad
```

## 🗂️ البنية

```
prisma/            schema.prisma (SQLite) + seed.ts
src/lib/           auth (JWT) / rbac (can + نطاقات) / api (أخطاء + rate limit + تدقيق)
                   attendance/ (qr-token + matrix) / excel/ / push/ / constants (المصفوفة الافتراضية)
src/app/api/       ~30 مسار REST: auth, stages, branches, subjects, lectures, files,
                   attendance (sessions/open/close/scan/manual/undo/records), my/*,
                   announcements, notifications, push, admin (users+import, permissions, audit),
                   reports, export, import
src/app/page.tsx   تطبيق صفحة واحدة (SPA) — موجّه hash: #/dashboard، #/stages/<id>...
src/components/app/ AppShell (سايدبار + شريط سفلي + جرس) + views/ (واجهات كل مجال)
public/            sw.js (Push + تحديث فوري) + icons/
db/uploads/        ملفات المحاضرات (خارج public مع تحقق صلاحية عند التنزيل)
```

## 🧪 اختبار سريع للسيرفر

```bash
# دخول
curl -c c.txt -X POST localhost:3000/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"inst1@college.edu","password":"Inst@123"}'
# فتح جلسة ثم مسح باركود طالب ثابت
curl -b c.txt -X POST localhost:3000/api/attendance/sessions/<id>/open
curl -b c.txt -X POST localhost:3000/api/attendance/sessions/<id>/scan \
  -H "Content-Type: application/json" -d '{"action":"scan","payload":"UID:202512002"}'
```

## 🐳 الإنتاج (Docker)

```bash
docker build -t college-mgmt .
docker run -p 3000:3000 -v college-data:/app/db college-mgmt
```

> المنطق حساس للتوقيت: QR يقبل النافذة الحالية ±30 ثانية فقط، والسيرفر يخزّن UTC ويعرض بتوقيت `APP_TIMEZONE`.
