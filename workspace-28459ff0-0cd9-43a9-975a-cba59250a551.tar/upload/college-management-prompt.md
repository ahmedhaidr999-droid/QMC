# 🎓 برومبت بناء نظام إدارة كلية / جامعة (Next.js + PWA)

> **طريقة الاستخدام:** انسخ كل ما في هذا الملف وألصقه في أداة الذكاء الاصطناعي (Claude Code / Cursor / غيرها).
> اطلب منه التنفيذ **على مراحل** كما في القسم 15، وبعد كل مرحلة اكتب له: "أكمل المرحلة التالية".

---

## 1. الدور والهدف

أنت مهندس برمجيات Full‑Stack خبير (Next.js / TypeScript / PostgreSQL / PWA) ومصمم UI/UX محترف.
مهمتك: بناء **نظام ويب احترافي وحديث لإدارة كلية/جامعة** يعمل على الحاسوب والهاتف (Android و iOS) كتطبيق **PWA قابل للتثبيت**، ويمكن تحديثه في أي وقت بمجرد نشر نسخة جديدة دون المرور على المتاجر.

### قواعد صارمة للتنفيذ
1. اكتب **كوداً كاملاً جاهزاً للتشغيل**، ممنوع استخدام `// TODO` أو `...` أو "أكمل بنفسك".
2. استخدم **TypeScript بوضع strict** في كل المشروع.
3. اعرض كل ملف باسمه ومساره الكامل قبل كوده، مثال: `src/lib/rbac/can.ts`.
4. كل التحقق من الصلاحيات يتم **في السيرفر** (Route Handlers / Server Actions). إخفاء الأزرار في الواجهة للتجميل فقط وليس للحماية.
5. كل النصوص الظاهرة للمستخدم **بالعربية** مع دعم **RTL** كامل، والتعليقات في الكود بالعربية.
6. كل صفحة يجب أن تحتوي: حالة تحميل (Skeleton)، حالة فراغ (Empty State)، حالة خطأ، ورسائل نجاح/فشل (Toast).
7. لا تخترع مكتبات غير موجودة. استخدم المكتبات المذكورة في القسم 3 فقط ما لم تضطر، واذكر السبب إن أضفت غيرها.
8. بعد كل مرحلة اذكر: ما أُنجز، كيف أشغّله، وكيف أختبره.

---

## 2. وصف النظام (الفئات والميزات)

### الفئات (الأدوار)
| الدور | المفتاح | الوصف |
|---|---|---|
| مالك النظام | `OWNER` | صاحب المشروع. **الوحيد** الذي يعدّل مصفوفة الصلاحيات. |
| عميد الكلية | `DEAN` | إشراف كامل على الكلية، تعديل الحضور، إدارة المستخدمين والهيكل. |
| تدريسي | `INSTRUCTOR` | يدير مواده فقط: محاضرات، جلسات حضور، تبليغات، تقارير. |
| طالب مسؤول | `STUDENT_ADMIN` | طالب بصلاحيات إضافية: إضافة محاضرات ونشر تبليغات لمرحلته. |
| طالب | `STUDENT` | يتصفح محاضراته، يعرض باركوده، يرى حضوره وتبليغاته. |

### الميزات الأساسية
- تسجيل دخول آمن (لا يوجد تسجيل ذاتي؛ الحسابات يُنشئها OWNER/DEAN أو تُستورد من Excel).
- **صلاحيات ديناميكية** مخزنة في قاعدة البيانات وقابلة للتعديل من واجهة خاصة بالمالك فقط (القسم 7).
- **حضور بالباركود/QR**: لكل طالب باركود شخصي، يمسحه التدريسي بكاميرا الهاتف (القسم 8).
- **سجل حضور** لكل طالب في كل يوم مع التاريخ، مع إمكانية التعديل (للعميد/التدريسي) وتصدير/استيراد Excel (القسم 9).
- **هيكل أكاديمي**: المرحلة ← الفرع التدريسي ← المادة ← المحاضرات والشروحات (القسم 10).
- **تبليغات** مع إشعارات Push على الهاتف وطلب إذن الإشعارات (القسم 11).
- **PWA** يعمل على Android و iOS مع تحديث فوري (القسم 12).
- تصميم **Responsive** حديث بالألوان: **الأخضر + الأزرق الفاتح + الأبيض**.

---

## 3. التقنيات (Stack)

| الجانب | الاختيار |
|---|---|
| الإطار | Next.js 15 (App Router) + React 19 + TypeScript strict |
| التصميم | Tailwind CSS + shadcn/ui + lucide-react + framer-motion (خفيف) |
| الخطوط | `Cairo` أو `IBM Plex Sans Arabic` عبر `next/font/google` |
| قاعدة البيانات | PostgreSQL + Prisma ORM |
| المصادقة | Auth.js (NextAuth v5) بمزوّد Credentials + JWT + `argon2` (أو `bcryptjs`) |
| التحقق | Zod |
| الباركود/QR | `qrcode` (توليد QR)، `jsbarcode` (Code128 للبطاقة المطبوعة)، `@yudiel/react-qr-scanner` (مسح) |
| Excel | `exceljs` |
| الإشعارات | `web-push` (VAPID) + Service Worker |
| PWA | `app/manifest.ts` + Serwist (أو Service Worker يدوي) |
| الجداول والنماذج | TanStack Table + react-hook-form + zod resolver |
| الحالة/الجلب | Server Components + TanStack Query للتفاعلات |
| التواريخ | `date-fns` + `date-fns-tz` |
| الاختبارات | Vitest (منطق) + Playwright (مسارات رئيسية) |
| الحد من الطلبات | `@upstash/ratelimit` أو rate limiter بسيط في الذاكرة للتطوير |

متغيرات البيئة `.env.example`:
```env
DATABASE_URL=postgresql://user:pass@localhost:5432/college
AUTH_SECRET=غيّرها
OWNER_EMAIL=owner@college.edu
OWNER_PASSWORD=غيّرها-فوراً
NEXT_PUBLIC_VAPID_PUBLIC_KEY=
VAPID_PRIVATE_KEY=
VAPID_SUBJECT=mailto:admin@college.edu
APP_TIMEZONE=Asia/Baghdad   # غيّرها حسب بلدك
```

---

## 4. الهوية البصرية (Design System)

الألوان الأساسية: **أخضر**، **أزرق فاتح**، **أبيض**.

```css
/* src/app/globals.css */
:root {
  --primary: #16a34a;          /* أخضر رئيسي */
  --primary-dark: #15803d;
  --primary-soft: #dcfce7;
  --accent: #38bdf8;           /* أزرق فاتح */
  --accent-soft: #e0f2fe;
  --bg: #ffffff;
  --surface: #f8fafc;
  --border: #e2e8f0;
  --text: #0f172a;
  --muted: #64748b;
  --danger: #dc2626;
  --warning: #f59e0b;
  --radius: 14px;
}
```

إرشادات التصميم:
- `<html lang="ar" dir="rtl">` واستخدم **الخصائص المنطقية** في Tailwind (`ms-`, `me-`, `ps-`, `pe-`, `text-start`) بدل `left/right`.
- الشريط الجانبي (Sidebar) على الحاسوب، وشريط تنقل سفلي (Bottom Nav) على الهاتف.
- بطاقات بزوايا مدوّرة وظلال ناعمة، تدرّج خفيف من الأخضر إلى الأزرق الفاتح في الهيدر فقط.
- أيقونات حالة الحضور بالألوان: حاضر 🟢، غائب 🔴، متأخر 🟠، مجاز 🔵 — مع نص بجانب اللون (لا تعتمد على اللون وحده).
- أهداف لمس لا تقل عن 44px، وتباين ألوان يحقق WCAG AA، ودعم الوضع الداكن اختياري.
- لوحة تحكم (Dashboard) مختلفة لكل دور (القسم 13).

---

## 5. مصفوفة الصلاحيات الافتراضية (Permission Matrix)

النطاق (Scope) يحدد **على أي سجلات** تعمل الصلاحية:

| Scope | المعنى |
|---|---|
| `NONE` | لا يملكها |
| `OWN` | سجلاته التي أنشأها فقط |
| `ASSIGNED` | المواد المسندة إليه فقط |
| `BRANCH` | فرعه التدريسي فقط |
| `STAGE` | مرحلته فقط |
| `ALL` | الكل |

| الصلاحية (key) | OWNER | DEAN | INSTRUCTOR | STUDENT_ADMIN | STUDENT |
|---|---|---|---|---|---|
| `permissions.manage` | ALL | — | — | — | — |
| `users.manage` | ALL | ALL | — | — | — |
| `structure.manage` (مراحل/فروع/مواد) | ALL | ALL | — | — | — |
| `lectures.read` | ALL | ALL | ASSIGNED | STAGE | STAGE |
| `lectures.create` | ALL | ALL | ASSIGNED | STAGE | — |
| `lectures.update` | ALL | ALL | ASSIGNED | OWN | — |
| `lectures.delete` | ALL | ALL | ASSIGNED | OWN | — |
| `attendance.session.manage` | ALL | ALL | ASSIGNED | — | — |
| `attendance.scan` | ALL | ALL | ASSIGNED | — | — |
| `attendance.view` | ALL | ALL | ASSIGNED | — | OWN |
| `attendance.edit` | ALL | ALL | ASSIGNED | — | — |
| `attendance.export` | ALL | ALL | ASSIGNED | — | — |
| `attendance.import` | ALL | ALL | ASSIGNED | — | — |
| `announcements.read` | ALL | ALL | ALL | ALL | ALL |
| `announcements.create` | ALL | ALL | ASSIGNED | STAGE | — |
| `announcements.update` | ALL | ALL | OWN | OWN | — |
| `announcements.delete` | ALL | ALL | OWN | OWN | — |
| `reports.view` | ALL | ALL | ASSIGNED | — | — |
| `qr.own.view` | — | — | — | OWN | OWN |
| `audit.view` | ALL | ALL | — | — | — |

> هذه القيم **افتراضية فقط** (Seed). بعد التشغيل يعدّلها المالك من واجهة `/admin/permissions`.

---

## 6. قاعدة البيانات (Prisma Schema)

```prisma
generator client { provider = "prisma-client-js" }
datasource db { provider = "postgresql" url = env("DATABASE_URL") }

enum Scope            { NONE OWN ASSIGNED BRANCH STAGE ALL }
enum AttendanceStatus { PRESENT ABSENT LATE EXCUSED }
enum AttendanceMethod { QR_DYNAMIC QR_STATIC MANUAL EXCEL_IMPORT SYSTEM }
enum SessionStatus    { SCHEDULED OPEN CLOSED }
enum AudienceType     { ALL STAGE BRANCH SUBJECT }
enum Priority         { NORMAL IMPORTANT URGENT }
enum LectureType      { THEORY PRACTICAL }

model Role {
  id       String @id @default(cuid())
  key      String @unique            // OWNER | DEAN | INSTRUCTOR | STUDENT_ADMIN | STUDENT
  nameAr   String
  isSystem Boolean @default(true)
  users    User[]
  grants   RolePermission[]
}

model Permission {
  id        String @id @default(cuid())
  key       String @unique           // مثال: attendance.edit
  group     String
  nameAr    String
  roles     RolePermission[]
  overrides UserPermissionOverride[]
}

model RolePermission {
  roleId       String
  permissionId String
  scope        Scope @default(ALL)
  role         Role       @relation(fields: [roleId], references: [id], onDelete: Cascade)
  permission   Permission @relation(fields: [permissionId], references: [id], onDelete: Cascade)
  @@id([roleId, permissionId])
}

// للتطوير لاحقاً: صلاحية استثنائية لمستخدم واحد دون تغيير دوره
model UserPermissionOverride {
  userId       String
  permissionId String
  scope        Scope
  user         User       @relation(fields: [userId], references: [id], onDelete: Cascade)
  permission   Permission @relation(fields: [permissionId], references: [id], onDelete: Cascade)
  @@id([userId, permissionId])
}

model AppSetting {
  key       String   @id          // مثال: permissions.editableByRoles = ["OWNER"]
  value     Json
  updatedAt DateTime @updatedAt
}

model User {
  id                 String   @id @default(cuid())
  email              String   @unique
  universityId       String?  @unique       // الرقم الجامعي
  passwordHash       String
  mustChangePassword Boolean  @default(true)
  fullName           String
  phone              String?
  photoUrl           String?
  isActive           Boolean  @default(true)
  roleId             String
  role               Role     @relation(fields: [roleId], references: [id])
  qrSecret           String?                // سر QR المتغيّر للطالب
  studentProfile     StudentProfile?
  teaching           SubjectInstructor[]
  overrides          UserPermissionOverride[]
  pushSubs           PushSubscription[]
  notifications      Notification[]
  createdAt          DateTime @default(now())
}

model Stage {                               // المرحلة (الأولى، الثانية ...)
  id       String @id @default(cuid())
  nameAr   String
  level    Int    @unique
  branches Branch[]
  students StudentProfile[]
}

model Branch {                              // الفرع التدريسي
  id       String @id @default(cuid())
  stageId  String
  nameAr   String
  stage    Stage  @relation(fields: [stageId], references: [id], onDelete: Cascade)
  subjects Subject[]
  students StudentProfile[]
  @@unique([stageId, nameAr])
}

model StudentProfile {
  userId       String @id
  stageId      String
  branchId     String
  academicYear String                        // مثال: 2026-2027
  user   User   @relation(fields: [userId], references: [id], onDelete: Cascade)
  stage  Stage  @relation(fields: [stageId], references: [id])
  branch Branch @relation(fields: [branchId], references: [id])
  @@index([stageId, branchId])
}

model Subject {
  id        String @id @default(cuid())
  branchId  String
  code      String
  nameAr    String
  semester  Int    @default(1)
  branch    Branch @relation(fields: [branchId], references: [id], onDelete: Cascade)
  instructors SubjectInstructor[]
  lectures  Lecture[]
  sessions  ClassSession[]
  @@unique([branchId, code])
}

model SubjectInstructor {
  subjectId String
  userId    String
  subject   Subject @relation(fields: [subjectId], references: [id], onDelete: Cascade)
  user      User    @relation(fields: [userId], references: [id], onDelete: Cascade)
  @@id([subjectId, userId])
}

model Lecture {
  id          String @id @default(cuid())
  subjectId   String
  title       String
  summary     String?
  contentMd   String? @db.Text              // الشرح (Markdown)
  weekNo      Int?
  type        LectureType @default(THEORY)
  videoUrl    String?
  isPublished Boolean @default(true)
  createdById String
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  subject     Subject @relation(fields: [subjectId], references: [id], onDelete: Cascade)
  files       LectureFile[]
  @@index([subjectId, weekNo])
}

model LectureFile {
  id        String @id @default(cuid())
  lectureId String
  name      String
  url       String
  mime      String
  sizeBytes Int
  lecture   Lecture @relation(fields: [lectureId], references: [id], onDelete: Cascade)
}

model ClassSession {                          // جلسة محاضرة (يوم + وقت)
  id            String @id @default(cuid())
  subjectId     String
  date          DateTime @db.Date
  startsAt      DateTime
  endsAt        DateTime
  room          String?
  lateAfterMin  Int @default(15)              // بعدها يُسجَّل "متأخر"
  status        SessionStatus @default(SCHEDULED)
  createdById   String
  subject       Subject @relation(fields: [subjectId], references: [id], onDelete: Cascade)
  attendance    Attendance[]
  @@unique([subjectId, startsAt])
}

model Attendance {
  id          String @id @default(cuid())
  sessionId   String
  studentId   String
  status      AttendanceStatus @default(ABSENT)
  method      AttendanceMethod @default(SYSTEM)
  scannedAt   DateTime?
  markedById  String?
  editedById  String?
  editedAt    DateTime?
  note        String?
  session     ClassSession @relation(fields: [sessionId], references: [id], onDelete: Cascade)
  @@unique([sessionId, studentId])            // يمنع التكرار
  @@index([studentId])
}

model Announcement {
  id           String @id @default(cuid())
  title        String
  body         String @db.Text
  priority     Priority @default(NORMAL)
  audienceType AudienceType
  stageId      String?
  branchId     String?
  subjectId    String?
  pinned       Boolean @default(false)
  createdById  String
  publishedAt  DateTime @default(now())
  expiresAt    DateTime?
  reads        AnnouncementRead[]
  @@index([audienceType, stageId, branchId, subjectId])
}

model AnnouncementRead {
  announcementId String
  userId         String
  readAt         DateTime @default(now())
  announcement   Announcement @relation(fields: [announcementId], references: [id], onDelete: Cascade)
  @@id([announcementId, userId])
}

model PushSubscription {
  id        String @id @default(cuid())
  userId    String
  endpoint  String @unique
  p256dh    String
  auth      String
  userAgent String?
  createdAt DateTime @default(now())
  user      User @relation(fields: [userId], references: [id], onDelete: Cascade)
}

model Notification {                          // إشعار داخل التطبيق (احتياطي لـ Push)
  id     String @id @default(cuid())
  userId String
  title  String
  body   String
  url    String?
  readAt DateTime?
  createdAt DateTime @default(now())
  user   User @relation(fields: [userId], references: [id], onDelete: Cascade)
  @@index([userId, readAt])
}

model AuditLog {                              // سجل التدقيق لكل تعديل حساس
  id        String @id @default(cuid())
  actorId   String
  action    String                            // مثال: attendance.edit, permissions.update
  entity    String
  entityId  String?
  before    Json?
  after     Json?
  reason    String?
  ip        String?
  createdAt DateTime @default(now())
  @@index([entity, entityId])
}
```

---

## 7. نظام الصلاحيات (RBAC ديناميكي)

### المتطلبات
- الصلاحيات في قاعدة البيانات (`Role` × `Permission` × `Scope`) وليست ثابتة في الكود.
- **المالك فقط** يعدّل المصفوفة. القيد محفوظ في `AppSetting` بالمفتاح `permissions.editableByRoles` (القيمة الافتراضية `["OWNER"]`) حتى يمكن تغيير هذا الخيار مستقبلاً بالتطوير دون تعديل الكود.
- ثوابت لا يمكن كسرها: لا يُسحب `permissions.manage` من `OWNER`، ولا يمكن تعطيل آخر حساب OWNER.
- كل تعديل يُسجَّل في `AuditLog` ويُبطل الكاش (`revalidateTag("rbac")`).

### الكود الأساسي

```ts
// src/lib/rbac/can.ts
import { unstable_cache } from "next/cache";
import { prisma } from "@/lib/prisma";

export type Scope = "NONE" | "OWN" | "ASSIGNED" | "BRANCH" | "STAGE" | "ALL";

export type AuthUser = {
  id: string;
  roleId: string;
  roleKey: string;
  stageId?: string | null;
  branchId?: string | null;
  assignedSubjectIds: string[];            // من SubjectInstructor
};

// المورد الذي نتحقق منه (املأ فقط ما يلزم)
export type Resource = {
  ownerId?: string;
  subjectId?: string;
  branchId?: string;
  stageId?: string;
};

const loadGrants = unstable_cache(
  async (roleId: string) => {
    const rows = await prisma.rolePermission.findMany({
      where: { roleId },
      include: { permission: true },
    });
    return Object.fromEntries(rows.map((r) => [r.permission.key, r.scope])) as Record<string, Scope>;
  },
  ["rbac-grants"],
  { tags: ["rbac"] }
);

export async function getScope(user: AuthUser, key: string): Promise<Scope> {
  const [grants, override] = await Promise.all([
    loadGrants(user.roleId),
    prisma.userPermissionOverride.findFirst({ where: { userId: user.id, permission: { key } } }),
  ]);
  return override?.scope ?? grants[key] ?? "NONE";
}

export async function can(user: AuthUser, key: string, res: Resource = {}): Promise<boolean> {
  const scope = await getScope(user, key);
  switch (scope) {
    case "ALL":      return true;
    case "NONE":     return false;
    case "OWN":      return !!res.ownerId && res.ownerId === user.id;
    case "ASSIGNED": return !!res.subjectId && user.assignedSubjectIds.includes(res.subjectId);
    case "BRANCH":   return !!res.branchId && res.branchId === user.branchId;
    case "STAGE":    return !!res.stageId && res.stageId === user.stageId;
  }
}

// لعرض عنصر في القائمة: هل يملك الصلاحية بأي نطاق؟
export async function hasAny(user: AuthUser, key: string) {
  return (await getScope(user, key)) !== "NONE";
}

// لبناء فلتر Prisma عند جلب القوائم (يمنع تسريب بيانات خارج النطاق)
export async function subjectWhere(user: AuthUser, key: string) {
  const scope = await getScope(user, key);
  switch (scope) {
    case "ALL":      return {};
    case "ASSIGNED": return { id: { in: user.assignedSubjectIds } };
    case "BRANCH":   return { branchId: user.branchId ?? "__none__" };
    case "STAGE":    return { branch: { stageId: user.stageId ?? "__none__" } };
    default:         return { id: "__none__" };
  }
}
```

```ts
// src/lib/rbac/guard.ts
export class HttpError extends Error {
  constructor(public status: number, message?: string) { super(message); }
}

export async function requirePermission(key: string, res: Resource = {}) {
  const user = await getSessionUser();                 // من Auth.js
  if (!user) throw new HttpError(401, "غير مسجّل الدخول");
  if (!user.isActive) throw new HttpError(403, "الحساب معطّل");
  if (!(await can(user, key, res))) throw new HttpError(403, "ليست لديك صلاحية");
  return user;
}
```

```ts
// src/app/api/admin/permissions/route.ts  (تعديل المصفوفة: للمالك فقط)
const bodySchema = z.array(z.object({
  roleId: z.string(),
  permissionKey: z.string(),
  scope: z.enum(["NONE", "OWN", "ASSIGNED", "BRANCH", "STAGE", "ALL"]),
}));

export async function PUT(req: Request) {
  const actor = await requirePermission("permissions.manage");
  const setting = await prisma.appSetting.findUnique({ where: { key: "permissions.editableByRoles" } });
  const allowedRoles = (setting?.value as string[]) ?? ["OWNER"];
  if (!allowedRoles.includes(actor.roleKey)) throw new HttpError(403);

  const changes = bodySchema.parse(await req.json());

  // قيود لا تُكسر
  const ownerRole = await prisma.role.findUniqueOrThrow({ where: { key: "OWNER" } });
  if (changes.some(c => c.roleId === ownerRole.id && c.permissionKey === "permissions.manage" && c.scope !== "ALL"))
    throw new HttpError(400, "لا يمكن سحب صلاحية إدارة الصلاحيات من المالك");

  const before = await prisma.rolePermission.findMany({ include: { permission: true } });
  await prisma.$transaction([
    ...changes.map(c => prisma.rolePermission.upsert({
      where: { roleId_permissionId: { roleId: c.roleId, permissionId: /* id من key */ "" } },
      create: { roleId: c.roleId, permissionId: "", scope: c.scope },
      update: { scope: c.scope },
    })),
    prisma.auditLog.create({ data: { actorId: actor.id, action: "permissions.update", entity: "RolePermission", before: before as any, after: changes as any } }),
  ]);
  revalidateTag("rbac");
  return Response.json({ ok: true });
}
```
> (على الذكاء الاصطناعي: حلّ `permissionId` من `key` عبر استعلام مسبق، وأكمل الكود الكامل.)

### واجهة `/admin/permissions` (المالك فقط)
- جدول مصفوفة: **الصفوف = الصلاحيات (مجمّعة حسب group)**، **الأعمدة = الأدوار**.
- كل خلية قائمة منسدلة بالـ Scope (`—`, `OWN`, `ASSIGNED`, `BRANCH`, `STAGE`, `ALL`) بأسماء عربية.
- زر "حفظ" مع معاينة التغييرات (diff) وتأكيد قبل الحفظ، وزر "إعادة الافتراضي".
- تبويب ثانٍ: "صلاحيات استثنائية لمستخدم" (يستخدم `UserPermissionOverride`) — يمكن إخفاؤه خلف خيار في `AppSetting` ليُفعَّل لاحقاً.

### بذرة المصفوفة (Seed)
```ts
// prisma/seed/matrix.ts
export const DEFAULT_MATRIX: Record<string, Record<string, Scope>> = {
  OWNER: { /* كل الصلاحيات: ALL */ },
  DEAN: {
    "users.manage": "ALL", "structure.manage": "ALL",
    "lectures.read": "ALL", "lectures.create": "ALL", "lectures.update": "ALL", "lectures.delete": "ALL",
    "attendance.session.manage": "ALL", "attendance.scan": "ALL", "attendance.view": "ALL",
    "attendance.edit": "ALL", "attendance.export": "ALL", "attendance.import": "ALL",
    "announcements.read": "ALL", "announcements.create": "ALL", "announcements.update": "ALL", "announcements.delete": "ALL",
    "reports.view": "ALL", "audit.view": "ALL",
  },
  INSTRUCTOR: {
    "lectures.read": "ASSIGNED", "lectures.create": "ASSIGNED", "lectures.update": "ASSIGNED", "lectures.delete": "ASSIGNED",
    "attendance.session.manage": "ASSIGNED", "attendance.scan": "ASSIGNED", "attendance.view": "ASSIGNED",
    "attendance.edit": "ASSIGNED", "attendance.export": "ASSIGNED", "attendance.import": "ASSIGNED",
    "announcements.read": "ALL", "announcements.create": "ASSIGNED", "announcements.update": "OWN", "announcements.delete": "OWN",
    "reports.view": "ASSIGNED",
  },
  STUDENT_ADMIN: {
    "lectures.read": "STAGE", "lectures.create": "STAGE", "lectures.update": "OWN", "lectures.delete": "OWN",
    "announcements.read": "ALL", "announcements.create": "STAGE", "announcements.update": "OWN", "announcements.delete": "OWN",
    "qr.own.view": "OWN",
  },
  STUDENT: {
    "lectures.read": "STAGE", "attendance.view": "OWN", "announcements.read": "ALL", "qr.own.view": "OWN",
  },
};
```

---

## 8. الحضور بالباركود (الخوارزمية والكود)

### التصميم
- لكل طالب **QR شخصي متغيّر** (يتجدد كل 30 ثانية) يظهر في صفحة `/my-qr` بتطبيقه، فلا ينفع تصويره أو مشاركته.
- التدريسي يفتح جلسة (`/attendance/sessions/[id]/scan`) ويمسح الـ QR بكاميرا هاتفه.
- **بديل ثابت**: باركود Code128 للرقم الجامعي على بطاقة مطبوعة، ويدعم أيضاً قارئ باركود USB (يعمل كلوحة مفاتيح داخل حقل مُركَّز).
- صيغة المحتوى: `QR1:<token>` للمتغيّر، و`UID:<universityId>` للثابت.

### خوارزمية التوكن (مشابهة لـ TOTP)
```
window  = floor(unixSeconds / 30)
mac     = base64url( HMAC_SHA256(student.qrSecret, studentId + "." + window) )[0..22]
token   = studentId + "." + window + "." + mac
```
التحقق: نقبل `window` الحالي ± 1 فقط (تسامح مع فرق الساعة)، ونقارن بـ `timingSafeEqual`.

```ts
// src/lib/attendance/qr-token.ts
import { createHmac, timingSafeEqual } from "crypto";

const STEP = 30; // ثانية
const currentWindow = (t = Date.now()) => Math.floor(t / 1000 / STEP);
const sign = (secret: string, studentId: string, w: number) =>
  createHmac("sha256", secret).update(`${studentId}.${w}`).digest("base64url").slice(0, 22);

export function makeStudentToken(studentId: string, secret: string) {
  const w = currentWindow();
  return `QR1:${studentId}.${w}.${sign(secret, studentId, w)}`;
}

export function parseToken(raw: string) {
  const [studentId, w, mac] = raw.split(".");
  if (!studentId || !w || !mac || Number.isNaN(Number(w))) return null;
  return { studentId, w: Number(w), mac };
}

export function isValidMac(secret: string, studentId: string, w: number, mac: string) {
  if (Math.abs(currentWindow() - w) > 1) return false;
  const expected = Buffer.from(sign(secret, studentId, w));
  const given = Buffer.from(mac);
  return expected.length === given.length && timingSafeEqual(expected, given);
}
```

### فتح الجلسة (ينشئ صفوف "غائب" مسبقاً)
عند فتح الجلسة ينشئ النظام سجل `ABSENT` لكل طالب مسجّل في فرع المادة، فيصبح جدول الحضور مكتملاً وقابلاً للتعديل، والمسح يحوّل الحالة إلى `PRESENT/LATE`.

```ts
// src/app/api/attendance/sessions/[id]/open/route.ts
export async function POST(_: Request, { params }: { params: { id: string } }) {
  const session = await prisma.classSession.findUniqueOrThrow({
    where: { id: params.id }, include: { subject: { include: { branch: true } } },
  });
  await requirePermission("attendance.session.manage", {
    subjectId: session.subjectId, stageId: session.subject.branch.stageId,
  });

  const students = await prisma.studentProfile.findMany({
    where: { branchId: session.subject.branchId }, select: { userId: true },
  });
  await prisma.$transaction([
    prisma.attendance.createMany({
      data: students.map(s => ({ sessionId: session.id, studentId: s.userId })),
      skipDuplicates: true,
    }),
    prisma.classSession.update({ where: { id: session.id }, data: { status: "OPEN" } }),
  ]);
  return Response.json({ ok: true, count: students.length });
}
```

### نقطة المسح
```ts
// src/app/api/attendance/scan/route.ts
const schema = z.object({ sessionId: z.string(), payload: z.string().min(5).max(200) });

export async function POST(req: Request) {
  const { sessionId, payload } = schema.parse(await req.json());

  const session = await prisma.classSession.findUnique({
    where: { id: sessionId }, include: { subject: { include: { branch: true } } },
  });
  if (!session || session.status !== "OPEN") return fail("SESSION_CLOSED");

  const actor = await requirePermission("attendance.scan", {
    subjectId: session.subjectId, stageId: session.subject.branch.stageId,
  });
  await rateLimit(`scan:${actor.id}`, { max: 120, windowSec: 60 });

  // 1) تحديد الطالب من الباركود
  let student;
  let method: "QR_DYNAMIC" | "QR_STATIC";
  if (payload.startsWith("QR1:")) {
    const t = parseToken(payload.slice(4));
    if (!t) return fail("BAD_CODE");
    student = await prisma.user.findUnique({ where: { id: t.studentId } });
    if (!student?.qrSecret || !isValidMac(student.qrSecret, student.id, t.w, t.mac))
      return fail("EXPIRED_OR_FORGED");
    method = "QR_DYNAMIC";
  } else if (payload.startsWith("UID:")) {
    student = await prisma.user.findUnique({ where: { universityId: payload.slice(4) } });
    method = "QR_STATIC";
  } else return fail("BAD_CODE");

  if (!student || !student.isActive) return fail("NOT_FOUND");

  // 2) هل الطالب مسجّل في هذه الجلسة؟ (سجله موجود لأن الجلسة فُتحت مسبقاً)
  const rec = await prisma.attendance.findUnique({
    where: { sessionId_studentId: { sessionId, studentId: student.id } },
  });
  if (!rec) return fail("NOT_ENROLLED");

  // 3) منع التكرار
  const info = { name: student.fullName, universityId: student.universityId, photoUrl: student.photoUrl };
  if (rec.status !== "ABSENT") return ok({ duplicate: true, status: rec.status, student: info });

  // 4) حضور أو تأخير
  const now = new Date();
  const lateAt = new Date(session.startsAt.getTime() + session.lateAfterMin * 60_000);
  const status = now > lateAt ? "LATE" : "PRESENT";

  await prisma.attendance.update({
    where: { id: rec.id },
    data: { status, method, scannedAt: now, markedById: actor.id },
  });
  return ok({ duplicate: false, status, student: info });
}
```

### واجهة المسح (Scanner UI)
- كاميرا بملء الشاشة على الهاتف، مسح مستمر مع **تأخير 1.5 ثانية** بين القراءات (debounce).
- عند النجاح: صوت قصير + اهتزاز + بطاقة كبيرة تعرض **صورة الطالب واسمه وحالته** (أخضر = حضور، برتقالي = متأخر، رمادي = مكرر، أحمر = خطأ).
- قائمة "آخر الممسوحين" مع زر **تراجع** (يعيد الحالة إلى غائب).
- زر "تسجيل يدوي" لبحث طالب بالاسم أو الرقم الجامعي.
- حقل إدخال مخفي مُركَّز لدعم قارئ الباركود USB.
- تذكير: الكاميرا تحتاج **HTTPS**.

### تعديل الحضور (للعميد/التدريسي)
```ts
// PATCH /api/attendance/[id]  — body: { status, note, reason }
const rec = await prisma.attendance.findUniqueOrThrow({ where: { id }, include: { session: { include: { subject: { include: { branch: true } } } } } });
const actor = await requirePermission("attendance.edit", {
  subjectId: rec.session.subjectId, stageId: rec.session.subject.branch.stageId,
});
await prisma.$transaction([
  prisma.attendance.update({ where: { id }, data: { status, note, method: "MANUAL", editedById: actor.id, editedAt: new Date() } }),
  prisma.auditLog.create({ data: { actorId: actor.id, action: "attendance.edit", entity: "Attendance", entityId: id,
    before: { status: rec.status }, after: { status }, reason } }),
]);
```
> السبب (`reason`) إلزامي عند التعديل، وسجل التدقيق يظهر للعميد.

---

## 9. واجهة الحضور وتقارير Excel

### مصفوفة الحضور (تُعرض في الواجهة وفي Excel)
الصفوف = الطلاب، الأعمدة = تواريخ الجلسات:

| # | الطالب | 01/10 | 03/10 | 08/10 | 10/10 | حاضر | غائب | النسبة |
|---|---|---|---|---|---|---|---|---|
| 1 | أحمد علي | ✓ | ✓ | ت | ✓ | 4 | 0 | 100% |
| 2 | سارة حسن | ✓ | غ | ✓ | م | 2 | 1 | 67% |

الرموز: `✓` حاضر، `غ` غائب، `ت` متأخر، `م` مجاز.

```ts
// src/lib/attendance/matrix.ts
const SYMBOL = { PRESENT: "✓", ABSENT: "غ", LATE: "ت", EXCUSED: "م" } as const;

export function buildMatrix(
  students: { id: string; fullName: string }[],
  sessions: { id: string; date: Date }[],
  records: { studentId: string; sessionId: string; status: keyof typeof SYMBOL }[],
  absenceLimitPct = 25
) {
  const index = new Map(records.map(r => [`${r.studentId}:${r.sessionId}`, r.status]));
  return students.map((s, i) => {
    const row = sessions.map(ss => index.get(`${s.id}:${ss.id}`) ?? "ABSENT");
    const present = row.filter(x => x === "PRESENT" || x === "LATE").length;
    const excused = row.filter(x => x === "EXCUSED").length;
    const absent  = row.filter(x => x === "ABSENT").length;
    const counted = Math.max(row.length - excused, 1);           // المجاز لا يُحتسب غياباً
    const attendancePct = Math.round((present / counted) * 100);
    return {
      no: i + 1, name: s.fullName, cells: row.map(x => SYMBOL[x]),
      present, absent, attendancePct,
      atRisk: (absent / counted) * 100 > absenceLimitPct,         // تحذير الحرمان (نسبة قابلة للتعديل)
    };
  });
}
```

### التصدير (exceljs)
- ملف `.xlsx` باتجاه RTL، رأس أخضر بنص أبيض، تجميد أول عمودين وأول صف.
- تلوين الخلايا: حاضر أخضر فاتح، غائب أحمر فاتح، متأخر برتقالي فاتح، مجاز أزرق فاتح.
- صف إحصائي نهائي (نسبة الحضور لكل يوم).
- تصفية: حسب المادة، المرحلة/الفرع، الفترة (من–إلى)، الطالب.

```ts
const wb = new ExcelJS.Workbook();
const ws = wb.addWorksheet("الحضور", { views: [{ rightToLeft: true, state: "frozen", xSplit: 2, ySplit: 1 }] });
ws.columns = [
  { header: "#", width: 5 }, { header: "اسم الطالب", width: 30 },
  ...sessions.map(s => ({ header: format(s.date, "dd/MM"), width: 9 })),
  { header: "حاضر", width: 8 }, { header: "غائب", width: 8 }, { header: "النسبة %", width: 10 },
];
ws.getRow(1).eachCell(c => {
  c.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF16A34A" } };
  c.font = { color: { argb: "FFFFFFFF" }, bold: true };
  c.alignment = { horizontal: "center" };
});
```

### الاستيراد من Excel
1. المستخدم يرفع نفس القالب المُصدَّر بعد تعديله.
2. النظام يتحقق (Zod) من الرموز والتواريخ والأرقام الجامعية.
3. يعرض **معاينة الفروقات** (كان/صار) قبل التطبيق.
4. عند التأكيد يطبّق التغييرات بـ `method = EXCEL_IMPORT` ويكتب سجل تدقيق لكل صف تغيّر.

### صفحات الحضور
- **للتدريسي/العميد:** قائمة الجلسات، فتح/إغلاق جلسة، المسح، جدول المصفوفة القابل للتعديل (نقر على الخلية يغيّر الحالة مع سبب)، التصدير والاستيراد، تنبيه الطلاب المعرّضين للحرمان.
- **للطالب:** `/my-attendance` يعرض سجله لكل مادة بالتاريخ، ونسبة الحضور، دون إمكانية التعديل. و`/my-qr` يعرض QR المتغيّر مع عدّاد تنازلي ظاهر، وزر لتكبير الشاشة والسطوع.

---

## 10. الهيكل الأكاديمي (المراحل ← الفروع ← المواد ← المحاضرات)

```
المرحلة (Stage)
 └─ الفرع التدريسي (Branch)
     └─ المادة (Subject)  ← تُسند لتدريسي أو أكثر
         ├─ المحاضرات والشروحات (Lectures + Files + Video)
         ├─ جلسات الحضور (ClassSession)
         └─ التبليغات الخاصة بالمادة
```

الصفحات (Breadcrumb ظاهر دائماً):
- `/stages` — بطاقات المراحل (عدد الطلاب والمواد في كل مرحلة).
- `/stages/[stageId]` — بطاقات الفروع التدريسية.
- `/stages/[stageId]/branches/[branchId]` — مواد الفرع.
- `/subjects/[subjectId]` — تبويبات: **المحاضرات | الحضور | التبليغات | الطلاب**.

المحاضرة تحتوي: عنوان، ملخص، رقم الأسبوع، النوع (نظري/عملي)، شرح بصيغة Markdown (محرر بسيط بمعاينة)، رابط فيديو، ملفات مرفقة (PDF/PPT/صور — تحقق من النوع والحجم وحدٍّ أقصى مثل 25MB)، ومفتاح نشر/إخفاء.

التحكم بالوصول:
- الطالب يرى فقط محاضرات **مرحلته** (`lectures.read` بنطاق `STAGE`).
- الطالب المسؤول يضيف محاضرات لمرحلته، ويعدّل/يحذف ما أنشأه هو فقط (`OWN`).
- التدريسي يدير مواده المسندة فقط (`ASSIGNED`).

---

## 11. التبليغات والإشعارات (Web Push)

### سير العمل
1. المستخدم المصرَّح له ينشئ تبليغاً: عنوان، نص، أولوية، **الجمهور** (الكل / مرحلة / فرع / مادة)، تثبيت، تاريخ انتهاء.
2. النظام يحفظه، ثم يحدّد المستلمين ويرسل Push ويكتب `Notification` داخل التطبيق.
3. الضغط على الإشعار يفتح التبليغ مباشرة.
4. جرس إشعارات في الهيدر مع عدّاد غير المقروء (`AnnouncementRead`).

### طلب الإذن (UX مهم)
- **لا تطلب الإذن عند فتح الصفحة.** اعرض بطاقة لطيفة: "فعّل الإشعارات لتصلك التبليغات فوراً" بزر **تفعيل**، ثم اطلب الإذن عند النقر.
- إذا رفض: اعرض شرحاً قصيراً لكيفية تفعيله من إعدادات المتصفح، وابقِ الإشعارات الداخلية تعمل.
- **iOS:** الإشعارات تعمل فقط (iOS 16.4+) بعد **"إضافة إلى الشاشة الرئيسية"**. اعرض دليلاً مصوراً يظهر تلقائياً لمستخدمي iOS داخل المتصفح.

### الكود
```ts
// public/sw.js
self.addEventListener("push", (event) => {
  const d = event.data ? event.data.json() : {};
  event.waitUntil(self.registration.showNotification(d.title || "تبليغ جديد", {
    body: d.body, icon: "/icons/icon-192.png", badge: "/icons/badge-72.png",
    dir: "rtl", lang: "ar", tag: d.tag, data: { url: d.url || "/announcements" },
  }));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = event.notification.data.url;
  event.waitUntil(clients.matchAll({ type: "window", includeUncontrolled: true }).then((list) => {
    for (const c of list) if ("focus" in c) { c.navigate(url); return c.focus(); }
    return clients.openWindow(url);
  }));
});
```

```ts
// src/lib/push/client.ts
export async function enablePush() {
  if (!("serviceWorker" in navigator) || !("PushManager" in window))
    return { ok: false as const, reason: "UNSUPPORTED" };
  const perm = await Notification.requestPermission();
  if (perm !== "granted") return { ok: false as const, reason: "DENIED" };
  const reg = await navigator.serviceWorker.ready;
  const sub = await reg.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: urlBase64ToUint8Array(process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY!),
  });
  await fetch("/api/push/subscribe", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(sub),
  });
  return { ok: true as const };
}
```

```ts
// src/lib/push/server.ts
import webpush from "web-push";
import pLimit from "p-limit";

webpush.setVapidDetails(process.env.VAPID_SUBJECT!, process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY!, process.env.VAPID_PRIVATE_KEY!);

export async function resolveAudience(a: Announcement): Promise<string[]> {
  const where =
    a.audienceType === "ALL"    ? {} :
    a.audienceType === "STAGE"  ? { studentProfile: { stageId: a.stageId! } } :
    a.audienceType === "BRANCH" ? { studentProfile: { branchId: a.branchId! } } :
                                  { studentProfile: { branch: { subjects: { some: { id: a.subjectId! } } } } };
  const users = await prisma.user.findMany({ where: { isActive: true, ...where }, select: { id: true } });
  return users.map(u => u.id);
}

export async function sendToUsers(userIds: string[], payload: { title: string; body: string; url: string; tag?: string }) {
  const subs = await prisma.pushSubscription.findMany({ where: { userId: { in: userIds } } });
  const limit = pLimit(20);
  await Promise.allSettled(subs.map(s => limit(async () => {
    try {
      await webpush.sendNotification(
        { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
        JSON.stringify(payload), { TTL: 60 * 60 * 24 }
      );
    } catch (e: any) {
      if (e.statusCode === 404 || e.statusCode === 410)          // اشتراك منتهٍ → احذفه
        await prisma.pushSubscription.delete({ where: { id: s.id } });
    }
  })));
}
```
- للأعداد الكبيرة: انقل الإرسال إلى طابور (Upstash QStash أو Vercel Cron) بدل الإرسال داخل الطلب نفسه.
- توليد المفاتيح: `npx web-push generate-vapid-keys`.

---

## 12. PWA وتشغيله على Android و iOS مع تحديث فوري

```ts
// src/app/manifest.ts
import type { MetadataRoute } from "next";
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "نظام إدارة الكلية", short_name: "الكلية",
    start_url: "/dashboard", display: "standalone", dir: "rtl", lang: "ar",
    background_color: "#ffffff", theme_color: "#16a34a",
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
      { src: "/icons/maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
```

- أضف في `layout.tsx`: `viewport.themeColor`، وأيقونة `apple-touch-icon`، و`appleWebApp: { capable: true }`.
- Service Worker (Serwist): كاش للأصول الثابتة، **NetworkFirst** لطلبات الـ API، وصفحة `/offline` بسيطة. **لا تخزّن** بيانات الحضور محلياً بشكل يسمح بالتلاعب.
- **التحديث الفوري:** عند نشر نسخة جديدة يكتشفها الـ Service Worker، فيظهر شريط "يتوفر تحديث — اضغط للتحديث" ويستدعي `skipWaiting()` ثم يعيد التحميل.
- زر/بانر "ثبّت التطبيق" باستخدام حدث `beforeinstallprompt` على Android، ودليل مصوّر لـ iOS (مشاركة ← إضافة إلى الشاشة الرئيسية).
- **تطوير لاحق (اختياري):** تغليف الموقع بـ Capacitor لنشره في Google Play و App Store، مع `server.url` يشير للموقع المنشور حتى تبقى التحديثات فورية، واستبدال Web Push بـ FCM/APNs عبر `@capacitor/push-notifications`.

---

## 13. هيكل المشروع والصفحات

```
src/
├─ app/
│  ├─ (auth)/login/page.tsx
│  ├─ (app)/
│  │  ├─ layout.tsx                 # Sidebar + BottomNav + Header
│  │  ├─ dashboard/page.tsx         # لوحة مختلفة لكل دور
│  │  ├─ stages/…                   # القسم 10
│  │  ├─ subjects/[subjectId]/…
│  │  ├─ attendance/
│  │  │  ├─ sessions/[id]/scan/page.tsx
│  │  │  └─ reports/page.tsx
│  │  ├─ my-qr/page.tsx             # الطالب
│  │  ├─ my-attendance/page.tsx     # الطالب
│  │  ├─ announcements/…
│  │  ├─ settings/notifications/page.tsx
│  │  └─ admin/
│  │     ├─ permissions/page.tsx    # المالك فقط
│  │     ├─ users/page.tsx
│  │     ├─ structure/page.tsx
│  │     └─ audit-log/page.tsx
│  ├─ api/…                         # auth, attendance, push, files, admin
│  ├─ manifest.ts
│  └─ globals.css
├─ components/ (ui/, layout/, attendance/, announcements/, rbac/<Can/>)
├─ lib/ (prisma.ts, auth.ts, rbac/, attendance/, push/, excel/, rate-limit.ts)
└─ middleware.ts
prisma/ (schema.prisma, seed.ts, seed/matrix.ts)
public/ (sw.js, icons/)
```

محتوى لوحة التحكم حسب الدور:
- **OWNER/DEAN:** أعداد (طلاب، تدريسيون، مواد)، نسبة الحضور العامة، طلاب معرّضون للحرمان، آخر التبليغات، آخر تعديلات الحضور.
- **INSTRUCTOR:** جلساتي اليوم (زر "ابدأ الحضور")، موادي، آخر المحاضرات، تنبيهات الغياب.
- **STUDENT_ADMIN/STUDENT:** محاضرات المرحلة الجديدة، تبليغات غير مقروءة، نسبة حضوري، زر "باركودي".

الحماية بالـ middleware والـ Layout:
```ts
// middleware.ts
export { auth as middleware } from "@/auth";
export const config = {
  matcher: ["/((?!login|api/auth|_next|icons|sw.js|manifest.webmanifest).*)"],
};
```
ثم في كل صفحة/Action استدعِ `requirePermission(...)` ولا تعتمد على الـ middleware وحده.

مكوّن واجهة للتجميل فقط (الحماية الحقيقية في السيرفر):
```tsx
// <Can permission="attendance.edit" resource={{ subjectId }}> … </Can>
```

---

## 14. الأمان

- كلمات المرور بـ `argon2` (أو bcrypt بتكلفة ≥ 12)، وإجبار تغييرها عند أول دخول (`mustChangePassword`).
- Rate limiting على تسجيل الدخول (5 محاولات/دقيقة/IP+بريد) وعلى نقطة المسح.
- Zod على **كل** مدخل، وعدم الوثوق بأي حقل `role` أو `userId` قادم من العميل.
- رؤوس أمان (CSP, X-Frame-Options, Referrer-Policy) عبر `next.config`.
- رفع الملفات: تحقق من MIME والحجم، وأسماء ملفات عشوائية، وتخزين خارجي (S3/R2/UploadThing) لا داخل مجلد `public`.
- `qrSecret` لا يُرسل للعميل أبداً، ويُولَّد بـ `crypto.randomBytes(32)`.
- حذف ناعم أو تعطيل (`isActive`) بدل حذف المستخدمين الذين لديهم سجلات.
- كل العمليات الحساسة (تعديل حضور، تعديل صلاحيات، إنشاء/تعطيل مستخدم) تُسجَّل في `AuditLog` مع IP.
- نسخ احتياطي دوري لقاعدة البيانات، والوقت يُخزَّن UTC ويُعرض بمنطقة `APP_TIMEZONE`.

---

## 15. خطة التنفيذ (نفّذ على مراحل ولا تقفز)

**المرحلة 1 — الأساس:** إنشاء مشروع Next.js، Tailwind + shadcn، الخطوط، RTL، الـ Design System، Prisma + schema + migrations، Seed (الأدوار، الصلاحيات، المصفوفة، حساب المالك، مراحل وفروع ومواد تجريبية)، Auth.js، نظام RBAC (`can`, `requirePermission`)، Layout (Sidebar/BottomNav)، صفحة الدخول.

**المرحلة 2 — الإدارة والهيكل:** إدارة المستخدمين (إنشاء، استيراد Excel، تعطيل)، إدارة المراحل/الفروع/المواد وإسناد التدريسيين، **واجهة مصفوفة الصلاحيات للمالك**، سجل التدقيق.

**المرحلة 3 — المحاضرات:** صفحات المراحل ← الفروع ← المواد، إضافة/تعديل/حذف محاضرات، رفع الملفات، محرر Markdown، عرض الطالب.

**المرحلة 4 — الحضور:** الجلسات، `/my-qr` بالـ QR المتغيّر، الماسح، التسجيل اليدوي، مصفوفة الحضور القابلة للتعديل، `/my-attendance`، تصدير/استيراد Excel، تنبيه الحرمان.

**المرحلة 5 — التبليغات والإشعارات:** إنشاء التبليغات والجمهور، جرس الإشعارات، Web Push، طلب الإذن بتجربة لطيفة، دليل iOS.

**المرحلة 6 — PWA والتحسينات:** manifest، Service Worker، التحديث الفوري، لوحات التحكم، الأداء (Lighthouse ≥ 90)، إمكانية الوصول.

**المرحلة 7 — الجودة والنشر:** اختبارات Vitest للمنطق (التوكن، الصلاحيات، مصفوفة الحضور) وPlaywright للمسارات (دخول، مسح، تعديل حضور، تغيير صلاحية)، `README` بالعربية، `Dockerfile`، ونشر على Vercel + قاعدة (Neon/Supabase) أو VPS.

### صيغة ردّك في نهاية كل مرحلة
```
✅ ما أُنجز: …
📁 الملفات المضافة/المعدّلة: …
▶️ طريقة التشغيل: …
🧪 طريقة الاختبار: …
⏭️ المرحلة التالية: …
```

---

## 16. معايير القبول (Checklist)

- [ ] لا يستطيع غير المالك فتح `/admin/permissions` ولا استدعاء API التعديل (يرجع 403).
- [ ] تغيير صلاحية من المصفوفة ينعكس فوراً على المستخدمين بعد إبطال الكاش.
- [ ] الطالب لا يرى إلا محاضرات مرحلته، ولا يستطيع تعديل أي حضور.
- [ ] الطالب المسؤول يضيف محاضرة ويعدّل/يحذف ما أنشأه فقط.
- [ ] التدريسي لا يرى ولا يعدّل حضور مادة غير مسندة إليه.
- [ ] QR الطالب يتغيّر كل 30 ثانية، والـ QR القديم (> 90 ثانية) مرفوض.
- [ ] مسح الطالب مرتين لا يسجّل مرتين، ويظهر "مكرر".
- [ ] تعديل الحضور يتطلب سبباً ويظهر في سجل التدقيق.
- [ ] ملف Excel المُصدَّر يفتح بالعربية RTL بالألوان الصحيحة، واستيراده يعرض معاينة قبل التطبيق.
- [ ] التبليغ لمرحلة معيّنة يصل **فقط** لطلاب تلك المرحلة.
- [ ] طلب إذن الإشعارات يظهر بعد نقرة المستخدم وليس تلقائياً، والإشعار يفتح الصفحة الصحيحة.
- [ ] التطبيق قابل للتثبيت على Android و iOS، وشريط "يتوفر تحديث" يعمل.
- [ ] التصميم متجاوب من 360px إلى الشاشات الكبيرة، بالألوان الأخضر والأزرق الفاتح والأبيض.
- [ ] نتيجة Lighthouse: Performance و Accessibility و PWA ≥ 90.

---

**ابدأ الآن بالمرحلة 1 فقط، واعرض كل الملفات كاملة.**
