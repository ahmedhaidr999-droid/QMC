// بذرة قاعدة البيانات — الأدوار والصلاحيات والمصفوفة وحسابات تجريبية وهيكل أكاديمي
// التشغيل: bun prisma/seed.ts
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";
import { DEFAULT_MATRIX, PERMISSION_DEFS, APP_TIMEZONE } from "../src/lib/constants";

const db = new PrismaClient();

// 09:00 بتوقيت بغداد = 06:00 UTC (بغداد UTC+3 صيفاً وشتاءً)
function baghdad(y: number, m: number, d: number, h: number, min = 0) {
  return new Date(Date.UTC(y, m - 1, d, h - 3, min));
}

async function main() {
  console.log("🌱 بدء البذر...");

  // ===== 1) الأدوار =====
  const roleDefs = [
    { key: "OWNER", nameAr: "مالك النظام" },
    { key: "DEAN", nameAr: "عميد الكلية" },
    { key: "INSTRUCTOR", nameAr: "تدريسي" },
    { key: "STUDENT_ADMIN", nameAr: "طالب مسؤول" },
    { key: "STUDENT", nameAr: "طالب" },
  ];
  const roles: Record<string, { id: string }> = {};
  for (const r of roleDefs) {
    const role = await db.role.upsert({ where: { key: r.key }, update: { nameAr: r.nameAr }, create: r });
    roles[r.key] = role;
  }

  // ===== 2) الصلاحيات + المصفوفة =====
  const perms: Record<string, { id: string }> = {};
  for (const p of PERMISSION_DEFS) {
    perms[p.key] = await db.permission.upsert({
      where: { key: p.key },
      update: { group: p.group, nameAr: p.nameAr },
      create: p,
    });
  }

  await db.rolePermission.deleteMany({});
  for (const [roleKey, grants] of Object.entries(DEFAULT_MATRIX)) {
    for (const [permKey, scope] of Object.entries(grants)) {
      if (scope === "NONE") continue;
      await db.rolePermission.create({
        data: { roleId: roles[roleKey].id, permissionId: perms[permKey].id, scope },
      });
    }
  }

  // إعداد: من يستطيع تعديل المصفوفة (المالك فقط)
  await db.appSetting.upsert({
    where: { key: "permissions.editableByRoles" },
    update: { value: JSON.stringify(["OWNER"]) },
    create: { key: "permissions.editableByRoles", value: JSON.stringify(["OWNER"]) },
  });

  // ===== 3) المستخدمون =====
  const hash = (p: string) => bcrypt.hashSync(p, 12);
  const owner = await db.user.upsert({
    where: { email: process.env.OWNER_EMAIL || "owner@college.edu" },
    update: {},
    create: {
      email: process.env.OWNER_EMAIL || "owner@college.edu",
      passwordHash: hash(process.env.OWNER_PASSWORD || "Owner@123"),
      fullName: "مالك النظام",
      roleId: roles.OWNER.id,
      mustChangePassword: false,
    },
  });

  const dean = await db.user.upsert({
    where: { email: "dean@college.edu" },
    update: {},
    create: {
      email: "dean@college.edu",
      passwordHash: hash("Dean@123"),
      fullName: "د. حسن العميد",
      phone: "07701112233",
      roleId: roles.DEAN.id,
      mustChangePassword: false,
    },
  });

  const inst1 = await db.user.upsert({
    where: { email: "inst1@college.edu" },
    update: {},
    create: {
      email: "inst1@college.edu",
      passwordHash: hash("Inst@123"),
      fullName: "م. د. أحمد الكناني",
      phone: "07704445566",
      roleId: roles.INSTRUCTOR.id,
      mustChangePassword: false,
    },
  });
  const inst2 = await db.user.upsert({
    where: { email: "inst2@college.edu" },
    update: {},
    create: {
      email: "inst2@college.edu",
      passwordHash: hash("Inst@123"),
      fullName: "م. د. ليلى حسن",
      phone: "07707778899",
      roleId: roles.INSTRUCTOR.id,
      mustChangePassword: false,
    },
  });

  // ===== 4) الهيكل الأكاديمي =====
  const stage1 = await db.stage.upsert({
    where: { level: 1 },
    update: { nameAr: "المرحلة الأولى" },
    create: { nameAr: "المرحلة الأولى", level: 1 },
  });
  const stage2 = await db.stage.upsert({
    where: { level: 2 },
    update: { nameAr: "المرحلة الثانية" },
    create: { nameAr: "المرحلة الثانية", level: 2 },
  });

  const b1 = await db.branch.upsert({ where: { stageId_nameAr: { stageId: stage1.id, nameAr: "علوم الحاسوب" } }, update: {}, create: { stageId: stage1.id, nameAr: "علوم الحاسوب" } });
  const b2 = await db.branch.upsert({ where: { stageId_nameAr: { stageId: stage1.id, nameAr: "تقنية المعلومات" } }, update: {}, create: { stageId: stage1.id, nameAr: "تقنية المعلومات" } });
  const b3 = await db.branch.upsert({ where: { stageId_nameAr: { stageId: stage2.id, nameAr: "علوم الحاسوب" } }, update: {}, create: { stageId: stage2.id, nameAr: "علوم الحاسوب" } });

  const subjects = [
    { branchId: b1.id, code: "CS101", nameAr: "مقدمة في البرمجة", semester: 1, inst: inst1.id },
    { branchId: b1.id, code: "CS102", nameAr: "الرياضيات المتقطعة", semester: 1, inst: inst2.id },
    { branchId: b2.id, code: "IT101", nameAr: "أساسيات الشبكات", semester: 1, inst: inst2.id },
    { branchId: b3.id, code: "CS201", nameAr: "هياكل البيانات", semester: 1, inst: inst1.id },
  ];
  const subjectIds: Record<string, string> = {};
  for (const s of subjects) {
    const sub = await db.subject.upsert({
      where: { branchId_code: { branchId: s.branchId, code: s.code } },
      update: { nameAr: s.nameAr },
      create: { branchId: s.branchId, code: s.code, nameAr: s.nameAr, semester: s.semester },
    });
    subjectIds[s.code] = sub.id;
    await db.subjectInstructor.upsert({
      where: { subjectId_userId: { subjectId: sub.id, userId: s.inst } },
      update: {},
      create: { subjectId: sub.id, userId: s.inst },
    });
  }

  // ===== 5) الطلاب =====
  const studentDefs = [
    { email: "student1@college.edu", name: "علي عبد الرحمن", uid: "202512001", branch: b1, role: "STUDENT_ADMIN", pass: "StAdmin@123" },
    { email: "student2@college.edu", name: "مريم جابر", uid: "202512002", branch: b1, role: "STUDENT", pass: "Student@123" },
    { email: "student3@college.edu", name: "حسين صالح", uid: "202512003", branch: b1, role: "STUDENT", pass: "Student@123" },
    { email: "student4@college.edu", name: "زينب موسى", uid: "202512004", branch: b1, role: "STUDENT", pass: "Student@123" },
    { email: "student5@college.edu", name: "مقتدى كاظم", uid: "202512005", branch: b1, role: "STUDENT", pass: "Student@123" },
    { email: "student6@college.edu", name: "نور الهدى", uid: "202512006", branch: b2, role: "STUDENT", pass: "Student@123" },
    { email: "student7@college.edu", name: "فاطمة العبيدي", uid: "202512007", branch: b2, role: "STUDENT", pass: "Student@123" },
    { email: "student8@college.edu", name: "مرتضى حميد", uid: "202522001", branch: b3, role: "STUDENT", pass: "Student@123" },
  ];
  const studentIds: string[] = [];
  for (const st of studentDefs) {
    const u = await db.user.upsert({
      where: { email: st.email },
      update: {},
      create: {
        email: st.email,
        passwordHash: hash(st.pass),
        fullName: st.name,
        universityId: st.uid,
        roleId: roles[st.role].id,
        qrSecret: randomBytes(32).toString("base64url"),
        mustChangePassword: false,
        studentProfile: {
          create: {
            stageId: st.branch.stageId,
            branchId: st.branch.id,
            academicYear: "2025-2026",
          },
        },
      },
    });
    studentIds.push(u.id);
  }

  // ===== 6) محاضرات =====
  const lectures = [
    { code: "CS101", title: "المحاضرة الأولى: مقدمة في الخوارزميات", week: 1, type: "THEORY", md: "# مقدمة في الخوارزميات\n\nالخوارزمية هي **سلسلة خطوات منتهية** لحل مشكلة معينة.\n\n## مفاهيم أساسية\n1. المدخلات والمخرجات\n2. الحتمية\n3. الانتهاء\n\n> مثال: خوارزمية إيجاد الأكبر بين ثلاثة أعداد.\n\n```python\na = int(input())\nb = int(input())\nprint(max(a, b))\n```" },
    { code: "CS101", title: "المحاضرة الثانية: المتغيرات وأنواع البيانات", week: 2, type: "THEORY", md: "# المتغيرات\n\nالمتغير **وعاء في الذاكرة** يحمل قيمة قابلة للتغيير.\n\n| النوع | الحجم | مثال |\n|---|---|---|\n|int | 4 بايت | 42 |\n|float | 8 بايت | 3.14 |\n\n- **int** للأعداد الصحيحة\n- **float** للأعداد الحقيقية\n- **str** للنصوص" },
    { code: "CS101", title: "تطبيق عملي: أول برنامج بايثون", week: 3, type: "PRACTICAL", md: "# تطبيق عملي\n\n1. ثبّت بايثون من الموقع الرسمي\n2. اكتب أول برنامج\n\n```python\nprint(\"مرحباً بالعالم\")\n```" },
    { code: "CS102", title: "المنطق والبراهين", week: 1, type: "THEORY", md: "# المنطق الرياضي\n\n- **الجدول الصادقي** للأطروحات\n- قوانين **دي مورغان**\n\n$\\neg(p \\wedge q) \\iff \\neg p \\vee \\neg q$" },
    { code: "IT101", title: "نموذج OSI وطبقاته", week: 1, type: "THEORY", md: "# نموذج OSI\n\nسبع طبقات من الأسفل للأعلى:\n1. الفيزيائية\n2. ربط البيانات\n3. الشبكة\n4. النقل\n5. الجلسة\n6. العرض\n7. التطبيق" },
    { code: "CS201", title: "المصفوفات والقوائم المترابطة", week: 1, type: "THEORY", md: "# هياكل البيانات\n\n**المصفوفة**: كتلة ذاكرة متجاورة.\n\n**القائمة المترابطة**: عقد ترتبط بمؤشرات." },
  ];
  for (const l of lectures) {
    const exists = await db.lecture.findFirst({ where: { subjectId: subjectIds[l.code], title: l.title } });
    if (!exists) {
      await db.lecture.create({
        data: {
          subjectId: subjectIds[l.code],
          title: l.title,
          summary: `شرح كامل للمحاضرة مع أمثلة تطبيقية — ${l.title}`,
          contentMd: l.md,
          weekNo: l.week,
          type: l.type,
          isPublished: true,
          createdById: inst1.id,
        },
      });
    }
  }

  // ===== 7) جلسات وحضور تجريبية (لمادة CS101) =====
  const now = new Date();
  const y = now.getUTCFullYear();
  const sessionDefs = [
    { d: 14, daysAgo: 12, statuses: ["PRESENT", "PRESENT", "PRESENT", "ABSENT", "PRESENT", "ABSENT"] },
    { d: 21, daysAgo: 5, statuses: ["PRESENT", "LATE", "PRESENT", "PRESENT", "ABSENT", "PRESENT"] },
    { d: 24, daysAgo: 2, statuses: ["PRESENT", "PRESENT", "EXCUSED", "PRESENT", "LATE", "PRESENT"] },
  ];
  const csStudents = studentIds.slice(0, 6); // طلاب b1: student1..5 + لا، 6 طلاب b1 هم 1..5 فقط
  const b1Students = studentIds.slice(0, 5); // الخمسة الأوائل
  for (const sd of sessionDefs) {
    const startsAt = baghdad(y, now.getUTCMonth() + 1, now.getUTCDate() - sd.daysAgo, 9);
    const endsAt = baghdad(y, now.getUTCMonth() + 1, now.getUTCDate() - sd.daysAgo, 10, 30);
    const exists = await db.classSession.findFirst({ where: { subjectId: subjectIds.CS101, startsAt } });
    if (exists) continue;
    const session = await db.classSession.create({
      data: {
        subjectId: subjectIds.CS101,
        date: startsAt,
        startsAt,
        endsAt,
        room: "قاعة 12",
        lateAfterMin: 15,
        status: "CLOSED",
        createdById: inst1.id,
      },
    });
    // SQLite لا يدعم skipDuplicates → إنشاء صف بحال مع تجاهل التكرار
    for (const [i, sid] of b1Students.entries()) {
      await db.attendance
        .create({
          data: {
            sessionId: session.id,
            studentId: sid,
            status: sd.statuses[i],
            method: "MANUAL",
            scannedAt: sd.statuses[i] === "ABSENT" ? null : startsAt,
            markedById: inst1.id,
          },
        })
        .catch(() => {});
    }
  }

  // جلسة اليوم مفتوحة (CS101)
  {
    const todayStart = baghdad(y, now.getUTCMonth() + 1, now.getUTCDate(), 9);
    const todayEnd = baghdad(y, now.getUTCMonth() + 1, now.getUTCDate(), 10, 30);
    const exists = await db.classSession.findFirst({ where: { subjectId: subjectIds.CS101, startsAt: todayStart } });
    if (!exists) {
      const session = await db.classSession.create({
        data: {
          subjectId: subjectIds.CS101,
          date: todayStart,
          startsAt: todayStart,
          endsAt: todayEnd,
          room: "قاعة 12",
          status: "SCHEDULED",
          createdById: inst1.id,
        },
      });
      // SQLite لا يدعم skipDuplicates → إنشاء صف بحال
      for (const sid of b1Students) {
        await db.attendance
          .create({ data: { sessionId: session.id, studentId: sid } })
          .catch(() => {});
      }
    }
  }

  // ===== 8) تبليغات =====
  const annDefs = [
    { title: "بدء الدوام الصباحي للفصل الدراسي", body: "يبدأ الدوام الصباحي الساعة الثامنة والنصف تماماً، يُرجى من الطلبة الالتزام بالمواعيد.", priority: "IMPORTANT", audienceType: "ALL", pinned: true },
    { title: "جدول الاختبارات النصفية", body: "تم نشر جدول الاختبارات النصفية للمرحلة الأولى على لوحة الإعلانات وبوابة الطالب.", priority: "NORMAL", audienceType: "STAGE", stageId: stage1.id },
    { title: "تسليم مشروع مادة البرمجة", body: "آخر موعد لتسليم المشروع النهائي لمادة مقدمة في البرمجة نهاية الأسبوع القادم.", priority: "URGENT", audienceType: "SUBJECT", subjectId: subjectIds.CS101 },
  ];
  for (const a of annDefs) {
    const exists = await db.announcement.findFirst({ where: { title: a.title } });
    if (!exists) {
      await db.announcement.create({
        data: {
          title: a.title,
          body: a.body,
          priority: a.priority,
          audienceType: a.audienceType,
          stageId: "stageId" in a && a.stageId ? a.stageId : null,
          subjectId: "subjectId" in a && a.subjectId ? a.subjectId : null,
          pinned: a.pinned ?? false,
          createdById: dean.id,
        },
      });
    }
  }

  // ===== 9) سجل تدقيق أولي =====
  await db.auditLog.create({
    data: {
      actorId: owner.id,
      action: "system.seed",
      entity: "System",
      after: JSON.stringify({ message: "تهيئة النظام والبذرة الأولية", timezone: APP_TIMEZONE }),
    },
  });

  console.log("✅ تمت البذرة بنجاح");
  console.log("   حسابات تجريبية:");
  console.log("   المالك: owner@college.edu / Owner@123");
  console.log("   العميد: dean@college.edu / Dean@123");
  console.log("   تدريسي: inst1@college.edu / Inst@123");
  console.log("   طالب مسؤول: student1@college.edu / StAdmin@123");
  console.log("   طالب: student2@college.edu / Student@123");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
