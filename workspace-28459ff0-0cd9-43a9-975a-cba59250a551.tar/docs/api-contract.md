# عقد الـ API والواجهات — نظام إدارة الكلية (للوكلاء)

## قواعد عامة إلزامية
- كل النصوص الظاهرة للمستخدم **بالعربية**، `dir="rtl"` موروث من html — لا تضبطه يدوياً.
- استخدم `api<T>(path, init)` من `@/lib/client/api` — يرمي `ApiError` برسالة عربية جاهزة للعرض بـ `toast.error(e.message)`.
- الحالة: `useApp()` من `@/lib/client/store` (يحوي `user`, `scopes`, `hasScope(key)`, `unread`).
- التنقل: `navigate("/path")` (يضيف # تلقائياً). المسار الحالي عبر `useHashRoute().segments`.
- الجلب: `useQuery({ queryKey: [...], queryFn })` من @tanstack/react-query (مفعّل بمزوّد عام). الطفرات: `useMutation` + `qc.invalidateQueries`.
- الإشعارات: `import { toast } from "sonner"` — استخدم `toast.success/error(...)` بعد كل عملية.
- كل صفحة يجب أن تحتوي: Skeleton تحميل (`LoadingPage`/`LoadingRows` من `@/components/app/shared/ui-bits`)، EmptyState، ErrorState مع onRetry.
- ممنوع: أي `TODO`، ملفات جديدة خارج مسارك المحدد، تعديل page.tsx أو AppShell أو ملفات API.
- مكونات shadcn متاحة في `@/components/ui/*`: button, card, dialog, input, label, select, tabs, badge, table, textarea, dropdown-menu, alert-dialog, switch, checkbox, radio-group, skeleton, separator, avatar, tooltip, popover, form, accordion, scroll-area, command, hover-card, progress, sheet, sonner...
- أيقونات lucide-react. مكوّنات مشتركة في `@/components/app/shared/ui-bits`: PageHeader, EmptyState, ErrorState, LoadingPage, LoadingRows, StatCard, StatusBadge, PriorityBadge.
- ثوابت عربية من `@/lib/constants`: STATUS_LABELS, STATUS_SYMBOLS, STATUS_COLORS, METHOD_LABELS, SESSION_STATUS_LABELS, AUDIENCE_LABELS, PRIORITY_LABELS, LECTURE_TYPE_LABELS, ROLE_LABELS, SCOPE_LABELS, ABSENCE_LIMIT_PCT.
- تواريخ: `fmtDate/fmtTime/fmtShort/fmtWeekday/fmtDateTime` من `@/lib/date-fmt` (توقيت بغداد).
- التصميم: بطاقات `rounded-2xl shadow-sm border-border/60`، بطاقة إحصاء استخدم `StatCard`، رأس صفحة `PageHeader` بأيقونة. أهداف لمس ≥44px. لا تستخدم ألوان indigo/بنفسجي.

## صيغة الاستجابات
- نجاح: JSON مباشر (`{items: [...]}` أو `{ok: true}` أو الكيان).
- خطأ: `{"error": "رسالة عربية"}` مع status (401/403/400/404/429/500).

## نقاط النهاية

### المصادقة
- `POST /api/auth/login {email, password}` → `{user}`
- `POST /api/auth/logout`
- `GET /api/auth/me` → `{user, scopes, unread}` — scopes: Record<permKey, scope>

### المراحل/الفروع/المواد (structure.manage للتعديل)
- `GET /api/stages` → `{items: [{id, nameAr, level, branchesCount, studentsCount}]}`
- `POST /api/stages {nameAr, level}` → `{stage}`
- `PATCH /api/stages/{id} {nameAr?, level?}` — `DELETE /api/stages/{id}`
- `GET /api/branches?stageId=` → `{items: [{id, nameAr, stageId, stageName, subjectsCount, studentsCount}]}`
- `POST /api/branches {stageId, nameAr}` — `PATCH /api/branches/{id} {nameAr?}` — `DELETE /api/branches/{id}`
- `GET /api/subjects?branchId=` → `{items: [{id, code, nameAr, semester, branchId, branchName, stageId, stageName, instructors: [{id,name}], lecturesCount, sessionsCount}]}` (مفلترة بصلاحية lectures.read)
- `POST /api/subjects {branchId, code, nameAr, semester}` — `PATCH /api/subjects/{id} {nameAr?, code?, semester?, instructorIds?[]}` (يستبدل قائمة التدريسيين) — `DELETE /api/subjects/{id}`
- `GET /api/subjects/{id}` → `{subject: {...same + studentsCount}}`

### المحاضرات (lectures.*)
- `GET /api/lectures?subjectId=` → `{items: [{id, title, summary, contentMd, weekNo, type(THEORY|PRACTICAL), videoUrl, isPublished, files: [{id,name,url,mime,sizeBytes}], createdByName, createdById, createdAt}]}` (الطلاب يرون المنشور فقط)
- `POST /api/lectures {subjectId, title, summary?, contentMd?, weekNo?, type, videoUrl?, isPublished}`
- `PATCH /api/lectures/{id}` — `DELETE /api/lectures/{id}`
- `POST /api/files` multipart `{lectureId, file}` → `{file: {id,name,url,mime,sizeBytes}}` (حد 25MB، PDF/PPT/DOC/صور)
- `GET /api/files/{id}` تنزيل (الرابط مباشر في `<a href>`)

### الحضور
- `GET /api/attendance/sessions` → `{items: [{id, subjectId, subjectName, branchName, stageName, date, startsAt, endsAt, room, lateAfterMin, status(SCHEDULED|OPEN|CLOSED), total}]}`
- `POST /api/attendance/sessions {subjectId, date(yyyy-mm-dd), startTime(HH:mm), endTime, room?, lateAfterMin}` (التوقيت بتوقيت بغداد)
- `GET /api/attendance/sessions/{id}` → `{session: {...}, records: [{id, studentId, name, universityId, photoUrl, status, method, scannedAt, markedById, editedById, editedAt, note}]}`
- `POST /api/attendance/sessions/{id}/open` → `{ok, count}` (يُنشئ صفوف غياب للكل)
- `POST /api/attendance/sessions/{id}/close` → `{ok}`
- `POST /api/attendance/sessions/{id}/scan {action:"scan"|"manual"|"undo", payload?, studentId?}`:
  - scan: payload `QR1:...` أو `UID:202512001` → `{ok:true, duplicate, status, student:{name,universityId,photoUrl}}` أو `{ok:false, code, message}` (codes: SESSION_CLOSED, BAD_CODE, EXPIRED_OR_FORGED, NOT_FOUND, NOT_ENROLLED)
  - manual: `{studentId}` → نفس استجابة scan
  - undo: `{studentId}` → `{ok:true, undone:true, studentId}`
- `PATCH /api/attendance/records/{id} {status, note?, reason}` (سبب إلزامي ≥3 أحرف) → `{ok}`

### الطالب
- `GET /api/my/qr` → `{token, secondsLeft, step(30), staticCode:"UID:202512001", fullName, universityId, photoUrl}` — أعد الجلب كل مرة ينتهي العدّاد
- `GET /api/my/attendance` → `{subjects: [{subjectId, subjectName, branchName, stageName, sessions: [{id, date, status, note}], present, absent, late, excused, attendancePct, atRisk}]}`

### التبليغات
- `GET /api/announcements` → `{items: [{id, title, body, priority(NORMAL|IMPORTANT|URGENT), audienceType(ALL|STAGE|BRANCH|SUBJECT), stageName, branchName, subjectName, pinned, createdByName, createdById, publishedAt, expiresAt, isRead}]}`
- `POST /api/announcements {title, body, priority, audienceType, stageId?, branchId?, subjectId?, pinned}` → `{announcement, recipients}`
- `PATCH /api/announcements/{id}` — `DELETE /api/announcements/{id}`
- `POST /api/announcements/{id}/read`
- لقوائم الجمهور عند الإنشاء: `GET /api/stages` و `GET /api/branches?stageId=` و `GET /api/subjects?branchId=`

### التقارير والتصدير
- `GET /api/reports/attendance?subjectId=&from=&to=&student=` → `{subject: {nameAr,...}, sessions: [{id,date,room}], rows: [{no, id, name, universityId, cells[](status), cellSymbols[](✓ غ ت م), present, absent, late, excused, attendancePct, atRisk}]}`
- `GET /api/export/attendance?subjectId=` → ملف xlsx (تنزيل مباشر — استخدم window.open أو a[href])
- `POST /api/import/attendance` multipart `{subjectId, mode:"preview"|"apply", reason?, file}` → preview: `{preview: [{name, universityId, sessionDate, from, to}], errors[], symbols}` | apply: `{applied, errors[]}`

### الإدارة
- `GET /api/admin/users?q=&role=` → `{items: [{id, email, fullName, universityId, phone, photoUrl, isActive, roleKey, roleName, mustChangePassword, stageName, branchName, academicYear, subjects:[{id,name,code}], createdAt}]}`
- `POST /api/admin/users {fullName, email, password, roleKey, universityId?, phone?, stageId?, branchId?, academicYear?}` (المرحلة+الفرع إلزاميان للطلاب)
- `PATCH /api/admin/users/{id} {fullName?, phone?, roleKey?, isActive?, stageId?, branchId?, academicYear?, resetPassword?, regenerateQr?}` → `{ok, tempPassword?}`
- `DELETE /api/admin/users/{id}` → `{ok, deactivated?|deleted?}`
- `POST /api/admin/users/import` multipart `{file, mode:"preview"|"apply"}` — أعمدة Excel: الاسم الكامل، البريد الإلكتروني، الرقم الجامعي، الدور، المرحلة، الفرع، السنة الدراسية → preview: `{preview: [{fullName, email, universityId, roleKey, stageName, branchName, error?}], validCount}` | apply (multipart): `{created, preview}` | apply (JSON): `POST` body JSON `{rows: [...]}` → `{created, errors[]}`
- `GET /api/admin/permissions` → `{roles:[{id,key,nameAr}], permissions:[{key,group,nameAr}], scopes[], scopeLabels, matrix[roleKey][permKey]=scope, defaults, editableByRoles}`
- `PUT /api/admin/permissions [{roleId, permissionKey, scope}]` → `{ok, applied}` (رسائل أخطاء: لا يمكن سحب إدارة الصلاحيات من المالك؛ تعديل المصفوفة متاح للمالك فقط)
- `GET /api/admin/audit?limit=` → `{items: [{id, actorName, actorRole, action, entity, entityId, before, after, reason, ip, createdAt}]}`
- `GET /api/reports/dashboard` → حسب الدور (استُخدم في DashboardView)

## الواجهات المطلوبة (ملفات تُستبدل — نفس الأسماء والـ props)
- `src/components/app/views/academic/StagesView.tsx` — export function StagesView({stageId?: string})
- `src/components/app/views/academic/SubjectsView.tsx` — export function SubjectsView({branchId?: string})
- `src/components/app/views/academic/SubjectView.tsx` — export function SubjectView({subjectId: string})
- `src/components/app/views/attendance/SessionsView.tsx`
- `src/components/app/views/attendance/ScannerView.tsx` — export function ScannerView({sessionId: string})
- `src/components/app/views/attendance/ReportsView.tsx`
- `src/components/app/views/attendance/MyQrView.tsx`
- `src/components/app/views/attendance/MyAttendanceView.tsx`
- `src/components/app/views/announcements/AnnouncementsView.tsx`
- `src/components/app/views/admin/UsersView.tsx`
- `src/components/app/views/admin/PermissionsView.tsx`
- `src/components/app/views/admin/AuditView.tsx`
