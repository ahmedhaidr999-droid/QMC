// توليد أيقونات PWA من SVG — تشغيل: bun scripts/gen-icons.ts
import sharp from "sharp";
import { mkdirSync } from "fs";

mkdirSync("public/icons", { recursive: true });

// الشعار: قبعة تخرّج بيضاء على خلفية خضراء متدرجة
function svg(size: number, padding = 0) {
  const inner = size - padding * 2;
  const p = padding / size;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 1 1">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#16a34a"/>
      <stop offset="1" stop-color="#0d9488"/>
    </linearGradient>
  </defs>
  <rect width="1" height="1" rx="0.22" fill="url(#g)"/>
  <g transform="translate(${p}, ${p}) scale(${inner / size})" fill="none" stroke="#ffffff" stroke-width="0.045" stroke-linecap="round" stroke-linejoin="round">
    <path d="M 0.5 0.24 L 0.92 0.42 L 0.5 0.60 L 0.08 0.42 Z" fill="#ffffff"/>
    <path d="M 0.24 0.52 L 0.24 0.72 C 0.24 0.80 0.38 0.86 0.5 0.86 C 0.62 0.86 0.76 0.80 0.76 0.72 L 0.76 0.52"/>
    <path d="M 0.90 0.45 L 0.90 0.66"/>
  </g>
</svg>`;
}

async function gen(name: string, size: number, padding = 0) {
  await sharp(Buffer.from(svg(size, padding)))
    .resize(size, size)
    .png()
    .toFile(`public/icons/${name}`);
  console.log(`✔ public/icons/${name} (${size}x${size})`);
}

await gen("icon-192.png", 192);
await gen("icon-512.png", 512);
await gen("maskable-512.png", 512, 64); // هامش أمان للقناع
await gen("badge-72.png", 72);
await gen("apple-touch-icon.png", 180, 10);
console.log("✅ اكتملت الأيقونات");
