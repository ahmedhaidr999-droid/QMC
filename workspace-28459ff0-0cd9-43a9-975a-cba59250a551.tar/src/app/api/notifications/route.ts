// إشعارات داخل التطبيق — قائمة + تعليم الكل كمقروء
import { db } from "@/lib/db";
import { handle, requireAuth } from "@/lib/api";

export async function GET(req: Request) {
  return handle(async () => {
    const user = await requireAuth();
    const { searchParams } = new URL(req.url);
    const limit = Math.min(Number(searchParams.get("limit") ?? 20), 50);
    const items = await db.notification.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      take: limit,
    });
    const unread = items.filter((n) => !n.readAt).length;
    return Response.json({
      items: items.map((n) => ({
        id: n.id,
        title: n.title,
        body: n.body,
        url: n.url,
        readAt: n.readAt,
        createdAt: n.createdAt,
      })),
      unread,
    });
  });
}

export async function PATCH() {
  return handle(async () => {
    const user = await requireAuth();
    await db.notification.updateMany({
      where: { userId: user.id, readAt: null },
      data: { readAt: new Date() },
    });
    return Response.json({ ok: true });
  });
}
