// تعديل/حذف مرحلة — structure.manage
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requirePermission, writeAudit, getClientIp } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  nameAr: z.string().min(2).optional(),
  level: z.coerce.number().int().min(1).max(10).optional(),
});

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const actor = await requirePermission("structure.manage");
    const body = patchSchema.parse(await req.json());
    const before = await db.stage.findUnique({ where: { id } });
    if (!before) return Response.json({ error: "المرحلة غير موجودة" }, { status: 404 });
    const stage = await db.stage.update({ where: { id }, data: body });
    await writeAudit({
      actorId: actor.id,
      action: "structure.updateStage",
      entity: "Stage",
      entityId: id,
      before: { nameAr: before.nameAr, level: before.level },
      after: body,
      ip: getClientIp(req),
    });
    return Response.json({ stage });
  });
}

export async function DELETE(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const actor = await requirePermission("structure.manage");
    const before = await db.stage.findUnique({
      where: { id },
      include: { _count: { select: { students: true, branches: true } } },
    });
    if (!before) return Response.json({ error: "المرحلة غير موجودة" }, { status: 404 });
    if (before._count.students > 0) {
      return Response.json({ error: "لا يمكن حذف مرحلة تضم طلاباً" }, { status: 400 });
    }
    await db.stage.delete({ where: { id } });
    await writeAudit({
      actorId: actor.id,
      action: "structure.deleteStage",
      entity: "Stage",
      entityId: id,
      before: { nameAr: before.nameAr },
      ip: getClientIp(req),
    });
    return Response.json({ ok: true });
  });
}
