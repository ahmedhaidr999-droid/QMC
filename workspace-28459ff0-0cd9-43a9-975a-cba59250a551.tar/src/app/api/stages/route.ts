// المراحل — قائمة مع الإحصاءات + إنشاء (structure.manage)
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requireAuth, requirePermission, writeAudit, getClientIp } from "@/lib/api";
import { hasAny } from "@/lib/rbac";

export async function GET() {
  return handle(async () => {
    await requireAuth();
    const stages = await db.stage.findMany({
      orderBy: { level: "asc" },
      include: {
        _count: { select: { branches: true, students: true } },
      },
    });
    return Response.json({
      items: stages.map((s) => ({
        id: s.id,
        nameAr: s.nameAr,
        level: s.level,
        branchesCount: s._count.branches,
        studentsCount: s._count.students,
      })),
    });
  });
}

const createSchema = z.object({
  nameAr: z.string().min(2, "اسم المرحلة مطلوب"),
  level: z.coerce.number().int().min(1).max(10),
});

export async function POST(req: Request) {
  return handle(async () => {
    const actor = await requirePermission("structure.manage");
    if (!(await hasAny(actor, "structure.manage"))) {
      return Response.json({ error: "ليست لديك صلاحية" }, { status: 403 });
    }
    const body = createSchema.parse(await req.json());
    const exists = await db.stage.findUnique({ where: { level: body.level } });
    if (exists) return Response.json({ error: "رقم المرحلة مستخدم مسبقاً" }, { status: 400 });
    const stage = await db.stage.create({ data: body });
    await writeAudit({
      actorId: actor.id,
      action: "structure.createStage",
      entity: "Stage",
      entityId: stage.id,
      after: body,
      ip: getClientIp(req),
    });
    return Response.json({ stage });
  });
}
