// تغيير كلمة المرور — POST { currentPassword, newPassword }
// مسموح للمستخدم المطلوب منه تغيير كلمة المرور عند أول دخول (MUST_CHANGE_PASSWORD)
import { z } from "zod";
import { db } from "@/lib/db";
import { getSessionUser, hashPassword, verifyPassword } from "@/lib/auth";
import { handle, writeAudit, getClientIp } from "@/lib/api";

const bodySchema = z.object({
  currentPassword: z.string().min(1, "كلمة المرور الحالية مطلوبة"),
  newPassword: z.string().min(8, "كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل"),
});

export async function POST(req: Request) {
  return handle(async () => {
    const user = await getSessionUser();
    if (!user) return Response.json({ error: "غير مسجّل الدخول" }, { status: 401 });

    const body = bodySchema.parse(await req.json());
    const rec = await db.user.findUniqueOrThrow({ where: { id: user.id } });

    if (!(await verifyPassword(body.currentPassword, rec.passwordHash))) {
      return Response.json({ error: "كلمة المرور الحالية غير صحيحة" }, { status: 400 });
    }
    if (body.currentPassword === body.newPassword) {
      return Response.json({ error: "كلمة المرور الجديدة يجب أن تختلف عن الحالية" }, { status: 400 });
    }

    await db.user.update({
      where: { id: user.id },
      data: { passwordHash: await hashPassword(body.newPassword), mustChangePassword: false },
    });

    await writeAudit({
      actorId: user.id,
      action: "auth.changePassword",
      entity: "User",
      entityId: user.id,
      ip: getClientIp(req),
    });

    return Response.json({ ok: true });
  });
}
