// تسجيل الدخول — POST { email, password }
import { z } from "zod";
import { db } from "@/lib/db";
import { verifyPassword, createSession, loadUser } from "@/lib/auth";
import { handle, rateLimit, getClientIp } from "@/lib/api";

const bodySchema = z.object({
  email: z.string().email("بريد إلكتروني غير صالح"),
  password: z.string().min(1, "كلمة المرور مطلوبة"),
});

export async function POST(req: Request) {
  return handle(async () => {
    const ip = getClientIp(req);
    const body = bodySchema.parse(await req.json());
    // حد المحاولات: 5 في الدقيقة لكل (IP + بريد)
    rateLimit(`login:${ip}:${body.email}`, { max: 5, windowSec: 60 });

    const user = await db.user.findUnique({
      where: { email: body.email },
      include: { role: true },
    });

    // رسالة عامة لا تكشف وجود الحساب
    if (!user || !(await verifyPassword(body.password, user.passwordHash))) {
      return Response.json({ error: "البريد الإلكتروني أو كلمة المرور غير صحيحة" }, { status: 401 });
    }
    if (!user.isActive) {
      return Response.json({ error: "الحساب معطّل، راجع إدارة الكلية" }, { status: 403 });
    }

    await createSession(user.id);
    const full = await loadUser(user.id);
    return Response.json({ user: full });
  });
}
