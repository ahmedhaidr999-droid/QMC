// المستخدم الحالي + نطاقات صلاحياته (لعرض القوائم في الواجهة)
import { getSessionUser } from "@/lib/auth";
import { handle } from "@/lib/api";
import { db } from "@/lib/db";
import { PERMISSION_DEFS } from "@/lib/constants";
import { getScope } from "@/lib/rbac";

export async function GET() {
  return handle(async () => {
    const user = await getSessionUser();
    if (!user) return Response.json({ user: null }, { status: 401 });

    // نطاق كل صلاحية للمستخدم الحالي (تجاوز فردي > منح الدور)
    const scopes: Record<string, string> = {};
    await Promise.all(
      PERMISSION_DEFS.map(async (p) => {
        scopes[p.key] = await getScope(user, p.key);
      })
    );

    // عدد الإشعارات غير المقروءة
    const unread = await db.notification.count({ where: { userId: user.id, readAt: null } });

    return Response.json({ user, scopes, unread });
  });
}
