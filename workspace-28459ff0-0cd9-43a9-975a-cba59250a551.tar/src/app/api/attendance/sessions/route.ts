// جلسات الحضور — قائمة (بصلاحية attendance.view على المواد) + إنشاء (attendance.session.manage)
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requireAuth, requirePermission, writeAudit, getClientIp } from "@/lib/api";
import { sessionWhere } from "@/lib/rbac";

export async function GET(req: Request) {
  return handle(async () => {
    const user = await requireAuth();
    const { searchParams } = new URL(req.url);
    const subjectId = searchParams.get("subjectId");
    const items = await db.classSession.findMany({
      where: { AND: [await sessionWhere(user, "attendance.view"), subjectId ? { subjectId } : {}] },
      orderBy: { startsAt: "desc" },
      include: {
        subject: { include: { branch: { include: { stage: true } } } },
        _count: { select: { attendance: true } },
      },
      take: 100,
    });
    return Response.json({
      items: items.map((s) => {
        // إحصاءات سريعة
        return {
          id: s.id,
          subjectId: s.subjectId,
          subjectName: s.subject.nameAr,
          branchName: s.subject.branch.nameAr,
          stageName: s.subject.branch.stage.nameAr,
          date: s.date,
          startsAt: s.startsAt,
          endsAt: s.endsAt,
          room: s.room,
          lateAfterMin: s.lateAfterMin,
          status: s.status,
          total: s._count.attendance,
        };
      }),
    });
  });
}

const createSchema = z.object({
  subjectId: z.string().min(1, "المادة مطلوبة"),
  date: z.string().min(1, "التاريخ مطلوب"), // yyyy-mm-dd
  startTime: z.string().regex(/^\d{2}:\d{2}$/, "الوقت مطلوب"),
  endTime: z.string().regex(/^\d{2}:\d{2}$/, "وقت النهاية مطلوب"),
  room: z.string().optional().nullable(),
  lateAfterMin: z.coerce.number().int().min(0).max(120).default(15),
});

export async function POST(req: Request) {
  return handle(async () => {
    const body = createSchema.parse(await req.json());
    const subject = await db.subject.findUnique({
      where: { id: body.subjectId },
      include: { branch: true },
    });
    if (!subject) return Response.json({ error: "المادة غير موجودة" }, { status: 404 });

    const actor = await requirePermission("attendance.session.manage", {
      subjectId: subject.id,
      stageId: subject.branch.stageId,
    });

    // نبني التواريخ بتوقيت بغداد (UTC+3) — التخزين UTC
    const toUtc = (d: string, t: string) => {
      const [y, m, day] = d.split("-").map(Number);
      const [h, min] = t.split(":").map(Number);
      return new Date(Date.UTC(y, m - 1, day, h - 3, min));
    };
    const startsAt = toUtc(body.date, body.startTime);
    const endsAt = toUtc(body.date, body.endTime);
    if (endsAt <= startsAt) return Response.json({ error: "وقت النهاية يجب أن يكون بعد البداية" }, { status: 400 });

    const exists = await db.classSession.findUnique({
      where: { subjectId_startsAt: { subjectId: subject.id, startsAt } },
    });
    if (exists) return Response.json({ error: "توجد جلسة بنفس التاريخ والوقت لهذه المادة" }, { status: 400 });

    const session = await db.classSession.create({
      data: {
        subjectId: subject.id,
        date: startsAt,
        startsAt,
        endsAt,
        room: body.room || null,
        lateAfterMin: body.lateAfterMin,
        status: "SCHEDULED",
        createdById: actor.id,
      },
    });
    await writeAudit({
      actorId: actor.id,
      action: "attendance.createSession",
      entity: "ClassSession",
      entityId: session.id,
      after: { subjectId: subject.id, startsAt, endsAt },
      ip: getClientIp(req),
    });
    return Response.json({ session: { id: session.id } });
  });
}
