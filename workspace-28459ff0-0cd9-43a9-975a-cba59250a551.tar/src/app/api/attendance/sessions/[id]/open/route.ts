// فتح الجلسة — ينشئ صفوف "غائب" مسبقاً لكل طلاب فرع المادة فتصبح المصفوفة مكتملة وقابلة للتعديل
import { db } from "@/lib/db";
import { handle, requirePermission, writeAudit, getClientIp } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const session = await db.classSession.findUnique({
      where: { id },
      include: { subject: { include: { branch: true } } },
    });
    if (!session) return Response.json({ error: "الجلسة غير موجودة" }, { status: 404 });
    if (session.status === "OPEN") return Response.json({ error: "الجلسة مفتوحة مسبقاً" }, { status: 400 });

    const actor = await requirePermission("attendance.session.manage", {
      subjectId: session.subjectId,
      stageId: session.subject.branch.stageId,
    });

    // طلاب الفرع المسجّلون في هذه المادة (حالياً: كل طلاب الفرع)
    const students = await db.studentProfile.findMany({
      where: { branchId: session.subject.branchId },
      select: { userId: true },
    });

    // إنشاء صفوف الغياب الأولية (تجاهل الموجود)
    let created = 0;
    for (const s of students) {
      try {
        await db.attendance.create({
          data: { sessionId: session.id, studentId: s.userId },
        });
        created += 1;
      } catch {
        // الصف موجود مسبقاً
      }
    }

    await db.classSession.update({ where: { id: session.id }, data: { status: "OPEN" } });
    await writeAudit({
      actorId: actor.id,
      action: "attendance.openSession",
      entity: "ClassSession",
      entityId: session.id,
      after: { status: "OPEN", seeded: created },
      ip: getClientIp(req),
    });
    return Response.json({ ok: true, count: students.length });
  });
}
