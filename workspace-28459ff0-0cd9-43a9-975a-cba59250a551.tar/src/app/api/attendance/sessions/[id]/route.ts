// تفاصيل جلسة + سجلاتها (مصفوفة الحضور) — attendance.view على المادة
import { db } from "@/lib/db";
import { handle, requirePermission } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const session = await db.classSession.findUnique({
      where: { id },
      include: { subject: { include: { branch: { include: { stage: true } } } } },
    });
    if (!session) return Response.json({ error: "الجلسة غير موجودة" }, { status: 404 });

    await requirePermission("attendance.view", {
      subjectId: session.subjectId,
      branchId: session.subject.branchId,
      stageId: session.subject.branch.stageId,
    });

    // سجلات الجلسة مع معلومات الطلاب
    const records = await db.attendance.findMany({
      where: { sessionId: id },
      include: {
        student: {
          select: { id: true, fullName: true, universityId: true, photoUrl: true },
        },
      },
      orderBy: { student: { fullName: "asc" } },
    });

    return Response.json({
      session: {
        id: session.id,
        subjectId: session.subjectId,
        subjectName: session.subject.nameAr,
        branchName: session.subject.branch.nameAr,
        stageName: session.subject.branch.stage.nameAr,
        date: session.date,
        startsAt: session.startsAt,
        endsAt: session.endsAt,
        room: session.room,
        lateAfterMin: session.lateAfterMin,
        status: session.status,
        createdById: session.createdById,
      },
      records: records.map((r) => ({
        id: r.id,
        studentId: r.studentId,
        name: r.student.fullName,
        universityId: r.student.universityId,
        photoUrl: r.student.photoUrl,
        status: r.status,
        method: r.method,
        scannedAt: r.scannedAt,
        markedById: r.markedById,
        editedById: r.editedById,
        editedAt: r.editedAt,
        note: r.note,
      })),
    });
  });
}
