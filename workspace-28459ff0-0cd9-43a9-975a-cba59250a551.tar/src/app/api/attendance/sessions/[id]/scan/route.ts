// نقطة المسح — POST { action: "scan" | "manual" | "undo", payload?, studentId? }
// scan: QR1:<token> المتغيّر أو UID:<universityId> الثابت (يدعم قارئ USB)
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requirePermission, rateLimit, HttpError, writeAudit, getClientIp } from "@/lib/api";
import { parseToken, isValidMac } from "@/lib/attendance/qr-token";

type Ctx = { params: Promise<{ id: string }> };

const bodySchema = z.object({
  action: z.enum(["scan", "manual", "undo"]),
  payload: z.string().min(5).max(200).optional(),
  studentId: z.string().optional(),
});

// رسائل الأخطاء بأكواد لعرضها في الماسح
const fail = (code: string) => {
  const messages: Record<string, string> = {
    SESSION_CLOSED: "الجلسة غير مفتوحة",
    BAD_CODE: "باركود غير صالح",
    EXPIRED_OR_FORGED: "انتهت صلاحية الكود أو غير صحيح",
    NOT_FOUND: "الطالب غير موجود",
    NOT_ENROLLED: "الطالب غير مسجّل في هذه الجلسة",
    DUPLICATE: "تم تسجيل الحضور مسبقاً",
  };
  return { ok: false as const, code, message: messages[code] ?? "خطأ غير معروف" };
};

export async function POST(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id: sessionId } = await ctx.params;
    const body = bodySchema.parse(await req.json());

    const session = await db.classSession.findUnique({
      where: { id: sessionId },
      include: { subject: { include: { branch: true } } },
    });
    if (!session) return Response.json({ error: "الجلسة غير موجودة" }, { status: 404 });

    const actor = await requirePermission("attendance.scan", {
      subjectId: session.subjectId,
      stageId: session.subject.branch.stageId,
    });

    // ===== التراجع: إعادة الحالة إلى غائب =====
    if (body.action === "undo") {
      if (!body.studentId) throw new HttpError(400, "معرّف الطالب مطلوب");
      const rec = await db.attendance.findUnique({
        where: { sessionId_studentId: { sessionId, studentId: body.studentId } },
      });
      if (!rec) throw new HttpError(404, "السجل غير موجود");
      // من سجّل الحضور هو من يتراجع (أو من يملك تعديل الحضور)
      const canEdit = await requirePermission("attendance.edit", {
        subjectId: session.subjectId,
        stageId: session.subject.branch.stageId,
      }).catch(() => null);
      if (rec.markedById !== actor.id && !canEdit) {
        throw new HttpError(403, "لا يمكنك التراجع عن تسجيل لم تقم به");
      }
      await db.attendance.update({
        where: { id: rec.id },
        data: { status: "ABSENT", method: "MANUAL", scannedAt: null, markedById: actor.id },
      });
      return Response.json({ ok: true, undone: true, studentId: rec.studentId });
    }

    if (session.status !== "OPEN") return Response.json(fail("SESSION_CLOSED"), { status: 200 });

    // حد المسح: 120 عملية في الدقيقة لكل مسؤول
    rateLimit(`scan:${actor.id}`, { max: 120, windowSec: 60 });

    // ===== تحديد الطالب =====
    let student: { id: string; fullName: string; universityId: string | null; photoUrl: string | null; qrSecret: string | null } | null = null;
    let method: "QR_DYNAMIC" | "QR_STATIC" | "MANUAL" = "MANUAL";

    if (body.action === "scan" && body.payload) {
      if (body.payload.startsWith("QR1:")) {
        const t = parseToken(body.payload.slice(4));
        if (!t) return Response.json(fail("BAD_CODE"));
        student = await db.user.findUnique({
          where: { id: t.studentId },
          select: { id: true, fullName: true, universityId: true, photoUrl: true, qrSecret: true },
        });
        if (!student?.qrSecret || !isValidMac(student.qrSecret, student.id, t.w, t.mac)) {
          return Response.json(fail("EXPIRED_OR_FORGED"));
        }
        method = "QR_DYNAMIC";
      } else if (body.payload.startsWith("UID:")) {
        student = await db.user.findUnique({
          where: { universityId: body.payload.slice(4) },
          select: { id: true, fullName: true, universityId: true, photoUrl: true, qrSecret: true },
        });
        method = "QR_STATIC";
      } else {
        return Response.json(fail("BAD_CODE"));
      }
    } else if (body.action === "manual" && body.studentId) {
      student = await db.user.findUnique({
        where: { id: body.studentId },
        select: { id: true, fullName: true, universityId: true, photoUrl: true, qrSecret: true },
      });
    } else {
      return Response.json(fail("BAD_CODE"));
    }

    if (!student || !(await db.user.findUnique({ where: { id: student.id } }))?.isActive) {
      return Response.json(fail("NOT_FOUND"));
    }

    // هل الطالب مسجّل في هذه الجلسة؟ (سجله موجود لأن الجلسة فُتحت مسبقاً)
    const rec = await db.attendance.findUnique({
      where: { sessionId_studentId: { sessionId, studentId: student.id } },
    });
    if (!rec) return Response.json(fail("NOT_ENROLLED"));

    const info = { name: student.fullName, universityId: student.universityId, photoUrl: student.photoUrl };

    // منع التكرار
    if (rec.status !== "ABSENT") {
      return Response.json({ ok: true, duplicate: true, status: rec.status, student: info });
    }

    // حضور أو تأخير حسب lateAfterMin
    const now = new Date();
    const lateAt = new Date(session.startsAt.getTime() + session.lateAfterMin * 60_000);
    const status = now > lateAt ? "LATE" : "PRESENT";

    await db.attendance.update({
      where: { id: rec.id },
      data: { status, method, scannedAt: now, markedById: actor.id },
    });

    return Response.json({ ok: true, duplicate: false, status, student: info });
  });
}
