// إغلاق الجلسة — إيقاف المسح
import { db } from "@/lib/db";
import { handle, requirePermission, writeAudit, getClientIp } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const session = await db.classSession.findUnique({
      where: { id },
      include: { subject: { include: { branch: true } } },
    });
    if (!session) return Response.json({ error: "الجلسة غير موجودة" }, { status: 404 });

    const actor = await requirePermission("attendance.session.manage", {
      subjectId: session.subjectId,
      stageId: session.subject.branch.stageId,
    });

    await db.classSession.update({ where: { id }, data: { status: "CLOSED" } });
    await writeAudit({
      actorId: actor.id,
      action: "attendance.closeSession",
      entity: "ClassSession",
      entityId: session.id,
      after: { status: "CLOSED" },
      ip: getClientIp(req),
    });
    return Response.json({ ok: true });
  });
}
