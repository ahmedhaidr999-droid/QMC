// تعديل سجل حضور واحد — PATCH { status, note?, reason }
// السبب إلزامي ويسجَّل في سجل التدقيق
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requirePermission, writeAudit, getClientIp, HttpError } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

const bodySchema = z.object({
  status: z.enum(["PRESENT", "ABSENT", "LATE", "EXCUSED"]),
  note: z.string().max(500).optional().nullable(),
  reason: z.string().min(3, "سبب التعديل إلزامي"),
});

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const body = bodySchema.parse(await req.json());

    const rec = await db.attendance.findUnique({
      where: { id },
      include: { session: { include: { subject: { include: { branch: true } } } } },
    });
    if (!rec) return Response.json({ error: "السجل غير موجود" }, { status: 404 });

    const actor = await requirePermission("attendance.edit", {
      subjectId: rec.session.subjectId,
      stageId: rec.session.subject.branch.stageId,
    });

    if (rec.status === body.status && rec.note === (body.note ?? null)) {
      return Response.json({ ok: true, unchanged: true });
    }

    await db.attendance.update({
      where: { id },
      data: {
        status: body.status,
        note: body.note ?? null,
        method: "MANUAL",
        editedById: actor.id,
        editedAt: new Date(),
      },
    });

    // سجل تدقيق إلزامي مع السبب
    await writeAudit({
      actorId: actor.id,
      action: "attendance.edit",
      entity: "Attendance",
      entityId: id,
      before: { status: rec.status, note: rec.note },
      after: { status: body.status, note: body.note ?? null },
      reason: body.reason,
      ip: getClientIp(req),
    });

    return Response.json({ ok: true });
  });
}

export async function GET(_req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const rec = await db.attendance.findUnique({
      where: { id },
      include: { session: { include: { subject: { include: { branch: true } } } } },
    });
    if (!rec) throw new HttpError(404, "السجل غير موجود");
    return Response.json({ record: rec });
  });
}
