// اشتراك Web Push — POST حفظ / DELETE إلغاء
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requireAuth } from "@/lib/api";

const subSchema = z.object({
  endpoint: z.string().url("نقطة النهاية غير صالحة"),
  keys: z.object({
    p256dh: z.string().min(1),
    auth: z.string().min(1),
  }),
});

export async function POST(req: Request) {
  return handle(async () => {
    const user = await requireAuth();
    const body = subSchema.parse(await req.json());
    const userAgent = req.headers.get("user-agent") ?? null;

    await db.pushSubscription.upsert({
      where: { endpoint: body.endpoint },
      update: { userId: user.id, p256dh: body.keys.p256dh, auth: body.keys.auth, userAgent },
      create: {
        userId: user.id,
        endpoint: body.endpoint,
        p256dh: body.keys.p256dh,
        auth: body.keys.auth,
        userAgent,
      },
    });
    return Response.json({ ok: true });
  });
}

export async function DELETE(req: Request) {
  return handle(async () => {
    const user = await requireAuth();
    const { endpoint } = z.object({ endpoint: z.string().url() }).parse(await req.json());
    // نحذف فقط اشتراك المستخدم نفسه
    await db.pushSubscription.deleteMany({ where: { endpoint, userId: user.id } });
    return Response.json({ ok: true });
  });
}
