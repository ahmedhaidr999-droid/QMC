// إدارة المستخدمين — GET قائمة (users.manage) + POST إنشاء
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requirePermission, writeAudit, getClientIp } from "@/lib/api";
import { hashPassword } from "@/lib/auth";
import { generateQrSecret } from "@/lib/attendance/qr-token";
import { ROLE_KEYS } from "@/lib/constants";

export async function GET(req: Request) {
  return handle(async () => {
    await requirePermission("users.manage");
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim();
    const roleKey = searchParams.get("role");

    const role = roleKey ? await db.role.findUnique({ where: { key: roleKey } }) : null;

    const users = await db.user.findMany({
      where: {
        AND: [
          role ? { roleId: role.id } : {},
          q
            ? {
                OR: [
                  { fullName: { contains: q } },
                  { email: { contains: q } },
                  { universityId: { contains: q } },
                ],
              }
            : {},
        ],
      },
      orderBy: { createdAt: "desc" },
      take: 200,
      include: {
        role: true,
        studentProfile: { include: { stage: true, branch: true } },
        teaching: { include: { subject: true } },
      },
    });

    return Response.json({
      items: users.map((u) => ({
        id: u.id,
        email: u.email,
        fullName: u.fullName,
        universityId: u.universityId,
        phone: u.phone,
        photoUrl: u.photoUrl,
        isActive: u.isActive,
        roleKey: u.role.key,
        roleName: u.role.nameAr,
        mustChangePassword: u.mustChangePassword,
        stageName: u.studentProfile?.stage.nameAr ?? null,
        branchName: u.studentProfile?.branch.nameAr ?? null,
        academicYear: u.studentProfile?.academicYear ?? null,
        subjects: u.teaching.map((t) => ({ id: t.subject.id, name: t.subject.nameAr, code: t.subject.code })),
        createdAt: u.createdAt,
      })),
    });
  });
}

const createSchema = z.object({
  fullName: z.string().min(3, "الاسم الكامل مطلوب"),
  email: z.string().email("بريد غير صالح"),
  password: z.string().min(8, "كلمة المرور 8 أحرف على الأقل"),
  roleKey: z.enum(ROLE_KEYS),
  universityId: z.string().optional().nullable(),
  phone: z.string().optional().nullable(),
  stageId: z.string().optional().nullable(), // للطلاب
  branchId: z.string().optional().nullable(), // للطلاب
  academicYear: z.string().optional().nullable(),
});

export async function POST(req: Request) {
  return handle(async () => {
    const actor = await requirePermission("users.manage");
    const body = createSchema.parse(await req.json());

    const exists = await db.user.findUnique({ where: { email: body.email } });
    if (exists) return Response.json({ error: "البريد مستخدم مسبقاً" }, { status: 400 });
    if (body.universityId) {
      const uidExists = await db.user.findUnique({ where: { universityId: body.universityId } });
      if (uidExists) return Response.json({ error: "الرقم الجامعي مستخدم مسبقاً" }, { status: 400 });
    }

    const role = await db.role.findUnique({ where: { key: body.roleKey } });
    if (!role) return Response.json({ error: "الدور غير موجود" }, { status: 400 });

    const isStudent = body.roleKey === "STUDENT" || body.roleKey === "STUDENT_ADMIN";
    if (isStudent && (!body.stageId || !body.branchId)) {
      return Response.json({ error: "المرحلة والفرع مطلوبان لحساب الطالب" }, { status: 400 });
    }

    const user = await db.user.create({
      data: {
        fullName: body.fullName,
        email: body.email,
        passwordHash: await hashPassword(body.password),
        roleId: role.id,
        universityId: body.universityId || null,
        phone: body.phone || null,
        mustChangePassword: true,
        qrSecret: isStudent ? generateQrSecret() : null,
        studentProfile: isStudent
          ? { create: { stageId: body.stageId!, branchId: body.branchId!, academicYear: body.academicYear || "2025-2026" } }
          : undefined,
      },
    });

    await writeAudit({
      actorId: actor.id,
      action: "users.create",
      entity: "User",
      entityId: user.id,
      after: { email: body.email, roleKey: body.roleKey },
      ip: getClientIp(req),
    });

    return Response.json({ user: { id: user.id } });
  });
}
