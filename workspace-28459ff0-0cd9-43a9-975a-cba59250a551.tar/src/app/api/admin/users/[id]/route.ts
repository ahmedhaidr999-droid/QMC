// تعديل مستخدم / تعطيل / إعادة تعيين كلمة المرور
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requirePermission, writeAudit, getClientIp, HttpError } from "@/lib/api";
import { hashPassword } from "@/lib/auth";
import { generateQrSecret } from "@/lib/attendance/qr-token";
import { ROLE_KEYS } from "@/lib/constants";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  fullName: z.string().min(3).optional(),
  phone: z.string().optional().nullable(),
  roleKey: z.enum(ROLE_KEYS).optional(),
  isActive: z.boolean().optional(),
  stageId: z.string().optional().nullable(), // للطالب
  branchId: z.string().optional().nullable(),
  academicYear: z.string().optional().nullable(),
  resetPassword: z.boolean().optional(), // true → توليد كلمة مرور مؤقتة وإجبار تغييرها
  regenerateQr: z.boolean().optional(), // إبطال باركود الطالب القديم
});

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const actor = await requirePermission("users.manage");
    const body = patchSchema.parse(await req.json());

    const user = await db.user.findUnique({ where: { id }, include: { role: true, studentProfile: true } });
    if (!user) throw new HttpError(404, "المستخدم غير موجود");

    const before = {
      fullName: user.fullName,
      roleKey: user.role.key,
      isActive: user.isActive,
    };

    const data: Record<string, unknown> = {};
    if (body.fullName) data.fullName = body.fullName;
    if (body.phone !== undefined) data.phone = body.phone || null;
    if (body.isActive !== undefined) data.isActive = body.isActive;
    if (body.regenerateQr) data.qrSecret = generateQrSecret();

    // قيد لا يُكسر: لا يمكن تعطيل آخر حساب مالك نشط
    if (body.isActive === false && user.role.key === "OWNER") {
      const activeOwners = await db.user.count({ where: { role: { key: "OWNER" }, isActive: true } });
      if (activeOwners <= 1) throw new HttpError(400, "لا يمكن تعطيل آخر حساب مالك للنظام");
    }
    if (body.roleKey && body.roleKey !== user.role.key) {
      if (user.role.key === "OWNER") throw new HttpError(400, "لا يمكن تغيير دور حساب المالك");
      const role = await db.role.findUnique({ where: { key: body.roleKey } });
      if (!role) throw new HttpError(400, "الدور غير موجود");
      data.roleId = role.id;
      // إزالة الملف الطلابي عند التحول لدور غير طلابي
      if (!["STUDENT", "STUDENT_ADMIN"].includes(body.roleKey) && user.studentProfile) {
        await db.studentProfile.delete({ where: { userId: user.id } }).catch(() => {});
      }
    }

    let tempPassword: string | null = null;
    if (body.resetPassword) {
      tempPassword = `Cg${Math.random().toString(36).slice(2, 8)}!${Date.now() % 100}`;
      data.passwordHash = await hashPassword(tempPassword);
      data.mustChangePassword = true;
    }

    // تحديث الملف الطلابي
    if ((body.stageId || body.branchId || body.academicYear !== undefined) && (user.studentProfile || (body.stageId && body.branchId))) {
      if (user.studentProfile) {
        await db.studentProfile.update({
          where: { userId: user.id },
          data: {
            stageId: body.stageId ?? user.studentProfile.stageId,
            branchId: body.branchId ?? user.studentProfile.branchId,
            academicYear: body.academicYear ?? user.studentProfile.academicYear,
          },
        });
      } else {
        await db.studentProfile.create({
          data: {
            userId: user.id,
            stageId: body.stageId!,
            branchId: body.branchId!,
            academicYear: body.academicYear || "2025-2026",
          },
        });
        if (!user.qrSecret) data.qrSecret = generateQrSecret();
      }
    }

    if (Object.keys(data).length > 0) {
      await db.user.update({ where: { id }, data: data as never });
    }

    await writeAudit({
      actorId: actor.id,
      action: body.resetPassword ? "users.resetPassword" : "users.update",
      entity: "User",
      entityId: id,
      before,
      after: { ...body, password: body.resetPassword ? "[مؤقتة]" : undefined },
      ip: getClientIp(req),
    });

    return Response.json({ ok: true, tempPassword });
  });
}

// حذف ناعم غير متاح مباشرة — التعطيل عبر PATCH
export async function DELETE(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const actor = await requirePermission("users.manage");
    const user = await db.user.findUnique({ where: { id }, include: { role: true } });
    if (!user) throw new HttpError(404, "المستخدم غير موجود");
    if (user.role.key === "OWNER") throw new HttpError(400, "لا يمكن حذف حساب المالك");
    // حذف فعلي فقط إذا لا سجلات حضور له، وإلا تعطيل
    const attCount = await db.attendance.count({ where: { studentId: id } });
    if (attCount > 0) {
      await db.user.update({ where: { id }, data: { isActive: false } });
      await writeAudit({
        actorId: actor.id,
        action: "users.deactivate",
        entity: "User",
        entityId: id,
        before: { isActive: true },
        after: { isActive: false, reason: "لديه سجلات حضور — تم التعطيل بدل الحذف" },
        ip: getClientIp(req),
      });
      return Response.json({ ok: true, deactivated: true });
    }
    await db.user.delete({ where: { id } });
    await writeAudit({
      actorId: actor.id,
      action: "users.delete",
      entity: "User",
      entityId: id,
      before: { email: user.email },
      ip: getClientIp(req),
    });
    return Response.json({ ok: true, deleted: true });
  });
}
