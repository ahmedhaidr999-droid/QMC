// استيراد المستخدمين من Excel — POST multipart { file, mode: "preview" | "apply" }
// preview: تحليل ومعاينة مع أخطاء الصفوف — apply: إنشاء الصفوف الصالحة (JSON)
import { z } from "zod";
import ExcelJS from "exceljs";
import { db } from "@/lib/db";
import { handle, requirePermission, writeAudit, getClientIp } from "@/lib/api";
import { hashPassword } from "@/lib/auth";
import { generateQrSecret } from "@/lib/attendance/qr-token";
import { ROLE_KEYS } from "@/lib/constants";

type Row = {
  fullName: string;
  email: string;
  universityId: string | null;
  roleKey: string;
  stageName: string | null;
  branchName: string | null;
  academicYear: string | null;
  error?: string | null;
};

async function parseFile(buffer: Buffer): Promise<Row[]> {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buffer as unknown as ArrayBuffer);
  const ws = wb.worksheets[0];
  if (!ws) throw new Error("لا توجد أوراق في الملف");

  // تحديد أعمدة الرأس (يدعم العربية)
  const header = ws.getRow(1).values as unknown[];
  const colOf = (names: string[]) => {
    for (let i = 1; i < header.length; i++) {
      const h = String(header[i] ?? "").trim();
      if (names.includes(h)) return i;
    }
    return -1;
  };
  const nameCol = colOf(["الاسم الكامل", "الاسم", "Name"]);
  const emailCol = colOf(["البريد الإلكتروني", "Email"]);
  const uidCol = colOf(["الرقم الجامعي"]);
  const roleCol = colOf(["الدور"]);
  const stageCol = colOf(["المرحلة"]);
  const branchCol = colOf(["الفرع", "الفرع التدريسي"]);
  const yearCol = colOf(["السنة الدراسية"]);

  if (nameCol === -1 || emailCol === -1 || roleCol === -1) {
    throw new Error("أعمدة مطلوبة ناقصة: الاسم الكامل، البريد الإلكتروني، الدور");
  }

  const rows: Row[] = [];
  ws.eachRow((row, rowNo) => {
    if (rowNo === 1) return;
    const fullName = String(row.getCell(nameCol).value ?? "").trim();
    const email = String(row.getCell(emailCol).value ?? "").trim();
    if (!fullName && !email) return;
    rows.push({
      fullName,
      email,
      universityId: uidCol > 0 ? String(row.getCell(uidCol).value ?? "").trim() || null : null,
      roleKey: String(row.getCell(roleCol).value ?? "").trim(),
      stageName: stageCol > 0 ? String(row.getCell(stageCol).value ?? "").trim() || null : null,
      branchName: branchCol > 0 ? String(row.getCell(branchCol).value ?? "").trim() || null : null,
      academicYear: yearCol > 0 ? String(row.getCell(yearCol).value ?? "").trim() || null : null,
    });
  });
  return rows;
}

// تحقق من كل صف وإلحاق الأخطاء
async function validateRows(rows: Row[]) {
  const stages = await db.stage.findMany();
  const branches = await db.branch.findMany();
  const valid: Row[] = [];
  for (const r of rows) {
    r.error = null;
    if (r.fullName.length < 3) r.error = "الاسم قصير";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(r.email)) r.error = "بريد غير صالح";
    else if (!(ROLE_KEYS as readonly string[]).includes(r.roleKey)) r.error = `دور غير معروف (${r.roleKey})`;
    else {
      const isStudent = r.roleKey === "STUDENT" || r.roleKey === "STUDENT_ADMIN";
      if (isStudent) {
        const stage = stages.find((s) => s.nameAr === r.stageName);
        const branch = branches.find((b) => b.nameAr === r.branchName);
        if (!stage) r.error = "المرحلة غير موجودة";
        else if (!branch || branch.stageId !== stage.id) r.error = "الفرع غير موجود في المرحلة";
        else { (r as Row & { _stageId?: string; _branchId?: string })._stageId = stage.id; (r as Row & { _stageId?: string; _branchId?: string })._branchId = branch.id; }
      }
    }
    // التكرار داخل الملف
    if (!r.error && valid.some((v) => v.email === r.email)) r.error = "بريد مكرر في الملف";
    // التكرار مع قاعدة البيانات
    if (!r.error) {
      const exists = await db.user.findUnique({ where: { email: r.email } });
      if (exists) r.error = "البريد مستخدم مسبقاً";
      else if (r.universityId) {
        const uidExists = await db.user.findUnique({ where: { universityId: r.universityId } });
        if (uidExists) r.error = "الرقم الجامعي مستخدم مسبقاً";
      }
    }
    if (!r.error) valid.push(r);
  }
  return { rows, valid };
}

const applySchema = z.array(
  z.object({
    fullName: z.string().min(3),
    email: z.string().email(),
    universityId: z.string().nullable().optional(),
    roleKey: z.enum(ROLE_KEYS),
    stageId: z.string().nullable().optional(),
    branchId: z.string().nullable().optional(),
    academicYear: z.string().nullable().optional(),
  })
);

export async function POST(req: Request) {
  return handle(async () => {
    const actor = await requirePermission("users.manage");
    const contentType = req.headers.get("content-type") ?? "";

    // ===== وضع التطبيق: JSON =====
    if (contentType.includes("application/json")) {
      const body = applySchema.parse(await req.json());
      let created = 0;
      const errors: { email: string; error: string }[] = [];
      for (const r of body) {
        try {
          const role = await db.role.findUniqueOrThrow({ where: { key: r.roleKey } });
          const isStudent = r.roleKey === "STUDENT" || r.roleKey === "STUDENT_ADMIN";
          if (isStudent && (!r.stageId || !r.branchId)) throw new Error("بيانات المرحلة/الفرع ناقصة");
          // كلمة مرور مبدئية = الرقم الجامعي إن وجد وإلا مؤقتة
          const tempPass = r.universityId ? `Cg${r.universityId}@2025` : `Cg${Date.now().toString(36)}`;
          await db.user.create({
            data: {
              fullName: r.fullName,
              email: r.email,
              passwordHash: await hashPassword(tempPass),
              roleId: role.id,
              universityId: r.universityId || null,
              mustChangePassword: true,
              qrSecret: isStudent ? generateQrSecret() : null,
              studentProfile: isStudent
                ? { create: { stageId: r.stageId!, branchId: r.branchId!, academicYear: r.academicYear || "2025-2026" } }
                : undefined,
            },
          });
          created += 1;
        } catch (e) {
          errors.push({ email: r.email, error: e instanceof Error ? e.message : "خطأ" });
        }
      }
      await writeAudit({
        actorId: actor.id,
        action: "users.import",
        entity: "User",
        after: { created, failed: errors.length },
        ip: getClientIp(req),
      });
      return Response.json({ created, errors });
    }

    // ===== وضع المعاينة: ملف Excel =====
    const form = await req.formData();
    const mode = String(form.get("mode") ?? "preview");
    const file = form.get("file");
    if (!(file instanceof File)) return Response.json({ error: "الملف مطلوب" }, { status: 400 });

    const rows = await parseFile(Buffer.from(await file.arrayBuffer()));
    const { rows: validated, valid } = await validateRows(rows);

    if (mode === "apply") {
      const roleMap = new Map((await db.role.findMany()).map((r) => [r.key, r.id]));
      let created = 0;
      for (const r of valid) {
        try {
          const isStudent = r.roleKey === "STUDENT" || r.roleKey === "STUDENT_ADMIN";
          const tempPass = r.universityId ? `Cg${r.universityId}@2025` : `Cg${Date.now().toString(36)}`;
          await db.user.create({
            data: {
              fullName: r.fullName,
              email: r.email,
              passwordHash: await hashPassword(tempPass),
              roleId: roleMap.get(r.roleKey)!,
              universityId: r.universityId,
              mustChangePassword: true,
              qrSecret: isStudent ? generateQrSecret() : null,
              studentProfile: isStudent && (r as Row & { _stageId?: string })._stageId
                ? {
                    create: {
                      stageId: (r as Row & { _stageId?: string })._stageId!,
                      branchId: (r as Row & { _branchId?: string })._branchId!,
                      academicYear: r.academicYear || "2025-2026",
                    },
                  }
                : undefined,
            },
          });
          created += 1;
        } catch {
          r.error = "فشل الإنشاء";
        }
      }
      await writeAudit({
        actorId: actor.id,
        action: "users.import",
        entity: "User",
        after: { created },
        ip: getClientIp(req),
      });
      return Response.json({ created, preview: validated });
    }

    return Response.json({ preview: validated, validCount: valid.length });
  });
}
