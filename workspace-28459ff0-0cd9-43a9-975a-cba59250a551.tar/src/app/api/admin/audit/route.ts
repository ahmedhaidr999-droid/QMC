// سجل التدقيق — audit.view
import { db } from "@/lib/db";
import { handle, requirePermission } from "@/lib/api";

export async function GET(req: Request) {
  return handle(async () => {
    await requirePermission("audit.view");
    const { searchParams } = new URL(req.url);
    const action = searchParams.get("action");
    const limit = Math.min(Number(searchParams.get("limit") ?? 100), 300);

    const items = await db.auditLog.findMany({
      where: action ? { action } : {},
      orderBy: { createdAt: "desc" },
      take: limit,
      include: { actor: { select: { fullName: true, role: { select: { key: true } } } } },
    });

    return Response.json({
      items: items.map((a) => ({
        id: a.id,
        actorId: a.actorId,
        actorName: a.actor?.fullName ?? "—",
        actorRole: a.actor?.role?.key ?? "—",
        action: a.action,
        entity: a.entity,
        entityId: a.entityId,
        before: a.before ? safeParse(a.before) : null,
        after: a.after ? safeParse(a.after) : null,
        reason: a.reason,
        ip: a.ip,
        createdAt: a.createdAt,
      })),
    });
  });
}

function safeParse(s: string): unknown {
  try {
    return JSON.parse(s);
  } catch {
    return s;
  }
}
