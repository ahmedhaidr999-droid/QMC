// مصفوفة الصلاحيات — للمالك فقط (حسب AppSetting: permissions.editableByRoles)
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requireAuth, HttpError, writeAudit, getClientIp } from "@/lib/api";
import { can } from "@/lib/rbac";
import { invalidateRbacCache } from "@/lib/rbac";
import { PERMISSION_DEFS, SCOPES, SCOPE_LABELS, DEFAULT_MATRIX } from "@/lib/constants";
import { revalidatePath } from "next/cache";

async function assertCanEditMatrix(actorId: string) {
  // الإعداد يحدد أدواراً مسموح لها بتعديل المصفوفة (افتراضياً المالك فقط)
  const setting = await db.appSetting.findUnique({ where: { key: "permissions.editableByRoles" } });
  const allowedRoles: string[] = (() => {
    try {
      return JSON.parse(setting?.value ?? '["OWNER"]');
    } catch {
      return ["OWNER"];
    }
  })();
  const actor = await db.user.findUnique({ where: { id: actorId }, include: { role: true } });
  if (!actor || !allowedRoles.includes(actor.role.key)) {
    throw new HttpError(403, "تعديل مصفوفة الصلاحيات متاح للمالك فقط");
  }
  return actor;
}

export async function GET() {
  return handle(async () => {
    const actor = await requireAuth();
    // قراءة المصفوفة متاحة لمن يملك permissions.manage
    if (!(await can(actor, "permissions.manage"))) {
      throw new HttpError(403, "ليست لديك صلاحية");
    }
    const [roles, grants, setting] = await Promise.all([
      db.role.findMany({ orderBy: { key: "asc" } }),
      db.rolePermission.findMany({ include: { permission: true } }),
      db.appSetting.findUnique({ where: { key: "permissions.editableByRoles" } }),
    ]);

    // matrix[roleKey][permissionKey] = scope
    const matrix: Record<string, Record<string, string>> = {};
    for (const r of roles) matrix[r.key] = {};
    for (const g of grants) {
      const role = roles.find((r) => r.id === g.roleId);
      if (role) matrix[role.key][g.permission.key] = g.scope;
    }

    let editableByRoles: string[] = ["OWNER"];
    try {
      editableByRoles = JSON.parse(setting?.value ?? '["OWNER"]');
    } catch {}

    return Response.json({
      roles: roles.map((r) => ({ id: r.id, key: r.key, nameAr: r.nameAr })),
      permissions: PERMISSION_DEFS,
      scopes: SCOPES,
      scopeLabels: SCOPE_LABELS,
      matrix,
      defaults: DEFAULT_MATRIX,
      editableByRoles,
    });
  });
}

const putSchema = z.array(
  z.object({
    roleId: z.string(),
    permissionKey: z.string(),
    scope: z.enum(["NONE", "OWN", "ASSIGNED", "BRANCH", "STAGE", "ALL"]),
  })
);

export async function PUT(req: Request) {
  return handle(async () => {
    const actor = await requireAuth();
    if (!(await can(actor, "permissions.manage"))) {
      throw new HttpError(403, "ليست لديك صلاحية");
    }
    const full = await assertCanEditMatrix(actor.id);

    const changes = putSchema.parse(await req.json());
    if (changes.length === 0) throw new HttpError(400, "لا توجد تغييرات");

    const [roles, permissions] = await Promise.all([
      db.role.findMany(),
      db.permission.findMany(),
    ]);
    const roleByKey = new Map(roles.map((r) => [r.id, r]));
    const permByKey = new Map(permissions.map((p) => [p.key, p]));

    // ===== قيود لا تُكسر =====
    const ownerRole = roles.find((r) => r.key === "OWNER");
    if (
      ownerRole &&
      changes.some((c) => c.roleId === ownerRole.id && c.permissionKey === "permissions.manage" && c.scope !== "ALL")
    ) {
      throw new HttpError(400, "لا يمكن سحب صلاحية إدارة الصلاحيات من المالك");
    }

    // قبل التعديل (للسجل)
    const before = await db.rolePermission.findMany({ include: { permission: true } });

    // تطبيق التغييرات
    for (const c of changes) {
      const role = roleByKey.get(c.roleId);
      const perm = permByKey.get(c.permissionKey);
      if (!role || !perm) continue;

      if (c.scope === "NONE") {
        await db.rolePermission
          .deleteMany({ where: { roleId: c.roleId, permissionId: perm.id } })
          .catch(() => {});
      } else {
        await db.rolePermission.upsert({
          where: { roleId_permissionId: { roleId: c.roleId, permissionId: perm.id } },
          update: { scope: c.scope },
          create: { roleId: c.roleId, permissionId: perm.id, scope: c.scope },
        });
      }
    }

    // إبطال الكاش فوراً لينعكس التغيير على المستخدمين
    invalidateRbacCache();
    revalidatePath("/", "layout");

    await writeAudit({
      actorId: full.id,
      action: "permissions.update",
      entity: "RolePermission",
      before: before.map((b) => ({ roleId: b.roleId, key: b.permission.key, scope: b.scope })),
      after: changes,
      ip: getClientIp(req),
    });

    return Response.json({ ok: true, applied: changes.length });
  });
}
