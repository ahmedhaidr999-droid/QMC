// استيراد الحضور من Excel — POST multipart { file, subjectId, mode: "preview" | "apply", reason }
// preview: معاينة الفروقات (كان/صار) — apply: تطبيق التغييرات بـ method=EXCEL_IMPORT + سجل تدقيق لكل صف
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requirePermission, writeAudit, getClientIp, HttpError } from "@/lib/api";
import { parseAttendanceImport } from "@/lib/excel/attendance";
import { STATUS_SYMBOLS } from "@/lib/constants";

const REVERSE: Record<string, string> = {
  // الرموز العربية كما في التصدير
  "✓": "PRESENT", "ح": "PRESENT",
  "غ": "ABSENT",
  "ت": "LATE",
  "م": "EXCUSED",
  // وتُقبل الحالات الإنجليزية أيضاً (من ملفات معدّلة يدوياً)
  PRESENT: "PRESENT", ABSENT: "ABSENT", LATE: "LATE", EXCUSED: "EXCUSED",
};

export async function POST(req: Request) {
  return handle(async () => {
    const form = await req.formData();
    const subjectId = z.string().min(1).parse(form.get("subjectId"));
    const mode = String(form.get("mode") ?? "preview");
    const reason = String(form.get("reason") ?? "استيراد من Excel");
    const file = form.get("file");
    if (!(file instanceof File)) throw new HttpError(400, "الملف مطلوب");

    const subject = await db.subject.findUnique({
      where: { id: subjectId },
      include: { branch: { include: { stage: true } } },
    });
    if (!subject) throw new HttpError(404, "المادة غير موجودة");

    const actor = await requirePermission("attendance.import", {
      subjectId: subject.id,
      stageId: subject.branch.stageId,
    });

    const buffer = Buffer.from(await file.arrayBuffer());
    const parsed = await parseAttendanceImport(buffer);

    // مطابقة الرموز مع الحالات الحالية
    const sessions = await db.classSession.findMany({
      where: { subjectId },
      orderBy: { startsAt: "asc" },
    });
    if (parsed.sessions.length === 0) throw new HttpError(400, "لا توجد أعمدة تواريخ في الملف");

    // ربط أعمدة الملف بالجلسات: ندعم المطابقة بالفهرس ضمن نطاق عدد الجلسات
    const diffs: {
      universityId: string; name: string; sessionId: string; sessionDate: string;
      from: string; to: string; recordId: string;
    }[] = [];
    const errors: string[] = [];

    const profiles = await db.studentProfile.findMany({
      where: { branchId: subject.branchId },
      include: { user: { select: { id: true, fullName: true, universityId: true } } },
    });
    const byUid = new Map(profiles.filter((p) => p.user.universityId).map((p) => [p.user.universityId!, p.user.id]));
    const byName = new Map(profiles.map((p) => [p.user.fullName, p.user.id]));

    for (const row of parsed.rows) {
      const studentId = (row.universityId && byUid.get(row.universityId)) || byName.get(row.name);
      if (!studentId) {
        errors.push(`طالب غير موجود: ${row.name} (${row.universityId || "بدون رقم جامعي"})`);
        continue;
      }
      for (let j = 0; j < parsed.sessions.length; j++) {
        const cell = row.cells[j];
        if (cell == null || cell === "") continue;
        const newStatus = REVERSE[cell.trim()];
        if (!newStatus) {
          errors.push(`رمز غير معروف «${cell}» للطالب ${row.name}`);
          continue;
        }
        // مطابقة الجلسة بالفهرس
        const session = sessions[j];
        if (!session) continue;
        const rec = await db.attendance.findUnique({
          where: { sessionId_studentId: { sessionId: session.id, studentId } },
        });
        if (!rec) {
          errors.push(`لا يوجد سجل للطالب ${row.name} في جلسة ${parsed.sessions[j]}`);
          continue;
        }
        if (rec.status !== newStatus) {
          diffs.push({
            universityId: row.universityId || "—",
            name: row.name,
            sessionId: session.id,
            sessionDate: parsed.sessions[j],
            from: rec.status,
            to: newStatus,
            recordId: rec.id,
          });
        }
      }
    }

    if (mode === "apply") {
      let applied = 0;
      for (const d of diffs) {
        await db.attendance.update({
          where: { id: d.recordId },
          data: { status: d.to, method: "EXCEL_IMPORT", editedById: actor.id, editedAt: new Date(), note: reason },
        });
        await writeAudit({
          actorId: actor.id,
          action: "attendance.import",
          entity: "Attendance",
          entityId: d.recordId,
          before: { status: d.from },
          after: { status: d.to },
          reason,
          ip: getClientIp(req),
        });
        applied += 1;
      }
      return Response.json({ applied, errors, diffs: [] });
    }

    return Response.json({
      preview: diffs.map((d) => ({
        name: d.name,
        universityId: d.universityId,
        sessionDate: d.sessionDate,
        from: d.from,
        to: d.to,
      })),
      errors,
      symbols: STATUS_SYMBOLS,
    });
  });
}
