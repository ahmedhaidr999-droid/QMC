// التبليغات — قائمة (حسب جمهور المستخدم) + إنشاء مع بث الإشعارات
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requireAuth, requirePermission, writeAudit, getClientIp } from "@/lib/api";
import { can } from "@/lib/rbac";
import { broadcastAnnouncement } from "@/lib/push/server";

// التبليغات المرئية للمستخدم: الكل + مرحلته + فرعه + مواد فرعه
export async function GET(req: Request) {
  return handle(async () => {
    const user = await requireAuth();
    const { searchParams } = new URL(req.url);
    const limit = Math.min(Number(searchParams.get("limit") ?? 50), 100);

    const userBranchSubjectIds = user.branchId
      ? (await db.subject.findMany({ where: { branchId: user.branchId }, select: { id: true } })).map((s) => s.id)
      : [];

    const items = await db.announcement.findMany({
      where: {
        OR: [
          { audienceType: "ALL" },
          { audienceType: "STAGE", stageId: user.stageId ?? "__none__" },
          { audienceType: "BRANCH", branchId: user.branchId ?? "__none__" },
          { audienceType: "SUBJECT", subjectId: { in: userBranchSubjectIds } },
        ],
      },
      orderBy: [{ pinned: "desc" }, { publishedAt: "desc" }],
      take: limit,
      include: {
        createdBy: { select: { fullName: true } },
        reads: { where: { userId: user.id } },
        stage: { select: { nameAr: true } },
        branch: { select: { nameAr: true } },
        subject: { select: { nameAr: true } },
      },
    });

    return Response.json({
      items: items.map((a) => ({
        id: a.id,
        title: a.title,
        body: a.body,
        priority: a.priority,
        audienceType: a.audienceType,
        stageName: a.stage?.nameAr ?? null,
        branchName: a.branch?.nameAr ?? null,
        subjectName: a.subject?.nameAr ?? null,
        pinned: a.pinned,
        createdByName: a.createdBy.fullName,
        createdById: a.createdById,
        publishedAt: a.publishedAt,
        expiresAt: a.expiresAt,
        isRead: a.reads.length > 0,
      })),
    });
  });
}

const createSchema = z.object({
  title: z.string().min(3, "العنوان مطلوب"),
  body: z.string().min(3, "النص مطلوب"),
  priority: z.enum(["NORMAL", "IMPORTANT", "URGENT"]).default("NORMAL"),
  audienceType: z.enum(["ALL", "STAGE", "BRANCH", "SUBJECT"]),
  stageId: z.string().optional().nullable(),
  branchId: z.string().optional().nullable(),
  subjectId: z.string().optional().nullable(),
  pinned: z.boolean().default(false),
});

export async function POST(req: Request) {
  return handle(async () => {
    const body = createSchema.parse(await req.json());

    // التحقق من الجمهور والصلاحية عليه
    let resource: Parameters<typeof can>[2] = {};
    if (body.audienceType === "STAGE" && body.stageId) {
      const stage = await db.stage.findUnique({ where: { id: body.stageId } });
      if (!stage) return Response.json({ error: "المرحلة غير موجودة" }, { status: 400 });
      resource = { stageId: stage.id };
    } else if (body.audienceType === "BRANCH" && body.branchId) {
      const branch = await db.branch.findUnique({ where: { id: body.branchId } });
      if (!branch) return Response.json({ error: "الفرع غير موجود" }, { status: 400 });
      resource = { branchId: branch.id, stageId: branch.stageId };
    } else if (body.audienceType === "SUBJECT" && body.subjectId) {
      const subject = await db.subject.findUnique({ where: { id: body.subjectId } });
      if (!subject) return Response.json({ error: "المادة غير موجودة" }, { status: 400 });
      resource = { subjectId: subject.id, branchId: subject.branchId };
    }

    const actor = await requirePermission("announcements.create", resource);
    if (!(await can(actor, "announcements.create", resource))) {
      return Response.json({ error: "ليست لديك صلاحية على هذا الجمهور" }, { status: 403 });
    }

    const announcement = await db.announcement.create({
      data: {
        title: body.title,
        body: body.body,
        priority: body.priority,
        audienceType: body.audienceType,
        stageId: body.audienceType === "STAGE" ? body.stageId! : null,
        branchId: body.audienceType === "BRANCH" ? body.branchId! : null,
        subjectId: body.audienceType === "SUBJECT" ? body.subjectId! : null,
        pinned: body.pinned,
        createdById: actor.id,
      },
    });

    // بث الإشعارات (داخل التطبيق + Push) دون تعطيل الطلب عند فشلها
    const recipients = await broadcastAnnouncement(announcement).catch(() => 0);

    await writeAudit({
      actorId: actor.id,
      action: "announcements.create",
      entity: "Announcement",
      entityId: announcement.id,
      after: { title: body.title, audienceType: body.audienceType, recipients },
      ip: getClientIp(req),
    });

    return Response.json({ announcement, recipients });
  });
}
