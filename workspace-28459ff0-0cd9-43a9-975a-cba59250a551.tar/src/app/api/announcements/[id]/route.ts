// تعديل/حذف تبليغ — scoped (OWN للمنشئ، ASSIGNED لمواد التدريسي)
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requirePermission, writeAudit, getClientIp } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

function resourceOf(a: { audienceType: string; stageId: string | null; branchId: string | null; subjectId: string | null; createdById: string }) {
  return {
    ownerId: a.createdById,
    stageId: a.audienceType === "STAGE" && a.stageId ? a.stageId : undefined,
    branchId: a.audienceType === "BRANCH" && a.branchId ? a.branchId : undefined,
    subjectId: a.audienceType === "SUBJECT" && a.subjectId ? a.subjectId : undefined,
  };
}

const patchSchema = z.object({
  title: z.string().min(3).optional(),
  body: z.string().min(3).optional(),
  priority: z.enum(["NORMAL", "IMPORTANT", "URGENT"]).optional(),
  pinned: z.boolean().optional(),
  expiresAt: z.string().datetime().optional().nullable(),
});

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const a = await db.announcement.findUnique({ where: { id } });
    if (!a) return Response.json({ error: "التبليغ غير موجود" }, { status: 404 });

    const actor = await requirePermission("announcements.update", resourceOf(a));
    const body = patchSchema.parse(await req.json());
    const updated = await db.announcement.update({ where: { id }, data: body });
    await writeAudit({
      actorId: actor.id,
      action: "announcements.update",
      entity: "Announcement",
      entityId: id,
      before: { title: a.title, pinned: a.pinned },
      after: body,
      ip: getClientIp(req),
    });
    return Response.json({ announcement: { id: updated.id } });
  });
}

export async function DELETE(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const a = await db.announcement.findUnique({ where: { id } });
    if (!a) return Response.json({ error: "التبليغ غير موجود" }, { status: 404 });

    const actor = await requirePermission("announcements.delete", resourceOf(a));
    await db.announcement.delete({ where: { id } });
    await writeAudit({
      actorId: actor.id,
      action: "announcements.delete",
      entity: "Announcement",
      entityId: id,
      before: { title: a.title },
      ip: getClientIp(req),
    });
    return Response.json({ ok: true });
  });
}
