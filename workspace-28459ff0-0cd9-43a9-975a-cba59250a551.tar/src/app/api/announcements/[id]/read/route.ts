// تعليم التبليغ كمقروء — AnnouncementRead
import { db } from "@/lib/db";
import { handle, requireAuth } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(_req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const user = await requireAuth();
    await db.announcementRead
      .create({ data: { announcementId: id, userId: user.id } })
      .catch(() => {}); // موجود مسبقاً
    return Response.json({ ok: true });
  });
}
