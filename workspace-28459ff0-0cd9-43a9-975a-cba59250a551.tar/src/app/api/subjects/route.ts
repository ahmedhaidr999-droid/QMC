// المواد — قائمة (مفلترة بصلاحية lectures.read) + إنشاء (structure.manage)
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requireAuth, requirePermission, writeAudit, getClientIp } from "@/lib/api";
import { subjectWhere } from "@/lib/rbac";

export async function GET(req: Request) {
  return handle(async () => {
    const user = await requireAuth();
    const { searchParams } = new URL(req.url);
    const branchId = searchParams.get("branchId");
    const items = await db.subject.findMany({
      where: { AND: [await subjectWhere(user, "lectures.read"), branchId ? { branchId } : {}] },
      orderBy: { nameAr: "asc" },
      include: {
        branch: { include: { stage: true } },
        instructors: { include: { user: { select: { id: true, fullName: true } } } },
        _count: { select: { lectures: true, sessions: true } },
      },
    });
    return Response.json({
      items: items.map((s) => ({
        id: s.id,
        code: s.code,
        nameAr: s.nameAr,
        semester: s.semester,
        branchId: s.branchId,
        branchName: s.branch.nameAr,
        stageId: s.branch.stageId,
        stageName: s.branch.stage.nameAr,
        instructors: s.instructors.map((i) => ({ id: i.user.id, name: i.user.fullName })),
        lecturesCount: s._count.lectures,
        sessionsCount: s._count.sessions,
      })),
    });
  });
}

const createSchema = z.object({
  branchId: z.string().min(1, "الفرع مطلوب"),
  code: z.string().min(2, "رمز المادة مطلوب").max(20),
  nameAr: z.string().min(2, "اسم المادة مطلوب"),
  semester: z.coerce.number().int().min(1).max(2).default(1),
});

export async function POST(req: Request) {
  return handle(async () => {
    const actor = await requirePermission("structure.manage");
    const body = createSchema.parse(await req.json());
    const exists = await db.subject.findUnique({
      where: { branchId_code: { branchId: body.branchId, code: body.code } },
    });
    if (exists) return Response.json({ error: "رمز المادة مستخدم مسبقاً في هذا الفرع" }, { status: 400 });
    const subject = await db.subject.create({ data: body });
    await writeAudit({
      actorId: actor.id,
      action: "structure.createSubject",
      entity: "Subject",
      entityId: subject.id,
      after: body,
      ip: getClientIp(req),
    });
    return Response.json({ subject });
  });
}
