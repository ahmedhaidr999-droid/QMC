// تفاصيل/تعديل/حذف مادة — القراءة بصلاحية lectures.read، التعديل بـ structure.manage (يشمل إسناد التدريسيين)
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requirePermission, requireAuth, writeAudit, getClientIp } from "@/lib/api";
import { can } from "@/lib/rbac";

type Ctx = { params: Promise<{ id: string }> };

async function loadSubject(id: string) {
  return db.subject.findUnique({
    where: { id },
    include: {
      branch: { include: { stage: true } },
      instructors: { include: { user: { select: { id: true, fullName: true, email: true } } } },
      _count: { select: { lectures: true, sessions: true } },
    },
  });
}

export async function GET(_req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const user = await requireAuth();
    const s = await loadSubject(id);
    if (!s) return Response.json({ error: "المادة غير موجودة" }, { status: 404 });
    const allowed = await can(user, "lectures.read", {
      subjectId: s.id,
      branchId: s.branchId,
      stageId: s.branch.stageId,
    });
    if (!allowed) return Response.json({ error: "ليست لديك صلاحية" }, { status: 403 });
    return Response.json({
      subject: {
        id: s.id,
        code: s.code,
        nameAr: s.nameAr,
        semester: s.semester,
        branchId: s.branchId,
        branchName: s.branch.nameAr,
        stageId: s.branch.stageId,
        stageName: s.branch.stage.nameAr,
        instructors: s.instructors.map((i) => ({ id: i.user.id, name: i.user.fullName, email: i.user.email })),
        lecturesCount: s._count.lectures,
        sessionsCount: s._count.sessions,
        studentsCount: await db.studentProfile.count({ where: { branchId: s.branchId } }),
      },
    });
  });
}

const patchSchema = z.object({
  nameAr: z.string().min(2).optional(),
  code: z.string().min(2).max(20).optional(),
  semester: z.coerce.number().int().min(1).max(2).optional(),
  instructorIds: z.array(z.string()).optional(), // إسناد التدريسيين (يستبدل القائمة)
});

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const actor = await requirePermission("structure.manage");
    const body = patchSchema.parse(await req.json());
    const before = await loadSubject(id);
    if (!before) return Response.json({ error: "المادة غير موجودة" }, { status: 404 });

    const { instructorIds, ...fields } = body;
    if (instructorIds) {
      await db.subjectInstructor.deleteMany({ where: { subjectId: id } });
      for (const uid of instructorIds) {
        await db.subjectInstructor
          .create({ data: { subjectId: id, userId: uid } })
          .catch(() => {});
      }
    }
    const subject = await db.subject.update({ where: { id }, data: fields });
    await writeAudit({
      actorId: actor.id,
      action: "structure.updateSubject",
      entity: "Subject",
      entityId: id,
      before: { nameAr: before.nameAr, instructors: before.instructors.map((i) => i.user.fullName) },
      after: body,
      ip: getClientIp(req),
    });
    return Response.json({ subject });
  });
}

export async function DELETE(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const actor = await requirePermission("structure.manage");
    const before = await db.subject.findUnique({ where: { id }, include: { _count: { select: { sessions: true } } } });
    if (!before) return Response.json({ error: "المادة غير موجودة" }, { status: 404 });
    if (before._count.sessions > 0) {
      return Response.json({ error: "لا يمكن حذف مادة لديها جلسات حضور" }, { status: 400 });
    }
    await db.subject.delete({ where: { id } });
    await writeAudit({
      actorId: actor.id,
      action: "structure.deleteSubject",
      entity: "Subject",
      entityId: id,
      before: { nameAr: before.nameAr, code: before.code },
      ip: getClientIp(req),
    });
    return Response.json({ ok: true });
  });
}
