// لوحة التحكم — إحصائيات مخصصة لكل دور
import { db } from "@/lib/db";
import { handle, requireAuth } from "@/lib/api";
import { subjectWhere, hasAny } from "@/lib/rbac";
import { buildMatrix } from "@/lib/attendance/matrix";
import { ABSENCE_LIMIT_PCT } from "@/lib/constants";

export async function GET() {
  return handle(async () => {
    const user = await requireAuth();

    // ===== قسم الأرقام العامة (OWNER / DEAN) =====
    if (await hasAny(user, "users.manage")) {
      const [students, instructors, subjects, stages, branches, openSessions] = await Promise.all([
        db.user.count({ where: { role: { key: { in: ["STUDENT", "STUDENT_ADMIN"] } }, isActive: true } }),
        db.user.count({ where: { role: { key: "INSTRUCTOR" }, isActive: true } }),
        db.subject.count(),
        db.stage.count(),
        db.branch.count(),
        db.classSession.count({ where: { status: "OPEN" } }),
      ]);

      // نسبة الحضور العامة (آخر 30 جلسة)
      const recentSessions = await db.classSession.findMany({
        orderBy: { startsAt: "desc" },
        take: 30,
        select: { id: true },
      });
      const recs = await db.attendance.findMany({
        where: { sessionId: { in: recentSessions.map((s) => s.id) } },
        select: { status: true },
      });
      const overallPct = recs.length
        ? Math.round((recs.filter((r) => r.status === "PRESENT" || r.status === "LATE").length / recs.length) * 100)
        : null;

      // الطلاب المعرّضون للحرمان (أكثر من 25% غياباً)
      const atRisk = await computeAtRisk(null);

      const [announcements, edits] = await Promise.all([
        db.announcement.findMany({
          orderBy: { publishedAt: "desc" },
          take: 5,
          include: { createdBy: { select: { fullName: true } } },
        }),
        db.auditLog.findMany({
          where: { action: "attendance.edit" },
          orderBy: { createdAt: "desc" },
          take: 5,
          include: { actor: { select: { fullName: true } } },
        }),
      ]);

      return Response.json({
        role: user.roleKey,
        stats: {
          students, instructors, subjects, stages, branches, openSessions, overallPct,
          atRiskCount: atRisk.length,
        },
        atRisk: atRisk.slice(0, 8),
        announcements: announcements.map((a) => ({
          id: a.id, title: a.title, priority: a.priority, pinned: a.pinned,
          by: a.createdBy.fullName, at: a.publishedAt,
        })),
        recentEdits: edits.map((e) => ({
          id: e.id, by: e.actor.fullName, reason: e.reason, at: e.createdAt, entityId: e.entityId,
        })),
      });
    }

    // ===== قسم التدريسي =====
    if (user.roleKey === "INSTRUCTOR") {
      const mySubjects = await db.subject.findMany({
        where: await subjectWhere(user, "attendance.view"),
        include: { branch: { include: { stage: true } } },
      });
      const subjectIds = mySubjects.map((s) => s.id);

      // جلسات اليوم (بتوقيت بغداد)
      const nowB = new Date(Date.now() + 3 * 3600_000);
      const dayStartUtc = new Date(Date.UTC(nowB.getUTCFullYear(), nowB.getUTCMonth(), nowB.getUTCDate()) - 3 * 3600_000);
      const dayEndUtc = new Date(dayStartUtc.getTime() + 24 * 3600_000);
      const todaySessions = await db.classSession.findMany({
        where: { subjectId: { in: subjectIds }, startsAt: { gte: dayStartUtc, lt: dayEndUtc } },
        orderBy: { startsAt: "asc" },
        include: { subject: true, _count: { select: { attendance: true } } },
      });

      const recentLectures = await db.lecture.findMany({
        where: { subjectId: { in: subjectIds } },
        orderBy: { createdAt: "desc" },
        take: 5,
        include: { subject: true },
      });

      // تنبيهات الغياب لموادي
      const atRisk = await computeAtRisk(subjectIds);

      return Response.json({
        role: user.roleKey,
        stats: {
          subjectsCount: mySubjects.length,
          todaySessionsCount: todaySessions.length,
          atRiskCount: atRisk.length,
        },
        mySubjects: mySubjects.map((s) => ({
          id: s.id, nameAr: s.nameAr, code: s.code, branchName: s.branch.nameAr,
        })),
        todaySessions: todaySessions.map((s) => ({
          id: s.id, subjectName: s.subject.nameAr, startsAt: s.startsAt, status: s.status, room: s.room, total: s._count.attendance,
        })),
        recentLectures: recentLectures.map((l) => ({
          id: l.id, title: l.title, subjectName: l.subject.nameAr, createdAt: l.createdAt, isPublished: l.isPublished,
        })),
        atRisk: atRisk.slice(0, 6),
      });
    }

    // ===== قسم الطالب / الطالب المسؤول =====
    const myStageBranch = user.branchId
      ? await db.branch.findUnique({ where: { id: user.branchId }, include: { stage: true } })
      : null;

    // محاضرات مرحلتي الجديدة
    const stageSubjects = myStageBranch
      ? await db.subject.findMany({ where: { branchId: user.branchId! } })
      : [];
    const newLectures = await db.lecture.findMany({
      where: { subjectId: { in: stageSubjects.map((s) => s.id) }, isPublished: true },
      orderBy: { createdAt: "desc" },
      take: 5,
      include: { subject: true },
    });

    // تبليغاتي غير المقروءة
    const unreadAnn = await db.announcement.findMany({
      where: {
        reads: { none: { userId: user.id } },
        OR: [
          { audienceType: "ALL" },
          { audienceType: "STAGE", stageId: user.stageId ?? "__none__" },
          { audienceType: "BRANCH", branchId: user.branchId ?? "__none__" },
          { audienceType: "SUBJECT", subjectId: { in: stageSubjects.map((s) => s.id) } },
        ],
      },
      orderBy: { publishedAt: "desc" },
      take: 5,
    });

    // نسبة حضوري
    const myRecs = await db.attendance.findMany({ where: { studentId: user.id } });
    const present = myRecs.filter((r) => r.status === "PRESENT" || r.status === "LATE").length;
    const counted = myRecs.filter((r) => r.status !== "EXCUSED").length;
    const myPct = counted ? Math.round((present / counted) * 100) : null;

    return Response.json({
      role: user.roleKey,
      stats: {
        myAttendancePct: myPct,
        unreadAnnouncements: unreadAnn.length,
        newLecturesCount: newLectures.length,
        stageName: myStageBranch?.stage.nameAr ?? null,
        branchName: myStageBranch?.nameAr ?? null,
      },
      newLectures: newLectures.map((l) => ({
        id: l.id, title: l.title, subjectName: l.subject.nameAr, createdAt: l.createdAt,
      })),
      unreadAnnouncementsList: unreadAnn.map((a) => ({
        id: a.id, title: a.title, priority: a.priority, at: a.publishedAt,
      })),
    });
  });
}

// حساب الطلاب المعرّضين للحرمان (كلها أو لمواد محددة)
async function computeAtRisk(subjectIds: string[] | null) {
  const sessions = await db.classSession.findMany({
    where: subjectIds ? { subjectId: { in: subjectIds } } : {},
    orderBy: { startsAt: "desc" },
    take: 200,
    select: { id: true, subjectId: true },
  });
  if (sessions.length === 0) return [];

  const records = await db.attendance.findMany({
    where: { sessionId: { in: sessions.map((s) => s.id) } },
    include: {
      student: {
        include: { studentProfile: { include: { stage: true } } },
      },
    },
  });

  const byStudent = new Map<string, { name: string; uid: string | null; present: number; absent: number; excused: number }>();
  for (const r of records) {
    if (!byStudent.has(r.studentId)) {
      byStudent.set(r.studentId, { name: r.student.fullName, uid: r.student.universityId, present: 0, absent: 0, excused: 0 });
    }
    const s = byStudent.get(r.studentId)!;
    if (r.status === "PRESENT" || r.status === "LATE") s.present += 1;
    else if (r.status === "EXCUSED") s.excused += 1;
    else s.absent += 1;
  }

  const result: { id: string; name: string; uid: string | null; absent: number; pct: number }[] = [];
  for (const [id, s] of byStudent) {
    const counted = Math.max(s.present + s.absent, 1);
    const pct = Math.round((s.present / counted) * 100);
    if ((s.absent / counted) * 100 > ABSENCE_LIMIT_PCT) {
      result.push({ id, name: s.name, uid: s.uid, absent: s.absent, pct });
    }
  }
  return result.sort((a, b) => a.pct - b.pct);
}
