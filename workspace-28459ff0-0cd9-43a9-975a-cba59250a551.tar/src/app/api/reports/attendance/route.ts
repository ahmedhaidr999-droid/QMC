// تقرير الحضور — مصفوفة (طلاب × جلسات) لمادة مع فلترة فترة
import { db } from "@/lib/db";
import { handle, requirePermission } from "@/lib/api";
import { buildMatrix } from "@/lib/attendance/matrix";
import { ABSENCE_LIMIT_PCT } from "@/lib/constants";

export async function GET(req: Request) {
  return handle(async () => {
    const { searchParams } = new URL(req.url);
    const subjectId = searchParams.get("subjectId");
    if (!subjectId) return Response.json({ error: "معرّف المادة مطلوب" }, { status: 400 });
    const from = searchParams.get("from");
    const to = searchParams.get("to");
    const studentQuery = searchParams.get("student")?.trim();

    const subject = await db.subject.findUnique({
      where: { id: subjectId },
      include: { branch: { include: { stage: true } } },
    });
    if (!subject) return Response.json({ error: "المادة غير موجودة" }, { status: 404 });

    await requirePermission("attendance.view", {
      subjectId: subject.id,
      stageId: subject.branch.stageId,
    });

    // جلسات المادة مع فلترة الفترة
    const sessions = await db.classSession.findMany({
      where: {
        subjectId,
        ...(from || to
          ? {
              startsAt: {
                ...(from ? { gte: new Date(`${from}T00:00:00+03:00`) } : {}),
                ...(to ? { lte: new Date(`${to}T23:59:59+03:00`) } : {}),
              },
            }
          : {}),
      },
      orderBy: { startsAt: "asc" },
    });

    // طلاب الفرع (مع بحث اختياري)
    const students = (
      await db.studentProfile.findMany({
        where: { branchId: subject.branchId },
        include: { user: { select: { id: true, fullName: true, universityId: true } } },
      })
    )
      .map((sp) => ({ id: sp.user.id, fullName: sp.user.fullName, universityId: sp.user.universityId }))
      .filter((s) => !studentQuery || s.fullName.includes(studentQuery) || s.universityId?.includes(studentQuery))
      .sort((a, b) => a.fullName.localeCompare(b.fullName, "ar"));

    const records = await db.attendance.findMany({
      where: { sessionId: { in: sessions.map((s) => s.id) } },
    });

    const rows = buildMatrix(
      students,
      sessions.map((s) => ({ id: s.id, date: s.startsAt })),
      records.map((r) => ({ studentId: r.studentId, sessionId: r.sessionId, status: r.status as never })),
      ABSENCE_LIMIT_PCT
    );

    return Response.json({
      subject: { id: subject.id, nameAr: subject.nameAr, code: subject.code, branchName: subject.branch.nameAr, stageName: subject.branch.stage.nameAr },
      sessions: sessions.map((s) => ({ id: s.id, date: s.startsAt, room: s.room })),
      rows,
    });
  });
}
