// تصدير الحضور Excel — GET ?subjectId= (attendance.export)
import { db } from "@/lib/db";
import { handle, requirePermission } from "@/lib/api";
import { exportAttendanceXlsx } from "@/lib/excel/attendance";

export async function GET(req: Request) {
  return handle(async () => {
    const { searchParams } = new URL(req.url);
    const subjectId = searchParams.get("subjectId");
    if (!subjectId) return Response.json({ error: "معرّف المادة مطلوب" }, { status: 400 });

    const subject = await db.subject.findUnique({
      where: { id: subjectId },
      include: { branch: { include: { stage: true } } },
    });
    if (!subject) return Response.json({ error: "المادة غير موجودة" }, { status: 404 });

    await requirePermission("attendance.export", {
      subjectId: subject.id,
      stageId: subject.branch.stageId,
    });

    const [sessions, profiles, records] = await Promise.all([
      db.classSession.findMany({ where: { subjectId }, orderBy: { startsAt: "asc" } }),
      db.studentProfile.findMany({
        where: { branchId: subject.branchId },
        include: { user: { select: { id: true, fullName: true, universityId: true } } },
      }),
      db.attendance.findMany({ where: { sessionId: { in: (await db.classSession.findMany({ where: { subjectId }, select: { id: true } })).map((s) => s.id) } } }),
    ]);

    const students = profiles
      .map((sp) => ({ id: sp.user.id, fullName: sp.user.fullName, universityId: sp.user.universityId }))
      .sort((a, b) => a.fullName.localeCompare(b.fullName, "ar"));

    const buffer = await exportAttendanceXlsx({
      subjectName: `${subject.nameAr} (${subject.code}) — ${subject.branch.nameAr} / ${subject.branch.stage.nameAr}`,
      students,
      sessions: sessions.map((s) => ({ id: s.id, date: s.startsAt })),
      records: records.map((r) => ({ studentId: r.studentId, sessionId: r.sessionId, status: r.status as never })),
    });

    return new Response(new Uint8Array(buffer), {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="attendance-${subject.code}.xlsx"`,
      },
    });
  });
}
