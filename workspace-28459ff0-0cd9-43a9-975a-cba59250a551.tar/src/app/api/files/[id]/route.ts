// تنزيل ملف مرفق — التحقق من صلاحية القراءة على مادة المحاضرة قبل التقديم
import { stat } from "fs/promises";
import path from "path";
import { createReadStream } from "fs";
import { db } from "@/lib/db";
import { handle, requireAuth } from "@/lib/api";
import { can } from "@/lib/rbac";
import { ALLOWED_UPLOAD_MIME } from "@/lib/constants";

type Ctx = { params: Promise<{ id: string }> };
const UPLOAD_DIR = path.join(process.cwd(), "db", "uploads");

// تحويل Node stream إلى Response body
function toWeb(stream: NodeJS.ReadableStream) {
  return new ReadableStream({
    start(controller) {
      stream.on("data", (chunk) => controller.enqueue(chunk));
      stream.on("end", () => controller.close());
      stream.on("error", (err) => controller.error(err));
    },
    cancel() {
      (stream as unknown as { destroy: () => void }).destroy();
    },
  } as ConstructorParameters<typeof ReadableStream<Uint8Array>>[0]);
}

export async function GET(_req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    // الحماية من اجتياز المسار: الاسم مكوّن من حروف سداسية عشرية وامتداد فقط
    if (!/^[a-f0-9]{32}(\.[a-zA-Z0-9]{1,9})?$/.test(id)) {
      return Response.json({ error: "اسم ملف غير صالح" }, { status: 400 });
    }
    const filePath = path.join(UPLOAD_DIR, id);
    try {
      await stat(filePath);
    } catch {
      return Response.json({ error: "الملف غير موجود" }, { status: 404 });
    }

    // ابحث عن سجل الملف المرتبط بمحاضرة وتحقق من الصلاحية
    // (url ليس حقلاً فريداً في المخطط — findFirst بدل findUnique)
    const rec = await db.lectureFile.findFirst({ where: { url: `/api/files/${id}` } });
    if (rec) {
      const lecture = await db.lecture.findUnique({
        where: { id: rec.lectureId },
        include: { subject: { include: { branch: true } } },
      });
      if (lecture) {
        const user = await requireAuth();
        const allowed = await can(user, "lectures.read", {
          subjectId: lecture.subjectId,
          branchId: lecture.subject.branchId,
          stageId: lecture.subject.branch.stageId,
        });
        if (!allowed) return Response.json({ error: "ليست لديك صلاحية" }, { status: 403 });
      }
    }

    const mime = rec?.mime && ALLOWED_UPLOAD_MIME.includes(rec.mime) ? rec.mime : "application/octet-stream";
    const stream = createReadStream(filePath);
    return new Response(toWeb(stream), {
      headers: {
        "Content-Type": mime,
        "Content-Disposition": `inline; filename*=UTF-8''${encodeURIComponent(rec?.name ?? id)}`,
        "Cache-Control": "private, max-age=3600",
      },
    });
  });
}
