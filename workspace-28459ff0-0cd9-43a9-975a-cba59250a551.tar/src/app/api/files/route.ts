// رفع ملف مرفق بمحاضرة — multipart/form-data { file, lectureId }
import { randomBytes } from "crypto";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requirePermission, writeAudit, getClientIp } from "@/lib/api";
import { MAX_FILE_SIZE, ALLOWED_UPLOAD_MIME } from "@/lib/constants";

const UPLOAD_DIR = path.join(process.cwd(), "db", "uploads");

export async function POST(req: Request) {
  return handle(async () => {
    const form = await req.formData();
    const lectureId = z.string().min(1).parse(form.get("lectureId"));
    const file = form.get("file");

    if (!(file instanceof File)) {
      return Response.json({ error: "الملف مطلوب" }, { status: 400 });
    }
    // التحقق من النوع والحجم
    if (!ALLOWED_UPLOAD_MIME.includes(file.type)) {
      return Response.json({ error: `نوع الملف غير مدعوم (${file.type || "غير معروف"})` }, { status: 400 });
    }
    if (file.size > MAX_FILE_SIZE) {
      return Response.json({ error: "حجم الملف يتجاوز الحد الأقصى 25MB" }, { status: 400 });
    }

    const lecture = await db.lecture.findUnique({
      where: { id: lectureId },
      include: { subject: { include: { branch: true } } },
    });
    if (!lecture) return Response.json({ error: "المحاضرة غير موجودة" }, { status: 404 });

    // رفع الملف = تعديل على المحاضرة
    const actor = await requirePermission("lectures.update", {
      ownerId: lecture.createdById,
      subjectId: lecture.subjectId,
      stageId: lecture.subject.branch.stageId,
    });

    // اسم عشوائي آمن + تخزين خارج مجلد public
    const ext = path.extname(file.name).slice(0, 10) || ".bin";
    const storedName = `${randomBytes(16).toString("hex")}${ext}`;
    await mkdir(UPLOAD_DIR, { recursive: true });
    await writeFile(path.join(UPLOAD_DIR, storedName), Buffer.from(await file.arrayBuffer()));

    const rec = await db.lectureFile.create({
      data: {
        lectureId: lecture.id,
        name: file.name,
        url: `/api/files/${storedName}`,
        mime: file.type,
        sizeBytes: file.size,
      },
    });
    await writeAudit({
      actorId: actor.id,
      action: "files.upload",
      entity: "LectureFile",
      entityId: rec.id,
      after: { name: file.name, sizeBytes: file.size },
      ip: getClientIp(req),
    });
    return Response.json({ file: { id: rec.id, name: rec.name, url: rec.url, mime: rec.mime, sizeBytes: rec.sizeBytes } });
  });
}
