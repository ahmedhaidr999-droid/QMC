// باركود الطالب — QR المتغيّر + بيانات البطاقة الثابتة
import { db } from "@/lib/db";
import { handle, requireAuth, HttpError } from "@/lib/api";
import { can } from "@/lib/rbac";
import { makeStudentToken, secondsUntilNextWindow, generateQrSecret } from "@/lib/attendance/qr-token";

export async function GET() {
  return handle(async () => {
    const user = await requireAuth();
    if (!(await can(user, "qr.own.view", { ownerId: user.id }))) {
      throw new HttpError(403, "ليست لديك صلاحية");
    }
    const rec = await db.user.findUnique({ where: { id: user.id } });
    if (!rec) throw new HttpError(404, "المستخدم غير موجود");
    if (!rec.qrSecret) {
      // توليد السر إن لم يوجد (لحسابات الطلاب الجديدة)
      const secret = generateQrSecret();
      await db.user.update({ where: { id: user.id }, data: { qrSecret: secret } });
      rec.qrSecret = secret;
    }
    const token = makeStudentToken(user.id, rec.qrSecret);
    return Response.json({
      token,
      secondsLeft: secondsUntilNextWindow(),
      step: 30,
      // الباركود الثابت للبطاقة المطبوعة: UID:<الرقم الجامعي>
      staticCode: user.universityId ? `UID:${user.universityId}` : null,
      fullName: user.fullName,
      universityId: user.universityId,
      photoUrl: user.photoUrl,
    });
  });
}
