// سجل حضور الطالب نفسه — attendance.view بنطاق OWN
import { db } from "@/lib/db";
import { handle, requireAuth, HttpError } from "@/lib/api";
import { can } from "@/lib/rbac";
import { buildMatrix } from "@/lib/attendance/matrix";
import { ABSENCE_LIMIT_PCT } from "@/lib/constants";

export async function GET() {
  return handle(async () => {
    const user = await requireAuth();
    if (!(await can(user, "attendance.view", { ownerId: user.id }))) {
      throw new HttpError(403, "ليست لديك صلاحية");
    }

    // كل سجلات حضور الطالب مع بيانات الجلسات والمواد
    const records = await db.attendance.findMany({
      where: { studentId: user.id },
      include: {
        session: {
          include: { subject: { include: { branch: { include: { stage: true } } } } },
        },
      },
      orderBy: { session: { startsAt: "desc" } },
    });

    // تجميع حسب المادة
    const bySubject = new Map<
      string,
      {
        subjectId: string;
        subjectName: string;
        branchName: string;
        stageName: string;
        sessions: { id: string; date: Date; status: string; note: string | null }[];
      }
    >();
    for (const r of records) {
      const key = r.session.subjectId;
      if (!bySubject.has(key)) {
        bySubject.set(key, {
          subjectId: key,
          subjectName: r.session.subject.nameAr,
          branchName: r.session.subject.branch.nameAr,
          stageName: r.session.subject.branch.stage.nameAr,
          sessions: [],
        });
      }
      bySubject.get(key)!.sessions.push({
        id: r.session.id,
        date: r.session.date,
        status: r.status,
        note: r.note,
      });
    }

    const subjects = [...bySubject.values()].map((s) => {
      const rows = buildMatrix(
        [{ id: user.id, fullName: user.fullName }],
        s.sessions.map((x) => ({ id: x.id, date: x.date })),
        s.sessions.map((x) => ({ studentId: user.id, sessionId: x.id, status: x.status as never })),
        ABSENCE_LIMIT_PCT
      )[0];
      return {
        subjectId: s.subjectId,
        subjectName: s.subjectName,
        branchName: s.branchName,
        stageName: s.stageName,
        sessions: s.sessions,
        present: rows.present,
        absent: rows.absent,
        late: rows.late,
        excused: rows.excused,
        attendancePct: rows.attendancePct,
        atRisk: rows.atRisk,
      };
    });

    return Response.json({ subjects });
  });
}
