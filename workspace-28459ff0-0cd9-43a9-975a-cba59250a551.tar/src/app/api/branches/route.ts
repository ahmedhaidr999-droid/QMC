// الفروع التدريسية — إنشاء (structure.manage)
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requireAuth, requirePermission, writeAudit, getClientIp } from "@/lib/api";

export async function GET(req: Request) {
  return handle(async () => {
    await requireAuth();
    const { searchParams } = new URL(req.url);
    const stageId = searchParams.get("stageId");
    const branches = await db.branch.findMany({
      where: stageId ? { stageId } : undefined,
      orderBy: { nameAr: "asc" },
      include: { stage: true, _count: { select: { subjects: true, students: true } } },
    });
    return Response.json({
      items: branches.map((b) => ({
        id: b.id,
        nameAr: b.nameAr,
        stageId: b.stageId,
        stageName: b.stage.nameAr,
        subjectsCount: b._count.subjects,
        studentsCount: b._count.students,
      })),
    });
  });
}

const createSchema = z.object({
  stageId: z.string().min(1, "المرحلة مطلوبة"),
  nameAr: z.string().min(2, "اسم الفرع مطلوب"),
});

export async function POST(req: Request) {
  return handle(async () => {
    const actor = await requirePermission("structure.manage");
    const body = createSchema.parse(await req.json());
    const exists = await db.branch.findUnique({
      where: { stageId_nameAr: { stageId: body.stageId, nameAr: body.nameAr } },
    });
    if (exists) return Response.json({ error: "الفرع موجود مسبقاً في هذه المرحلة" }, { status: 400 });
    const branch = await db.branch.create({ data: body });
    await writeAudit({
      actorId: actor.id,
      action: "structure.createBranch",
      entity: "Branch",
      entityId: branch.id,
      after: body,
      ip: getClientIp(req),
    });
    return Response.json({ branch });
  });
}
