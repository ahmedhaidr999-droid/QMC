// تعديل/حذف فرع تدريسي — structure.manage
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requirePermission, writeAudit, getClientIp } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({ nameAr: z.string().min(2).optional() });

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const actor = await requirePermission("structure.manage");
    const body = patchSchema.parse(await req.json());
    const before = await db.branch.findUnique({ where: { id } });
    if (!before) return Response.json({ error: "الفرع غير موجود" }, { status: 404 });
    const branch = await db.branch.update({ where: { id }, data: body });
    await writeAudit({
      actorId: actor.id,
      action: "structure.updateBranch",
      entity: "Branch",
      entityId: id,
      before: { nameAr: before.nameAr },
      after: body,
      ip: getClientIp(req),
    });
    return Response.json({ branch });
  });
}

export async function DELETE(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const actor = await requirePermission("structure.manage");
    const before = await db.branch.findUnique({
      where: { id },
      include: { _count: { select: { students: true } } },
    });
    if (!before) return Response.json({ error: "الفرع غير موجود" }, { status: 404 });
    if (before._count.students > 0) {
      return Response.json({ error: "لا يمكن حذف فرع يضم طلاباً" }, { status: 400 });
    }
    await db.branch.delete({ where: { id } });
    await writeAudit({
      actorId: actor.id,
      action: "structure.deleteBranch",
      entity: "Branch",
      entityId: id,
      before: { nameAr: before.nameAr },
      ip: getClientIp(req),
    });
    return Response.json({ ok: true });
  });
}
