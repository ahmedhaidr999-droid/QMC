// المحاضرات — قائمة وإنشاء
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requireAuth, requirePermission, writeAudit, getClientIp } from "@/lib/api";
import { can, getScope } from "@/lib/rbac";

export async function GET(req: Request) {
  return handle(async () => {
    const user = await requireAuth();
    const { searchParams } = new URL(req.url);
    const subjectId = searchParams.get("subjectId");
    if (!subjectId) return Response.json({ error: "معرّف المادة مطلوب" }, { status: 400 });

    const subject = await db.subject.findUnique({
      where: { id: subjectId },
      include: { branch: true },
    });
    if (!subject) return Response.json({ error: "المادة غير موجودة" }, { status: 404 });

    const allowed = await can(user, "lectures.read", {
      subjectId: subject.id,
      branchId: subject.branchId,
      stageId: subject.branch.stageId,
    });
    if (!allowed) return Response.json({ error: "ليست لديك صلاحية" }, { status: 403 });

    const scope = await getScope(user, "lectures.read");
    const lectures = await db.lecture.findMany({
      where: {
        subjectId,
        // الطالب والطالب المسؤول لا يريان المحاضرات غير المنشورة
        ...(scope === "STAGE" ? { isPublished: true } : {}),
      },
      orderBy: [{ weekNo: "asc" }, { createdAt: "asc" }],
      include: { files: true },
    });
    // جلب أسماء المنشئين دفعة واحدة (لا توجد علاقة createdBy على النموذج)
    const creatorIds = [...new Set(lectures.map((l) => l.createdById))];
    const creators = creatorIds.length
      ? await db.user.findMany({ where: { id: { in: creatorIds } }, select: { id: true, fullName: true } })
      : [];
    const creatorMap = new Map(creators.map((u) => [u.id, u.fullName]));
    return Response.json({
      items: lectures.map((l) => ({
        id: l.id,
        title: l.title,
        summary: l.summary,
        weekNo: l.weekNo,
        type: l.type,
        videoUrl: l.videoUrl,
        isPublished: l.isPublished,
        contentMd: l.contentMd,
        files: l.files.map((f) => ({ id: f.id, name: f.name, url: f.url, mime: f.mime, sizeBytes: f.sizeBytes })),
        createdByName: creatorMap.get(l.createdById) ?? "—",
        createdById: l.createdById,
        createdAt: l.createdAt,
      })),
    });
  });
}

const createSchema = z.object({
  subjectId: z.string().min(1),
  title: z.string().min(3, "العنوان مطلوب"),
  summary: z.string().optional().nullable(),
  contentMd: z.string().optional().nullable(),
  weekNo: z.coerce.number().int().min(1).max(30).optional().nullable(),
  type: z.enum(["THEORY", "PRACTICAL"]).default("THEORY"),
  videoUrl: z.string().url("رابط غير صالح").optional().nullable().or(z.literal("")),
  isPublished: z.boolean().default(true),
});

export async function POST(req: Request) {
  return handle(async () => {
    const body = createSchema.parse(await req.json());
    const subject = await db.subject.findUnique({
      where: { id: body.subjectId },
      include: { branch: true },
    });
    if (!subject) return Response.json({ error: "المادة غير موجودة" }, { status: 404 });

    // التحقق من الصلاحية على مورد هذه المادة تحديداً
    const actor = await requirePermission("lectures.create", {
      subjectId: subject.id,
      stageId: subject.branch.stageId,
    });

    const lecture = await db.lecture.create({
      data: {
        subjectId: subject.id,
        title: body.title,
        summary: body.summary ?? null,
        contentMd: body.contentMd ?? null,
        weekNo: body.weekNo ?? null,
        type: body.type,
        videoUrl: body.videoUrl || null,
        isPublished: body.isPublished,
        createdById: actor.id,
      },
    });
    await writeAudit({
      actorId: actor.id,
      action: "lectures.create",
      entity: "Lecture",
      entityId: lecture.id,
      after: { title: body.title },
      ip: getClientIp(req),
    });
    return Response.json({ lecture });
  });
}
