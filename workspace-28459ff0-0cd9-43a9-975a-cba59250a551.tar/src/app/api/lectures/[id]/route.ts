// تفاصيل/تعديل/حذف محاضرة — scoped: OWN (المنشئ)، ASSIGNED (تدريسي المادة)، ALL
import { z } from "zod";
import { db } from "@/lib/db";
import { handle, requireAuth, requirePermission, writeAudit, getClientIp } from "@/lib/api";
import { can } from "@/lib/rbac";

type Ctx = { params: Promise<{ id: string }> };

async function loadLecture(id: string) {
  return db.lecture.findUnique({
    where: { id },
    include: {
      subject: { include: { branch: { include: { stage: true } } } },
      files: true,
    },
  });
}

function serialize(l: NonNullable<Awaited<ReturnType<typeof loadLecture>>>, creatorName: string) {
  return {
    id: l.id,
    subjectId: l.subjectId,
    subjectName: l.subject.nameAr,
    branchName: l.subject.branch.nameAr,
    stageId: l.subject.branch.stageId,
    stageName: l.subject.branch.stage.nameAr,
    title: l.title,
    summary: l.summary,
    contentMd: l.contentMd,
    weekNo: l.weekNo,
    type: l.type,
    videoUrl: l.videoUrl,
    isPublished: l.isPublished,
    files: l.files.map((f) => ({ id: f.id, name: f.name, url: f.url, mime: f.mime, sizeBytes: f.sizeBytes })),
    createdById: l.createdById,
    createdByName: creatorName,
    createdAt: l.createdAt,
    updatedAt: l.updatedAt,
  };
}

export async function GET(_req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const user = await requireAuth();
    const l = await loadLecture(id);
    if (!l) return Response.json({ error: "المحاضرة غير موجودة" }, { status: 404 });
    const allowed = await can(user, "lectures.read", {
      subjectId: l.subjectId,
      branchId: l.subject.branchId,
      stageId: l.subject.branch.stageId,
    });
    if (!allowed) return Response.json({ error: "ليست لديك صلاحية" }, { status: 403 });
    // الطلاب لا يرون غير المنشورة
    const scopeRead = await can(user, "lectures.create", { subjectId: l.subjectId, stageId: l.subject.branch.stageId });
    if (!l.isPublished && !scopeRead) return Response.json({ error: "المحاضرة غير منشورة" }, { status: 403 });
    const creator = await db.user.findUnique({ where: { id: l.createdById }, select: { fullName: true } });
    return Response.json({ lecture: serialize(l, creator?.fullName ?? "—") });
  });
}

const patchSchema = z.object({
  title: z.string().min(3).optional(),
  summary: z.string().optional().nullable(),
  contentMd: z.string().optional().nullable(),
  weekNo: z.coerce.number().int().min(1).max(30).optional().nullable(),
  type: z.enum(["THEORY", "PRACTICAL"]).optional(),
  videoUrl: z.string().url("رابط غير صالح").optional().nullable().or(z.literal("")),
  isPublished: z.boolean().optional(),
});

export async function PATCH(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const l = await loadLecture(id);
    if (!l) return Response.json({ error: "المحاضرة غير موجودة" }, { status: 404 });
    // المورد: منشئ المحاضرة (OWN) + المادة (ASSIGNED) + المرحلة (STAGE)
    const actor = await requirePermission("lectures.update", {
      ownerId: l.createdById,
      subjectId: l.subjectId,
      stageId: l.subject.branch.stageId,
    });
    const body = patchSchema.parse(await req.json());
    const before = { title: l.title, isPublished: l.isPublished, weekNo: l.weekNo };
    const updated = await db.lecture.update({
      where: { id },
      data: {
        ...body,
        videoUrl: body.videoUrl === undefined ? undefined : body.videoUrl || null,
      },
    });
    await writeAudit({
      actorId: actor.id,
      action: "lectures.update",
      entity: "Lecture",
      entityId: id,
      before,
      after: body,
      ip: getClientIp(req),
    });
    return Response.json({ lecture: { id: updated.id } });
  });
}

export async function DELETE(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { id } = await ctx.params;
    const l = await loadLecture(id);
    if (!l) return Response.json({ error: "المحاضرة غير موجودة" }, { status: 404 });
    const actor = await requirePermission("lectures.delete", {
      ownerId: l.createdById,
      subjectId: l.subjectId,
      stageId: l.subject.branch.stageId,
    });
    await db.lecture.delete({ where: { id } });
    await writeAudit({
      actorId: actor.id,
      action: "lectures.delete",
      entity: "Lecture",
      entityId: id,
      before: { title: l.title },
      ip: getClientIp(req),
    });
    return Response.json({ ok: true });
  });
}
