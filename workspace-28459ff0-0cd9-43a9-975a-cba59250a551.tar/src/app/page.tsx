"use client";
// الصفحة الرئيسية — تطبيق صفحة واحدة (SPA) على مسار واحد
// التنقل عبر الـ hash: #/dashboard ، #/stages/<id> ، #/subjects/<id> ...

import { useEffect } from "react";
import { useApp, useHashRoute } from "@/lib/client/store";
import { AppShell } from "@/components/app/AppShell";
import { LoginView } from "@/components/app/views/core/LoginView";
import { ChangePasswordView } from "@/components/app/views/core/ChangePasswordView";
import { DashboardView } from "@/components/app/views/core/DashboardView";
import { SettingsView } from "@/components/app/views/core/SettingsView";
import { StagesView } from "@/components/app/views/academic/StagesView";
import { SubjectsView } from "@/components/app/views/academic/SubjectsView";
import { SubjectView } from "@/components/app/views/academic/SubjectView";
import { SessionsView } from "@/components/app/views/attendance/SessionsView";
import { ScannerView } from "@/components/app/views/attendance/ScannerView";
import { ReportsView } from "@/components/app/views/attendance/ReportsView";
import { MyQrView } from "@/components/app/views/attendance/MyQrView";
import { MyAttendanceView } from "@/components/app/views/attendance/MyAttendanceView";
import { AnnouncementsView } from "@/components/app/views/announcements/AnnouncementsView";
import { UsersView } from "@/components/app/views/admin/UsersView";
import { PermissionsView } from "@/components/app/views/admin/PermissionsView";
import { AuditView } from "@/components/app/views/admin/AuditView";
import { Providers } from "@/components/app/Providers";
import { GraduationCap, Loader2 } from "lucide-react";

export default function Page() {
  return (
    <Providers>
      <AppRoot />
    </Providers>
  );
}

function AppRoot() {
  const { user, loadingMe, fetchMe } = useApp();
  const { segments } = useHashRoute();

  // جلب الجلسة عند أول تحميل
  useEffect(() => {
    fetchMe();
  }, [fetchMe]);

  // ===== شاشة تحميل أولية =====
  if (loadingMe) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 bg-surface">
        <div className="p-5 rounded-3xl brand-gradient text-white shadow-lg">
          <GraduationCap className="w-14 h-14" />
        </div>
        <div className="flex items-center gap-2 text-muted-foreground">
          <Loader2 className="w-4 h-4 animate-spin" />
          <p className="text-sm">جارٍ تحميل نظام إدارة الكلية...</p>
        </div>
      </div>
    );
  }

  // ===== غير مسجّل → شاشة الدخول =====
  if (!user) return <LoginView />;

  // ===== إجبار تغيير كلمة المرور عند أول دخول =====
  if (user.mustChangePassword) return <ChangePasswordView />;

  // ===== التطبيق الرئيسي =====
  return (
    <AppShell>
      <Router segments={segments} />
    </AppShell>
  );
}

// الموجّه — يحدد الواجهة من مقاطع المسار
function Router({ segments }: { segments: string[] }) {
  const [root, a, _b] = segments;

  switch (root) {
    case "stages":
      // #/stages → قائمة المراحل | #/stages/<id> → فروع المرحلة
      return <StagesView key={a ?? "all"} stageId={a} />;
    case "branches":
      // #/branches/<id> → مواد الفرع
      return <SubjectsView key={a ?? "all"} branchId={a} />;
    case "subjects":
      // #/subjects/<id> → صفحة المادة (تبويبات)
      return a ? <SubjectView key={a} subjectId={a} /> : <DashboardView />;
    case "attendance":
      return <SessionsView />;
    case "scan":
      // #/scan/<sessionId> → الماسح
      return a ? <ScannerView key={a} sessionId={a} /> : <SessionsView />;
    case "reports":
      return <ReportsView />;
    case "my-qr":
      return <MyQrView />;
    case "my-attendance":
      return <MyAttendanceView />;
    case "announcements":
      return <AnnouncementsView />;
    case "admin-users":
      return <UsersView />;
    case "admin-permissions":
      return <PermissionsView />;
    case "admin-audit":
      return <AuditView />;
    case "settings":
      return <SettingsView />;
    default:
      return <DashboardView />;
  }
}
