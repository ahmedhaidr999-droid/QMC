"use client";
// الهيكل الرئيسي: شريط جانبي (حاسوب) + شريط سفلي (هاتف) + هيدر + جرس الإشعارات
import { useState, type ReactNode } from "react";
import { useApp, navigate, useHashRoute } from "@/lib/client/store";
import { NotificationBell } from "./shared/NotificationBell";
import { PwaProvider } from "./shared/PwaBits";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  LayoutDashboard, GraduationCap, CalendarCheck, Megaphone, QrCode, ClipboardList,
  Users, ShieldCheck, ScrollText, Settings, LogOut, Menu, BarChart3,
} from "lucide-react";
import { cn } from "@/lib/utils";

// عناصر التنقل — تظهر حسب الصلاحية (إخفاء تجميلي فقط؛ الحماية في السيرفر)
type NavItem = { key: string; path: string; label: string; icon: ReactNode; show: (scopes: Record<string, string>, roleKey: string) => boolean };

const NAV_ITEMS: NavItem[] = [
  { key: "dashboard", path: "/dashboard", label: "الرئيسية", icon: <LayoutDashboard className="w-5 h-5" />, show: () => true },
  { key: "stages", path: "/stages", label: "المراحل", icon: <GraduationCap className="w-5 h-5" />, show: () => true },
  { key: "attendance", path: "/attendance", label: "الحضور", icon: <CalendarCheck className="w-5 h-5" />, show: (s) => (s["attendance.view"] ?? "NONE") !== "NONE" && (s["qr.own.view"] ?? "NONE") === "NONE" },
  { key: "my-qr", path: "/my-qr", label: "باركودي", icon: <QrCode className="w-5 h-5" />, show: (s) => (s["qr.own.view"] ?? "NONE") !== "NONE" },
  { key: "my-attendance", path: "/my-attendance", label: "حضوري", icon: <ClipboardList className="w-5 h-5" />, show: (s) => (s["qr.own.view"] ?? "NONE") !== "NONE" },
  { key: "announcements", path: "/announcements", label: "التبليغات", icon: <Megaphone className="w-5 h-5" />, show: (s) => (s["announcements.read"] ?? "NONE") !== "NONE" },
  { key: "reports", path: "/reports", label: "تقارير الحضور", icon: <BarChart3 className="w-5 h-5" />, show: (s) => (s["reports.view"] ?? "NONE") !== "NONE" },
  { key: "admin-users", path: "/admin-users", label: "المستخدمون", icon: <Users className="w-5 h-5" />, show: (s) => (s["users.manage"] ?? "NONE") !== "NONE" },
  { key: "admin-permissions", path: "/admin-permissions", label: "الصلاحيات", icon: <ShieldCheck className="w-5 h-5" />, show: (s) => (s["permissions.manage"] ?? "NONE") !== "NONE" },
  { key: "admin-audit", path: "/admin-audit", label: "سجل التدقيق", icon: <ScrollText className="w-5 h-5" />, show: (s) => (s["audit.view"] ?? "NONE") !== "NONE" },
];

const ADMIN_GROUP = ["admin-users", "admin-permissions", "admin-audit"];

export function AppShell({ children }: { children: ReactNode }) {
  const { user, scopes, logout } = useApp();
  const { segments } = useHashRoute();
  const [menuOpen, setMenuOpen] = useState(false);
  if (!user) return null;

  const visible = NAV_ITEMS.filter((i) => i.show(scopes, user.roleKey));
  const mainNav = visible.filter((i) => !ADMIN_GROUP.includes(i.key));
  const adminNav = visible.filter((i) => ADMIN_GROUP.includes(i.key));
  const active = segments[0] ?? "dashboard";

  const initials = user.fullName.split(" ").slice(0, 2).map((w) => w[0]).join("");

  return (
    <div className="min-h-screen flex flex-col bg-surface">
      {/* ===== الهيدر ===== */}
      <header className="header-gradient text-white sticky top-0 z-40 shadow-md">
        <div className="flex items-center gap-2 sm:gap-3 px-4 h-16 max-w-7xl mx-auto w-full">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden p-2"
            onClick={() => setMenuOpen(true)}
            aria-label="القائمة"
          >
            <Menu className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-2.5 flex-1 min-w-0">
            <img src="/icons/icon-192.png" alt="" className="w-8 h-8 rounded-lg hidden sm:block" />
            <div className="min-w-0">
              <p className="font-extrabold leading-tight truncate">نظام إدارة الكلية</p>
              <p className="text-[11px] sm:text-xs text-white/80 truncate">{user.roleName} — {user.fullName}</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <div className="[&_button]:text-white [&_button:hover]:bg-white/15">
              <NotificationBell />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="rounded-full focus:outline-none focus-visible:ring-2 ring-white/70" aria-label="قائمة الحساب">
                  <Avatar className="w-9 h-9 border-2 border-white/40">
                    {user.photoUrl ? (
                      <img src={user.photoUrl} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <AvatarFallback className="bg-white/20 text-white text-sm font-bold">{initials}</AvatarFallback>
                    )}
                  </Avatar>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <p className="font-bold">{user.fullName}</p>
                  <p className="text-xs text-muted-foreground font-normal">{user.email}</p>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate("/settings")} className="gap-2 cursor-pointer">
                  <Settings className="w-4 h-4" /> الإعدادات
                </DropdownMenuItem>
                <DropdownMenuItem onClick={logout} className="gap-2 text-destructive focus:text-destructive cursor-pointer">
                  <LogOut className="w-4 h-4" /> تسجيل الخروج
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <div className="flex flex-1 max-w-7xl w-full mx-auto w-full">
        {/* ===== الشريط الجانبي (حاسوب) ===== */}
        <aside className="hidden lg:flex flex-col gap-1 w-64 shrink-0 border-e bg-card p-4 sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto">
          <NavList mainNav={mainNav} adminNav={adminNav} active={active} />
        </aside>

        {/* ===== المحتوى ===== */}
        <main className="flex-1 min-w-0 p-4 sm:p-6 pb-24 lg:pb-8">{children}</main>
      </div>

      {/* ===== شريط التنقل السفلي (هاتف) ===== */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-card border-t shadow-[0_-4px_16px_rgba(0,0,0,0.06)]" style={{ paddingBottom: "env(safe-area-inset-bottom)" }} aria-label="التنقل الرئيسي">
        <div className="grid grid-cols-5 h-16">
          {mainNav.slice(0, 4).map((item) => (
            <NavButton key={item.key} item={item} active={active === item.key} />
          ))}
          <button
            onClick={() => setMenuOpen(true)}
            className={cn(
              "flex flex-col items-center justify-center gap-1 text-[10px] font-medium transition-colors min-h-[44px]",
              menuOpen || (active !== "settings" && !mainNav.slice(0, 4).some((i) => i.key === active))
                ? "text-primary"
                : "text-muted-foreground"
            )}
            aria-label="المزيد"
          >
            <Menu className="w-5 h-5" />
            المزيد
          </button>
        </div>
      </nav>

      {/* قائمة كاملة للجوال (كل الصفحات + الإدارة) */}
      <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
        <SheetContent side="bottom" className="rounded-t-3xl max-h-[70vh]" dir="rtl">
          <SheetHeader className="pb-2">
            <SheetTitle className="text-start">كل الصفحات</SheetTitle>
          </SheetHeader>
          <div className="grid grid-cols-2 gap-2 overflow-y-auto pb-6">
            {[...mainNav, { key: "settings", path: "/settings", label: "الإعدادات", icon: <Settings className="w-5 h-5" /> }].map((item) => (
              <button
                key={item.key}
                onClick={() => {
                  setMenuOpen(false);
                  navigate(item.path);
                }}
                className={cn(
                  "flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium transition-colors min-h-[44px]",
                  active === item.key ? "bg-primary text-primary-foreground" : "bg-muted/60 hover:bg-muted"
                )}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </div>
        </SheetContent>
      </Sheet>

      {/* عناصر PWA: تحديث فوري + تثبيت + دليل iOS */}
      <PwaProvider />
    </div>
  );
}

function NavList({ mainNav, adminNav, active }: { mainNav: NavItem[]; adminNav: NavItem[]; active: string }) {
  return (
    <>
      {mainNav.map((item) => (
        <button
          key={item.key}
          onClick={() => navigate(item.path)}
          className={cn(
            "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors text-start",
            active === item.key ? "bg-primary text-primary-foreground shadow-sm" : "text-foreground/80 hover:bg-muted"
          )}
          aria-current={active === item.key ? "page" : undefined}
        >
          {item.icon}
          {item.label}
        </button>
      ))}
      {adminNav.length > 0 && (
        <>
          <p className="text-xs text-muted-foreground font-semibold px-3 pt-4 pb-1">الإدارة</p>
          {adminNav.map((item) => (
            <button
              key={item.key}
              onClick={() => navigate(item.path)}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors text-start",
                active === item.key ? "bg-primary text-primary-foreground shadow-sm" : "text-foreground/80 hover:bg-muted"
              )}
              aria-current={active === item.key ? "page" : undefined}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </>
      )}
    </>
  );
}

function NavButton({ item, active }: { item: NavItem; active: boolean }) {
  return (
    <button
      onClick={() => navigate(item.path)}
      className={cn(
        "flex flex-col items-center justify-center gap-1 text-[10px] font-medium transition-colors min-h-[44px]",
        active ? "text-primary" : "text-muted-foreground"
      )}
      aria-current={active ? "page" : undefined}
    >
      {item.icon}
      {item.label}
    </button>
  );
}
