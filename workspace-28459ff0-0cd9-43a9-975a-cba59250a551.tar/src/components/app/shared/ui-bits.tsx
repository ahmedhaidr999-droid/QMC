"use client";
// مكوّنات مشتركة لكل الواجهات — رؤوس صفحات، حالات فراغ/تحميل/خطأ، بطاقات إحصاء، شارات حالة
import { type ReactNode } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, Inbox, RefreshCw } from "lucide-react";
import { STATUS_LABELS, STATUS_COLORS, type AttendanceStatus } from "@/lib/constants";
import { cn } from "@/lib/utils";

// ===== رأس صفحة =====
export function PageHeader({
  title,
  description,
  icon,
  actions,
}: {
  title: string;
  description?: string;
  icon?: ReactNode;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-4 sm:mb-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {icon && <div className="p-2.5 rounded-xl bg-primary/10 text-primary">{icon}</div>}
          <div>
            <h1 className="text-xl sm:text-2xl font-bold">{title}</h1>
            {description && <p className="text-sm text-muted-foreground mt-0.5">{description}</p>}
          </div>
        </div>
        {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
      </div>
    </div>
  );
}

// ===== حالة فراغ =====
export function EmptyState({ message, sub, action }: { message: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-4 text-center" role="status">
      <div className="p-4 rounded-full bg-muted mb-3">
        <Inbox className="w-8 h-8 text-muted-foreground" />
      </div>
      <p className="font-semibold">{message}</p>
      {sub && <p className="text-sm text-muted-foreground mt-1 max-w-sm">{sub}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

// ===== حالة خطأ مع إعادة محاولة =====
export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-4 text-center" role="alert">
      <div className="p-4 rounded-full bg-destructive/10 mb-3">
        <AlertTriangle className="w-8 h-8 text-destructive" />
      </div>
      <p className="font-semibold text-destructive">{message}</p>
      {onRetry && (
        <Button variant="outline" size="sm" className="mt-4" onClick={onRetry}>
          <RefreshCw className="w-4 h-4" />
          إعادة المحاولة
        </Button>
      )}
    </div>
  );
}

// ===== هيكل تحميل (Skeleton) =====
export function LoadingPage({ cards = 4 }: { cards?: number }) {
  return (
    <div className="space-y-4" aria-busy="true">
      <Skeleton className="h-10 w-56" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {Array.from({ length: cards }).map((_, i) => (
          <Skeleton key={i} className="h-24 rounded-2xl" />
        ))}
      </div>
      <Skeleton className="h-48 rounded-2xl" />
    </div>
  );
}

export function LoadingRows({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-2" aria-busy="true">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-14 rounded-xl" />
      ))}
    </div>
  );
}

// ===== بطاقة إحصاء =====
export function StatCard({
  label,
  value,
  icon,
  tone = "primary",
  hint,
  onClick,
}: {
  label: string;
  value: string | number | null;
  icon?: ReactNode;
  tone?: "primary" | "accent" | "warning" | "danger" | "neutral";
  hint?: string;
  onClick?: () => void;
}) {
  const tones: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    accent: "bg-sky-100 text-sky-700",
    warning: "bg-amber-100 text-amber-700",
    danger: "bg-red-100 text-red-700",
    neutral: "bg-muted text-muted-foreground",
  };
  return (
    <Card
      className={cn(
        "rounded-2xl border-border/60 shadow-sm transition-all",
        onClick && "cursor-pointer hover:shadow-md hover:-translate-y-0.5 active:translate-y-0"
      )}
      onClick={onClick}
    >
      <CardContent className="p-4 flex items-center gap-3">
        {icon && <div className={cn("p-2.5 rounded-xl shrink-0", tones[tone])}>{icon}</div>}
        <div className="min-w-0">
          <p className="text-2xl font-extrabold tabular-nums leading-none">
            {value ?? "—"}
            {typeof value === "number" && value <= 100 && label.includes("%") ? "%" : ""}
          </p>
          <p className="text-xs sm:text-sm text-muted-foreground mt-1 truncate">{label}</p>
          {hint && <p className="text-[11px] text-muted-foreground/80 mt-0.5">{hint}</p>}
        </div>
      </CardContent>
    </Card>
  );
}

// ===== شارة حالة الحضور =====
export function StatusBadge({ status, className }: { status: AttendanceStatus; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-semibold border", STATUS_COLORS[status], className)}>
      <span aria-hidden="true" className={cn("w-2 h-2 rounded-full", { "bg-emerald-500": status === "PRESENT", "bg-red-500": status === "ABSENT", "bg-amber-500": status === "LATE", "bg-sky-500": status === "EXCUSED" })} />
      {STATUS_LABELS[status]}
    </span>
  );
}

// ===== شارة أولوية =====
export function PriorityBadge({ priority }: { priority: string }) {
  if (priority === "URGENT") return <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-red-100 text-red-800 border border-red-200">🔴 عاجلة</span>;
  if (priority === "IMPORTANT") return <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">🟠 مهمة</span>;
  return <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-muted text-muted-foreground border">عادية</span>;
}
