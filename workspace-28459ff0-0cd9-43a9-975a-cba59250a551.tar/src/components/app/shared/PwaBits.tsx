"use client";
// عناصر PWA — تسجيل Service Worker، شريط التحديث الفوري، زر التثبيت، دليل iOS
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Download, RefreshCw, Share, SquarePlus, X, Smartphone } from "lucide-react";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

export function PwaProvider() {
  const [waiting, setWaiting] = useState(false);
  const [installEvt, setInstallEvt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showIosGuide, setShowIosGuide] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // تسجيل Service Worker
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").then((reg) => {
        // كشف تحديث جديد
        const checkWaiting = (r: ServiceWorkerRegistration) => {
          if (r.waiting) setWaiting(true);
        };
        checkWaiting(reg);
        reg.addEventListener("updatefound", () => {
          const nw = reg.installing;
          nw?.addEventListener("statechange", () => {
            if (nw.state === "installed" && navigator.serviceWorker.controller) setWaiting(true);
          });
        });
        // عند سيطرة SW جديد → إعادة تحميل
        let reloaded = false;
        navigator.serviceWorker.addEventListener("controllerchange", () => {
          if (reloaded) return;
          reloaded = true;
          window.location.reload();
        });
      }).catch(() => {});
    }

    // زر التثبيت (Android/Chrome)
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setInstallEvt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);

    // دليل iOS: متصفح سفاري على iOS غير مثبَّت كتطبيق (خارج التأثير المتزامن لتجنب العروض المتتالية)
    const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
    const standalone = window.matchMedia("(display-mode: standalone)").matches || (navigator as unknown as { standalone?: boolean }).standalone === true;
    if (isIos && !standalone) queueMicrotask(() => setShowIosGuide(true));

    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  const doUpdate = async () => {
    const reg = await navigator.serviceWorker?.getRegistration();
    reg?.waiting?.postMessage("SKIP_WAITING");
  };

  const doInstall = async () => {
    if (!installEvt) return;
    await installEvt.prompt();
    const choice = await installEvt.userChoice;
    if (choice.outcome === "accepted") setInstallEvt(null);
  };

  if (dismissed) return null;

  return (
    <div className="fixed bottom-20 lg:bottom-6 inset-x-4 lg:left-auto lg:right-6 lg:inset-x-auto z-50 flex flex-col gap-2 max-w-md">
      {/* شريط التحديث الفوري */}
      {waiting && (
        <div className="flex items-center gap-3 rounded-2xl border bg-card shadow-lg px-4 py-3" role="alert">
          <RefreshCw className="w-5 h-5 text-primary shrink-0" />
          <p className="text-sm font-medium flex-1">يتوفر تحديث جديد للتطبيق</p>
          <Button size="sm" onClick={doUpdate} className="gap-1.5">
            تحديث
            <RefreshCw className="w-3.5 h-3.5" />
          </Button>
        </div>
      )}

      {/* زر التثبيت */}
      {installEvt && !waiting && (
        <div className="flex items-center gap-3 rounded-2xl border bg-card shadow-lg px-4 py-3">
          <Download className="w-5 h-5 text-primary shrink-0" />
          <p className="text-sm font-medium flex-1">ثبّت التطبيق على جهازك</p>
          <Button size="sm" onClick={doInstall} className="gap-1.5">
            تثبيت
            <Download className="w-3.5 h-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setDismissed(true)} aria-label="إخفاء">
            <X className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* دليل iOS */}
      {showIosGuide && !waiting && !installEvt && (
        <div className="rounded-2xl border bg-card shadow-lg px-4 py-3">
          <div className="flex items-start gap-3">
            <Smartphone className="w-5 h-5 text-primary shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm font-bold">ثبّت التطبيق على آيفون</p>
              <ol className="mt-2 space-y-1.5 text-xs text-muted-foreground list-decimal ps-4">
                <li className="flex items-center gap-1.5">
                  اضغط زر المشاركة <Share className="w-3.5 h-3.5 inline text-primary" />
                </li>
                <li className="flex items-center gap-1.5">
                  اختر «إضافة إلى الشاشة الرئيسية» <SquarePlus className="w-3.5 h-3.5 inline text-primary" />
                </li>
                <li>ستصلك الإشعارات فور تفعيلها من الإعدادات</li>
              </ol>
            </div>
            <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={() => setDismissed(true)} aria-label="إخفاء">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
