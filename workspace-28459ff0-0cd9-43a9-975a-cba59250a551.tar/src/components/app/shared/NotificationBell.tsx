"use client";
// جرس الإشعارات داخل التطبيق — قائمة منبثقة + عدّاد + تعليم الكل كمقروء
import { useEffect, useRef } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/client/api";
import { useApp, navigate } from "@/lib/client/store";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Bell, CheckCheck } from "lucide-react";
import { cn } from "@/lib/utils";

type NotifItem = { id: string; title: string; body: string; url: string | null; readAt: string | null; createdAt: string };

export function NotificationBell() {
  const { unread, setUnread } = useApp();
  const qc = useQueryClient();
  const openRef = useRef(false);

  const { data } = useQuery({
    queryKey: ["notifications"],
    queryFn: () => api<{ items: NotifItem[]; unread: number }>("/api/notifications?limit=20"),
    refetchInterval: 30_000, // تحديث دورية كل 30 ثانية
    enabled: true,
  });

  useEffect(() => {
    if (data && !openRef.current) setUnread(data.unread);
  }, [data, setUnread]);

  const markAll = async () => {
    await api("/api/notifications", { method: "PATCH" });
    setUnread(0);
    qc.invalidateQueries({ queryKey: ["notifications"] });
  };

  return (
    <Popover
      onOpenChange={(open) => {
        openRef.current = open;
        if (open && unread > 0) markAll().catch(() => {});
      }}
    >
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative rounded-full" aria-label={`الإشعارات${unread ? ` (${unread} غير مقروء)` : ""}`}>
          <Bell className="w-5 h-5" />
          {unread > 0 && (
            <span className="absolute -top-0.5 -left-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold flex items-center justify-center">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 sm:w-96 p-0" dir="rtl">
        <div className="flex items-center justify-between px-4 py-3 border-b">
          <p className="font-bold text-sm">الإشعارات</p>
          <Button variant="ghost" size="sm" className="h-8 gap-1.5 text-xs" onClick={markAll} disabled={!unread}>
            <CheckCheck className="w-3.5 h-3.5" />
            تعليم الكل كمقروء
          </Button>
        </div>
        <div className="max-h-96 overflow-y-auto">
          {!data || data.items.length === 0 ? (
            <div className="py-10 text-center text-sm text-muted-foreground">لا توجد إشعارات</div>
          ) : (
            data.items.map((n) => (
              <button
                key={n.id}
                className={cn(
                  "w-full text-start px-4 py-3 border-b last:border-0 hover:bg-muted/60 transition-colors text-start",
                  !n.readAt && "bg-primary/5"
                )}
                onClick={() => {
                  if (n.url) navigate(n.url.replace(/^#/, ""));
                  document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape" }));
                }}
              >
                <div className="flex items-start gap-2.5">
                  <div className={cn("w-2 h-2 rounded-full mt-1.5 shrink-0", n.readAt ? "bg-muted-foreground/30" : "bg-primary")} />
                  <div className="min-w-0">
                    <p className="font-semibold text-sm leading-snug">{n.title}</p>
                    <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{n.body}</p>
                    <p className="text-[10px] text-muted-foreground/70 mt-1">
                      {new Date(n.createdAt).toLocaleString("ar-IQ", { timeZone: "Asia/Baghdad" })}
                    </p>
                  </div>
                </div>
              </button>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
