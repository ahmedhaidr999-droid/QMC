"use client";
// الماسح — كاميرا الهاتف (jsQR) + حقل قارئ USB مخفي + تسجيل يدوي + تراجع + إحصاءات
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import jsQR from "jsqr";
import { api } from "@/lib/client/api";
import { navigate, useApp } from "@/lib/client/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  EmptyState,
  ErrorState,
  LoadingPage,
  PageHeader,
  StatusBadge,
} from "@/components/app/shared/ui-bits";
import { fmtDateTime, fmtTime } from "@/lib/date-fmt";
import { ATTENDANCE_STATUSES, STATUS_LABELS, type AttendanceStatus } from "@/lib/constants";
import {
  ArrowRight,
  CalendarClock,
  Camera,
  CameraOff,
  CheckCircle2,
  Clock,
  DoorClosed,
  MapPin,
  ScanLine,
  Search,
  Undo2,
  UserRound,
  UserX,
  Users,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

// ===== الأنواع =====
type SessionInfo = {
  id: string;
  subjectId: string;
  subjectName: string;
  branchName: string;
  stageName: string;
  date: string;
  startsAt: string;
  endsAt: string;
  room: string | null;
  lateAfterMin: number;
  status: string;
  createdById: string;
};

type RecordItem = {
  id: string;
  studentId: string;
  name: string;
  universityId: string | null;
  photoUrl: string | null;
  status: AttendanceStatus;
  method: string;
  scannedAt: string | null;
  markedById: string | null;
  editedById: string | null;
  editedAt: string | null;
  note: string | null;
};

type ScanResponse =
  | { ok: true; duplicate: boolean; status: AttendanceStatus; student: { name: string; universityId: string | null; photoUrl: string | null } }
  | { ok: false; code: string; message: string };

type ResultCard =
  | { kind: "success"; at: number; name: string; universityId: string | null; status: AttendanceStatus }
  | { kind: "duplicate"; at: number; name: string }
  | { kind: "error"; at: number; message: string };

type RecentOp = { universityId: string | null; name: string; status: AttendanceStatus; at: number };

const DEBOUNCE_MS = 1500;

function asStatus(s: string): AttendanceStatus {
  return (ATTENDANCE_STATUSES as readonly string[]).includes(s) ? (s as AttendanceStatus) : "ABSENT";
}

// ===== الأصوات القصيرة عبر Web Audio API =====
let audioCtx: AudioContext | null = null;

function tone(freq: number, durationMs: number, delaySec = 0, type: OscillatorType = "sine", volume = 0.14) {
  try {
    if (!audioCtx) audioCtx = new AudioContext();
    if (audioCtx.state === "suspended") void audioCtx.resume();
    const t0 = audioCtx.currentTime + delaySec;
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    gain.gain.setValueAtTime(volume, t0);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + durationMs / 1000);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start(t0);
    osc.stop(t0 + durationMs / 1000 + 0.05);
  } catch {
    // تجاهل أخطاء الصوت
  }
}

const beepSuccess = () => tone(880, 150);
const beepDuplicate = () => {
  tone(300, 90, 0);
  tone(300, 90, 0.16);
};
const beepError = () => tone(180, 320, 0, "square", 0.09);

export function ScannerView({ sessionId }: { sessionId: string }) {
  const { user, hasScope } = useApp();
  const qc = useQueryClient();

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["attendance-session", sessionId],
    queryFn: () => api<{ session: SessionInfo; records: RecordItem[] }>(`/api/attendance/sessions/${sessionId}`),
  });

  // ===== الحالة المحلية =====
  const [cameraOn, setCameraOn] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [result, setResult] = useState<ResultCard | null>(null);
  const [recent, setRecent] = useState<RecentOp[]>([]);
  const [usbValue, setUsbValue] = useState("");
  const [manualOpen, setManualOpen] = useState(false);
  const [manualQuery, setManualQuery] = useState("");
  const [closeConfirmOpen, setCloseConfirmOpen] = useState(false);

  // ===== المراجع =====
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const lastScanAtRef = useRef(0);
  const resultTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const usbInputRef = useRef<HTMLInputElement | null>(null);
  const anyDialogOpenRef = useRef(false);
  const dispatchRef = useRef<(payload: string) => void>(() => {});

  const anyDialogOpen = manualOpen || closeConfirmOpen;
  useEffect(() => {
    anyDialogOpenRef.current = anyDialogOpen;
    if (!anyDialogOpen) {
      const t = setTimeout(() => usbInputRef.current?.focus(), 60);
      return () => clearTimeout(t);
    }
  }, [anyDialogOpen]);

  // ===== إظهار بطاقة النتيجة 3 ثوانٍ ثم انكماشها =====
  const showResult = useCallback((r: ResultCard) => {
    setResult(r);
    if (resultTimerRef.current) clearTimeout(resultTimerRef.current);
    resultTimerRef.current = setTimeout(() => setResult(null), 3000);
  }, []);

  // ===== معالجة استجابة المسح =====
  const handleResult = useCallback(
    (res: ScanResponse) => {
      if (!res.ok) {
        beepError();
        showResult({ kind: "error", at: Date.now(), message: res.message });
        return;
      }
      if (res.duplicate) {
        beepDuplicate();
        showResult({ kind: "duplicate", at: Date.now(), name: res.student.name });
        return;
      }
      beepSuccess();
      if (typeof navigator !== "undefined" && navigator.vibrate) navigator.vibrate(80);
      showResult({
        kind: "success",
        at: Date.now(),
        name: res.student.name,
        universityId: res.student.universityId,
        status: res.status,
      });
      setRecent((prev) =>
        [
          { universityId: res.student.universityId, name: res.student.name, status: res.status, at: Date.now() },
          ...prev.filter((x) => x.universityId !== res.student.universityId || !res.student.universityId),
        ].slice(0, 20)
      );
      void refetch();
    },
    [refetch, showResult]
  );

  // ===== إرسال مسح (كاميرا أو USB) =====
  const submitScan = useCallback(
    async (payload: string) => {
      try {
        const res = await api<ScanResponse>(`/api/attendance/sessions/${sessionId}/scan`, {
          method: "POST",
          body: JSON.stringify({ action: "scan", payload }),
        });
        handleResult(res);
      } catch (e) {
        beepError();
        showResult({ kind: "error", at: Date.now(), message: e instanceof Error ? e.message : "تعذّر الاتصال بالخادم" });
      }
    },
    [sessionId, handleResult, showResult]
  );

  // ===== Debounce: لا قراءة جديدة قبل 1.5 ثانية من الأخيرة =====
  const tryDispatch = useCallback(
    (payload: string) => {
      const now = Date.now();
      if (now - lastScanAtRef.current < DEBOUNCE_MS) return;
      lastScanAtRef.current = now;
      void submitScan(payload);
    },
    [submitScan]
  );

  useEffect(() => {
    dispatchRef.current = tryDispatch;
  }, [tryDispatch]);

  // ===== الكاميرا =====
  const startCamera = useCallback(async () => {
    setCameraError(null);
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error("no camera api");
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
        audio: false,
      });
      streamRef.current = stream;
      setCameraOn(true);
    } catch {
      setCameraOn(false);
      setCameraError("الكاميرا غير متاحة — استخدم الإدخال اليدوي أو حقل القارئ");
    }
  }, []);

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setCameraOn(false);
  }, []);

  // حلقة requestAnimationFrame مع jsQR على canvas مخفي
  useEffect(() => {
    if (!cameraOn) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    video.srcObject = streamRef.current;
    void video.play().catch(() => {});
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) return;

    let running = true;
    const tick = () => {
      if (!running) return;
      rafRef.current = requestAnimationFrame(tick);
      if (!video.videoWidth || !video.videoHeight || video.readyState < video.HAVE_ENOUGH_DATA) return;
      // تصغير الإطار للسرعة (بحد 640px)
      const scale = Math.min(1, 640 / Math.max(video.videoWidth, video.videoHeight));
      const cw = Math.max(1, Math.round(video.videoWidth * scale));
      const ch = Math.max(1, Math.round(video.videoHeight * scale));
      if (canvas.width !== cw || canvas.height !== ch) {
        canvas.width = cw;
        canvas.height = ch;
      }
      ctx.drawImage(video, 0, 0, cw, ch);
      const img = ctx.getImageData(0, 0, cw, ch);
      const code = jsQR(img.data, cw, ch, { inversionAttempts: "dontInvert" });
      if (code?.data) dispatchRef.current(code.data);
    };
    rafRef.current = requestAnimationFrame(tick);

    return () => {
      running = false;
      if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
    };
  }, [cameraOn]);

  // ===== التنظيف عند إلغاء التثبيت =====
  useEffect(() => {
    return () => {
      streamRef.current?.getTracks().forEach((t) => t.stop());
      if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
      if (resultTimerRef.current) clearTimeout(resultTimerRef.current);
      void audioCtx?.close().then(() => {
        audioCtx = null;
      });
    };
  }, []);

  // ===== إغلاق الجلسة =====
  const closeMut = useMutation({
    mutationFn: () => api(`/api/attendance/sessions/${sessionId}/close`, { method: "POST" }),
    onSuccess: () => {
      toast.success("أُغلقت الجلسة");
      void refetch();
      void qc.invalidateQueries({ queryKey: ["attendance-sessions"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذّر إغلاق الجلسة"),
  });

  // ===== تسجيل يدوي =====
  const submitManual = useCallback(
    async (studentId: string) => {
      try {
        const res = await api<ScanResponse>(`/api/attendance/sessions/${sessionId}/scan`, {
          method: "POST",
          body: JSON.stringify({ action: "manual", studentId }),
        });
        handleResult(res);
        setManualOpen(false);
        setManualQuery("");
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "تعذّر التسجيل اليدوي");
      }
    },
    [sessionId, handleResult]
  );

  // ===== التراجع =====
  const undo = useCallback(
    async (rec: RecordItem) => {
      try {
        await api(`/api/attendance/sessions/${sessionId}/scan`, {
          method: "POST",
          body: JSON.stringify({ action: "undo", studentId: rec.studentId }),
        });
        toast.success(`تم التراجع عن تسجيل ${rec.name}`);
        setRecent((prev) => prev.filter((x) => (rec.universityId ? x.universityId !== rec.universityId : x.name !== rec.name)));
        void refetch();
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "تعذّر التراجع");
      }
    },
    [sessionId, refetch]
  );

  // ===== مشتقات =====
  const records = data?.records ?? [];
  const session = data?.session;

  const stats = useMemo(() => {
    let present = 0;
    let late = 0;
    let absent = 0;
    let excused = 0;
    for (const r of records) {
      if (r.status === "PRESENT") present += 1;
      else if (r.status === "LATE") late += 1;
      else if (r.status === "ABSENT") absent += 1;
      else if (r.status === "EXCUSED") excused += 1;
    }
    return { present, late, absent, excused };
  }, [records]);

  const manualFiltered = useMemo(() => {
    const q = manualQuery.trim();
    return records
      .filter((r) => !q || r.name.includes(q) || (r.universityId ?? "").includes(q))
      .sort((a, b) => (a.status === "ABSENT" ? -1 : 1) - (b.status === "ABSENT" ? -1 : 1))
      .slice(0, 60);
  }, [records, manualQuery]);

  // إيجاد سجل الطالب من عمليات المسح الحديثة (للتراجع)
  const findRecordByOp = useCallback(
    (op: RecentOp): RecordItem | undefined =>
      records.find((r) => (op.universityId ? r.universityId === op.universityId : r.name === op.name)),
    [records]
  );

  // ===== الشاشات =====
  if (isLoading) return <LoadingPage cards={2} />;
  if (error)
    return (
      <ErrorState
        message={error instanceof Error ? error.message : "تعذّر تحميل الجلسة"}
        onRetry={() => void refetch()}
      />
    );
  if (!session) return null;

  const isOpen = session.status === "OPEN";

  return (
    <div className="space-y-4">
      {/* حقل مخفي مركّز دائماً لقارئ الباركود USB */}
      <input
        ref={usbInputRef}
        type="text"
        inputMode="none"
        autoComplete="off"
        aria-label="حقل قارئ الباركود"
        className="absolute top-0 start-0 w-px h-px p-0 border-0 opacity-0 focus:outline-none"
        value={usbValue}
        onChange={(e) => setUsbValue(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            const v = usbValue.trim();
            setUsbValue("");
            if (v) tryDispatch(v);
          }
        }}
        onBlur={() => {
          if (!anyDialogOpenRef.current) setTimeout(() => usbInputRef.current?.focus(), 0);
        }}
      />

      <PageHeader
        title="ماسح الحضور"
        description={session.subjectName}
        icon={<ScanLine className="w-6 h-6" />}
        actions={
          <Button variant="outline" onClick={() => navigate("/attendance")} className="gap-2">
            <ArrowRight className="w-4 h-4" />
            عودة للجلسات
          </Button>
        }
      />

      {/* شريط معلومات الجلسة */}
      <Card className="rounded-2xl border-border/60 shadow-sm">
        <CardContent className="p-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm">
          <span className="inline-flex items-center gap-1.5 font-semibold">
            <CalendarClock className="w-4 h-4 text-primary" />
            {fmtDateTime(session.startsAt)}
          </span>
          <span className="inline-flex items-center gap-1.5 text-muted-foreground">
            <MapPin className="w-4 h-4" />
            {session.room ?? "بدون قاعة"}
          </span>
          <span className="inline-flex items-center gap-1.5 text-muted-foreground">
            <Users className="w-4 h-4" />
            {records.length} طالباً
          </span>
          <span
            className={cn(
              "ms-auto inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold border",
              session.status === "OPEN"
                ? "bg-emerald-100 text-emerald-800 border-emerald-200"
                : session.status === "SCHEDULED"
                  ? "bg-sky-100 text-sky-800 border-sky-200"
                  : "bg-muted text-muted-foreground border-border"
            )}
          >
            <span
              aria-hidden
              className={cn("w-2 h-2 rounded-full", isOpen ? "bg-emerald-500 animate-pulse" : session.status === "SCHEDULED" ? "bg-sky-500" : "bg-gray-400")}
            />
            {session.status === "OPEN" ? "مفتوحة" : session.status === "SCHEDULED" ? "مجدولة" : "مغلقة"}
          </span>
        </CardContent>
      </Card>

      {!isOpen && (
        <div
          className={cn(
            "flex items-center gap-2.5 rounded-xl border px-4 py-3 text-sm font-medium",
            session.status === "SCHEDULED"
              ? "border-sky-200 bg-sky-50 dark:bg-sky-950/30 dark:border-sky-900 text-sky-800 dark:text-sky-300"
              : "border-border bg-muted text-muted-foreground"
          )}
          role="status"
        >
          <Clock className="w-4 h-4 shrink-0" />
          {session.status === "SCHEDULED"
            ? "الجلسة مجدولة — المسح يعمل فقط بعد فتح الجلسة"
            : "الجلسة مغلقة — يمكنك التسجيل اليدوي بالتراجع عنه فقط من صفحة الجلسات"}
        </div>
      )}

      {/* الكاميرا */}
      <div className="relative rounded-2xl overflow-hidden bg-black aspect-video">
        <video
          ref={videoRef}
          playsInline
          muted
          autoPlay
          className={cn("w-full h-full object-cover", !cameraOn && "hidden")}
          aria-label="معاينة الكاميرا"
        />
        {cameraOn && (
          <div className="absolute inset-x-10 inset-y-10 border-2 border-white/60 rounded-xl pointer-events-none" aria-hidden />
        )}
        {!cameraOn && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center">
            <div className="p-4 rounded-full bg-white/10">
              <Camera className="w-8 h-8 text-white" />
            </div>
            {cameraError ? (
              <>
                <p className="text-white font-semibold">الكاميرا غير متاحة</p>
                <p className="text-white/70 text-sm">استخدم الإدخال اليدوي أو حقل القارئ — كلاهما يعمل الآن</p>
              </>
            ) : (
              <p className="text-white/80 text-sm">وجّه كاميرا الهاتف نحو رمز QR الخاص بالطالب</p>
            )}
            <Button onClick={() => void startCamera()} className="gap-2 bg-white text-foreground hover:bg-white/90">
              <Camera className="w-4 h-4" />
              بدء المسح بالكاميرا
            </Button>
          </div>
        )}
      </div>
      <canvas ref={canvasRef} className="hidden" aria-hidden />

      {/* بطاقة النتيجة الكبيرة */}
      <AnimatePresence>
        {result && (
          <motion.div
            key={result.at}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96 }}
            transition={{ duration: 0.18 }}
            role="status"
            aria-live="polite"
          >
            {result.kind === "success" && (
              <div
                className={cn(
                  "rounded-2xl border p-5 flex items-center gap-4 shadow-sm",
                  result.status === "PRESENT"
                    ? "border-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 dark:border-emerald-800"
                    : "border-amber-300 bg-amber-50 dark:bg-amber-950/40 dark:border-amber-800"
                )}
              >
                <div
                  className={cn(
                    "p-3 rounded-full shrink-0",
                    result.status === "PRESENT" ? "bg-emerald-100 dark:bg-emerald-900" : "bg-amber-100 dark:bg-amber-900"
                  )}
                >
                  <CheckCircle2
                    className={cn("w-8 h-8", result.status === "PRESENT" ? "text-emerald-600" : "text-amber-600")}
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xl font-extrabold truncate">{result.name}</p>
                  <p className="text-sm text-muted-foreground tabular-nums" dir="ltr">
                    {result.universityId ?? "—"}
                  </p>
                </div>
                <span
                  className={cn(
                    "shrink-0 px-3 py-1 rounded-full text-sm font-bold border",
                    result.status === "PRESENT"
                      ? "bg-emerald-100 text-emerald-800 border-emerald-300"
                      : "bg-amber-100 text-amber-800 border-amber-300"
                  )}
                >
                  {STATUS_LABELS[result.status]}
                </span>
              </div>
            )}

            {result.kind === "duplicate" && (
              <div className="rounded-2xl border border-border bg-muted/70 p-4 flex items-center gap-3 shadow-sm">
                <div className="p-2.5 rounded-full bg-muted shrink-0">
                  <UserRound className="w-6 h-6 text-muted-foreground" />
                </div>
                <p className="font-semibold text-muted-foreground">مكرر — {result.name}</p>
              </div>
            )}

            {result.kind === "error" && (
              <div className="rounded-2xl border border-red-300 bg-red-50 dark:bg-red-950/40 dark:border-red-800 p-4 flex items-center gap-3 shadow-sm" role="alert">
                <div className="p-2.5 rounded-full bg-red-100 dark:bg-red-900 shrink-0">
                  <XCircle className="w-6 h-6 text-red-600" />
                </div>
                <p className="font-semibold text-red-800 dark:text-red-300">{result.message}</p>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* أزرار التحكم */}
      <div className="flex flex-wrap items-center gap-2">
        <Button variant="outline" onClick={() => setManualOpen(true)} className="gap-2">
          <Search className="w-4 h-4" />
          تسجيل يدوي
        </Button>
        {cameraOn && (
          <Button variant="outline" onClick={stopCamera} className="gap-2">
            <CameraOff className="w-4 h-4" />
            إيقاف الكاميرا
          </Button>
        )}
        {isOpen && (
          <Button
            variant="outline"
            onClick={() => setCloseConfirmOpen(true)}
            disabled={closeMut.isPending}
            className="gap-2 ms-auto"
          >
            <DoorClosed className="w-4 h-4" />
            إغلاق الجلسة
          </Button>
        )}
      </div>

      {/* الإحصاءات الحالية */}
      <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
        <div className="rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/30 px-3 py-2 text-center">
          <p className="text-xl font-extrabold tabular-nums text-emerald-700 dark:text-emerald-400">{stats.present}</p>
          <p className="text-[11px] text-emerald-800/80 dark:text-emerald-300/80">حاضر</p>
        </div>
        <div className="rounded-xl border border-amber-200 dark:border-amber-900 bg-amber-50 dark:bg-amber-950/30 px-3 py-2 text-center">
          <p className="text-xl font-extrabold tabular-nums text-amber-700 dark:text-amber-400">{stats.late}</p>
          <p className="text-[11px] text-amber-800/80 dark:text-amber-300/80">متأخر</p>
        </div>
        <div className="rounded-xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/30 px-3 py-2 text-center">
          <p className="text-xl font-extrabold tabular-nums text-red-700 dark:text-red-400">{stats.absent}</p>
          <p className="text-[11px] text-red-800/80 dark:text-red-300/80">غائب</p>
        </div>
        <div className="rounded-xl border border-sky-200 dark:border-sky-900 bg-sky-50 dark:bg-sky-950/30 px-3 py-2 text-center">
          <p className="text-xl font-extrabold tabular-nums text-sky-700 dark:text-sky-400">{stats.excused}</p>
          <p className="text-[11px] text-sky-800/80 dark:text-sky-300/80">مجاز</p>
        </div>
      </div>

      {/* آخر الممسوحين */}
      <Card className="rounded-2xl border-border/60 shadow-sm">
        <CardContent className="p-4">
          <p className="text-sm font-semibold mb-3 flex items-center gap-2">
            <ScanLine className="w-4 h-4 text-primary" />
            آخر الممسوحين ({recent.length})
          </p>
          {recent.length === 0 ? (
            <EmptyState message="لم يُمسح أي رمز بعد" sub="ستظهر هنا نتائج المسح مباشرةً" />
          ) : (
            <div className="max-h-72 overflow-y-auto -mx-1 px-1 space-y-1.5">
              {recent.map((op) => {
                const rec = findRecordByOp(op);
                const canUndo = !!rec && (rec.markedById === user?.id || hasScope("attendance.edit"));
                return (
                  <div
                    key={`${op.universityId ?? op.name}-${op.at}`}
                    className="flex items-center gap-2 rounded-xl border border-border/60 bg-background px-3 py-2"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold truncate">{op.name}</p>
                      <p className="text-[11px] text-muted-foreground tabular-nums" dir="ltr">
                        {op.universityId ?? "—"}
                      </p>
                    </div>
                    <StatusBadge status={op.status} />
                    <span className="text-[11px] text-muted-foreground tabular-nums">{fmtTime(new Date(op.at))}</span>
                    {canUndo && rec && (
                      <Button
                        size="icon"
                        variant="ghost"
                        className="w-9 h-9 text-muted-foreground hover:text-destructive"
                        title={`التراجع عن تسجيل ${op.name}`}
                        aria-label={`التراجع عن تسجيل ${op.name}`}
                        onClick={() => void undo(rec)}
                      >
                        <Undo2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ===== حوار التسجيل اليدوي ===== */}
      <Dialog open={manualOpen} onOpenChange={setManualOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>تسجيل يدوي</DialogTitle>
            <DialogDescription>ابحث عن الطالب بالاسم أو الرقم الجامعي ثم اضغط عليه لتسجيل حضوره</DialogDescription>
          </DialogHeader>
          <div className="grid gap-2">
            <Label htmlFor="manual-search" className="sr-only">
              بحث
            </Label>
            <div className="relative">
              <Search className="absolute top-1/2 -translate-y-1/2 start-2.5 w-4 h-4 text-muted-foreground" />
              <Input
                id="manual-search"
                autoFocus
                className="ps-8"
                placeholder="الاسم أو الرقم الجامعي..."
                value={manualQuery}
                onChange={(e) => setManualQuery(e.target.value)}
              />
            </div>
          </div>
          <div className="max-h-80 overflow-y-auto -mx-2 px-2 space-y-1.5">
            {manualFiltered.length === 0 ? (
              <EmptyState message="لا نتائج مطابقة" />
            ) : (
              manualFiltered.map((r) => (
                <button
                  key={r.id}
                  className="w-full flex items-center justify-between gap-2 rounded-xl border border-border/60 px-3 py-2.5 text-start transition-colors hover:bg-muted/60 hover:border-border"
                  onClick={() => void submitManual(r.studentId)}
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{r.name}</p>
                    <p className="text-[11px] text-muted-foreground tabular-nums" dir="ltr">
                      {r.universityId ?? "—"}
                    </p>
                  </div>
                  {r.status === "ABSENT" ? (
                    <span className="text-[11px] text-muted-foreground inline-flex items-center gap-1 shrink-0">
                      <UserX className="w-3.5 h-3.5" />
                      غير مسجّل
                    </span>
                  ) : (
                    <StatusBadge status={r.status} />
                  )}
                </button>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* تأكيد إغلاق الجلسة */}
      <AlertDialog open={closeConfirmOpen} onOpenChange={setCloseConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>إغلاق الجلسة؟</AlertDialogTitle>
            <AlertDialogDescription>
              لن يقبل المسح أي رمز جديد بعد الإغلاق — يبقى التعديل ممكناً من التقارير أو تعديل السجلات بسبب
              موثّق.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={() => closeMut.mutate()}>إغلاق الجلسة</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
