"use client";
// حضوري — سجل حضور الطالب لكل مادة (نِسَب + إحصاءات + تفاصيل الجلسات)
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/client/api";
import { useApp } from "@/lib/client/store";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  CalendarCheck,
  CalendarX2,
  CheckCircle2,
  Clock,
  FileCheck2,
  UserX,
  AlertTriangle,
} from "lucide-react";
import {
  EmptyState,
  ErrorState,
  LoadingPage,
  PageHeader,
  StatusBadge,
} from "@/components/app/shared/ui-bits";
import { fmtDate, fmtTime } from "@/lib/date-fmt";
import { ATTENDANCE_STATUSES, type AttendanceStatus } from "@/lib/constants";
import { cn } from "@/lib/utils";

type MySubject = {
  subjectId: string;
  subjectName: string;
  branchName: string;
  stageName: string;
  sessions: { id: string; date: string; status: string; note: string | null }[];
  present: number;
  absent: number;
  late: number;
  excused: number;
  attendancePct: number;
  atRisk: boolean;
};

function asStatus(s: string): AttendanceStatus {
  return (ATTENDANCE_STATUSES as readonly string[]).includes(s) ? (s as AttendanceStatus) : "ABSENT";
}

// لون النسبة: أخضر ≥75، برتقالي 50-75، أحمر <50
function pctTone(pct: number) {
  if (pct >= 75) return { text: "text-emerald-600 dark:text-emerald-400", bar: "#10b981" };
  if (pct >= 50) return { text: "text-amber-600 dark:text-amber-400", bar: "#f59e0b" };
  return { text: "text-red-600 dark:text-red-400", bar: "#ef4444" };
}

function StatChip({
  icon,
  label,
  value,
  cls,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  cls: string;
}) {
  return (
    <div className="flex items-center gap-2 rounded-xl bg-muted/60 px-3 py-2">
      <span className={cn("shrink-0", cls)}>{icon}</span>
      <div className="leading-tight">
        <p className="text-base font-extrabold tabular-nums">{value}</p>
        <p className="text-[11px] text-muted-foreground">{label}</p>
      </div>
    </div>
  );
}

export function MyAttendanceView() {
  const { user } = useApp();
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["my-attendance"],
    queryFn: () => api<{ subjects: MySubject[] }>("/api/my/attendance"),
  });

  if (isLoading) return <LoadingPage />;
  if (error)
    return (
      <ErrorState message={error instanceof Error ? error.message : "تعذّر تحميل سجل الحضور"} onRetry={refetch} />
    );

  const subjects = data?.subjects ?? [];
  if (subjects.length === 0)
    return (
      <>
        <PageHeader
          title="حضوري"
          description="نسبة حضورك لكل مادة وتفاصيل الجلسات"
          icon={<CalendarCheck className="w-6 h-6" />}
        />
        <EmptyState
          message="لا يوجد سجل حضور بعد"
          sub="ستظهر موادك ونِسَب حضورك هنا بعد أول جلسة تُفتح لموادك"
        />
      </>
    );

  return (
    <div className="space-y-6">
      <PageHeader
        title="حضوري"
        description={`${user?.fullName ?? "سجل حضورك"} — النِسَب لكل مادة`}
        icon={<CalendarCheck className="w-6 h-6" />}
      />

      {subjects.map((s) => {
        const tone = pctTone(s.attendancePct);
        return (
          <Card key={s.subjectId} className="rounded-2xl border-border/60 shadow-sm">
            <CardContent className="p-4 sm:p-6 space-y-4">
              {/* رأس المادة: الاسم + النسبة */}
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-lg font-bold truncate">{s.subjectName}</h3>
                    {s.atRisk && (
                      <Badge className="bg-red-100 text-red-800 border border-red-200 hover:bg-red-100">
                        <AlertTriangle className="w-3 h-3 ml-1" />
                        معرّض للحرمان
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    {s.stageName} — {s.branchName}
                  </p>
                </div>
                <div className="text-end shrink-0">
                  <p className={cn("text-3xl font-extrabold tabular-nums", tone.text)}>
                    {s.attendancePct}%
                  </p>
                  <p className="text-[11px] text-muted-foreground">نسبة الحضور</p>
                </div>
              </div>

              {/* شريط النسبة */}
              <div
                className="h-2.5 rounded-full bg-muted overflow-hidden"
                role="progressbar"
                aria-valuenow={s.attendancePct}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label={`نسبة الحضور في ${s.subjectName}`}
              >
                <div
                  className="h-full rounded-full transition-all duration-700"
                  style={{ width: `${Math.min(100, s.attendancePct)}%`, backgroundColor: tone.bar }}
                />
              </div>

              {/* الإحصاءات */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <StatChip icon={<CheckCircle2 className="w-4 h-4" />} label="حاضر" value={s.present} cls="text-emerald-600" />
                <StatChip icon={<Clock className="w-4 h-4" />} label="متأخر" value={s.late} cls="text-amber-600" />
                <StatChip icon={<UserX className="w-4 h-4" />} label="غائب" value={s.absent} cls="text-red-600" />
                <StatChip icon={<FileCheck2 className="w-4 h-4" />} label="مجاز" value={s.excused} cls="text-sky-600" />
              </div>

              {/* جدول الجلسات */}
              <div>
                <p className="text-sm font-semibold mb-2 flex items-center gap-1.5">
                  <CalendarX2 className="w-4 h-4 text-primary" />
                  الجلسات ({s.sessions.length})
                </p>
                <div className="rounded-xl border border-border/60 overflow-hidden">
                  <div className="max-h-72 overflow-y-auto">
                    <Table>
                      <TableHeader className="sticky top-0 z-10">
                        <TableRow>
                          <TableHead className="bg-background">التاريخ</TableHead>
                          <TableHead className="bg-background">الحالة</TableHead>
                          <TableHead className="bg-background">ملاحظة</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {s.sessions.map((sess) => (
                          <TableRow key={sess.id}>
                            <TableCell className="whitespace-nowrap">
                              <span className="font-medium">{fmtDate(sess.date)}</span>
                              <span className="text-muted-foreground text-xs"> — {fmtTime(sess.date)}</span>
                            </TableCell>
                            <TableCell>
                              <StatusBadge status={asStatus(sess.status)} />
                            </TableCell>
                            <TableCell className="text-muted-foreground text-xs">
                              {sess.note ? <span title={sess.note}>{sess.note}</span> : "—"}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
