"use client";
// جلسات الحضور — قائمة الجلسات + إنشاء + فتح/إغلاق + فلترة بالمادة
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/client/api";
import { navigate, useApp } from "@/lib/client/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  EmptyState,
  ErrorState,
  LoadingRows,
  PageHeader,
} from "@/components/app/shared/ui-bits";
import { fmtDate, fmtTime } from "@/lib/date-fmt";
import type { SessionStatus } from "@/lib/constants";
import { CalendarCheck, CalendarPlus, DoorClosed, DoorOpen, Loader2, MapPin, ScanLine, Users } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type SessionItem = {
  id: string;
  subjectId: string;
  subjectName: string;
  branchName: string;
  stageName: string;
  date: string;
  startsAt: string;
  endsAt: string;
  room: string | null;
  lateAfterMin: number;
  status: SessionStatus;
  total: number;
};

type SubjectItem = { id: string; code: string; nameAr: string; branchName: string; stageName: string };

// شارة حالة الجلسة: مجدولة sky / مفتوحة emerald / مغلقة muted
function SessionStatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    SCHEDULED: "bg-sky-100 text-sky-800 border-sky-200",
    OPEN: "bg-emerald-100 text-emerald-800 border-emerald-200",
    CLOSED: "bg-muted text-muted-foreground border-border",
  };
  const labels: Record<string, string> = {
    SCHEDULED: "مجدولة",
    OPEN: "مفتوحة",
    CLOSED: "مغلقة",
  };
  return (
    <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold border", styles[status] ?? styles.CLOSED)}>
      <span aria-hidden className={cn("w-2 h-2 rounded-full", status === "OPEN" ? "bg-emerald-500 animate-pulse" : status === "SCHEDULED" ? "bg-sky-500" : "bg-gray-400")} />
      {labels[status] ?? status}
    </span>
  );
}

// تاريخ اليوم بتوقيت بغداد بصيغة yyyy-mm-dd
function baghdadToday(): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Baghdad",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

export function SessionsView() {
  const { hasScope } = useApp();
  const qc = useQueryClient();
  const canManage = hasScope("attendance.session.manage");

  const [subjectFilter, setSubjectFilter] = useState<string>("all");
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({
    subjectId: "",
    date: baghdadToday(),
    startTime: "09:00",
    endTime: "10:30",
    room: "",
    lateAfterMin: "15",
  });

  const sessionsQ = useQuery({
    queryKey: ["attendance-sessions", subjectFilter],
    queryFn: () =>
      api<{ items: SessionItem[] }>(
        `/api/attendance/sessions${subjectFilter !== "all" ? `?subjectId=${encodeURIComponent(subjectFilter)}` : ""}`
      ),
  });

  const subjectsQ = useQuery({
    queryKey: ["subjects-all"],
    queryFn: () => api<{ items: SubjectItem[] }>("/api/subjects"),
  });

  // ===== إنشاء جلسة =====
  const createMut = useMutation({
    mutationFn: () =>
      api("/api/attendance/sessions", {
        method: "POST",
        body: JSON.stringify({
          subjectId: form.subjectId,
          date: form.date,
          startTime: form.startTime,
          endTime: form.endTime,
          room: form.room || undefined,
          lateAfterMin: Number(form.lateAfterMin) || 0,
        }),
      }),
    onSuccess: () => {
      toast.success("تم إنشاء الجلسة بنجاح");
      setCreateOpen(false);
      void qc.invalidateQueries({ queryKey: ["attendance-sessions"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذّر إنشاء الجلسة"),
  });

  // ===== فتح / إغلاق =====
  const openMut = useMutation({
    mutationFn: (id: string) => api<{ ok: boolean; count: number }>(`/api/attendance/sessions/${id}/open`, { method: "POST" }),
    onSuccess: (res) => {
      toast.success(`فُتحت الجلسة — تم تسجيل ${res.count} طالباً في المصفوفة`);
      void qc.invalidateQueries({ queryKey: ["attendance-sessions"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذّر فتح الجلسة"),
  });

  const closeMut = useMutation({
    mutationFn: (id: string) => api(`/api/attendance/sessions/${id}/close`, { method: "POST" }),
    onSuccess: () => {
      toast.success("أُغلقت الجلسة");
      void qc.invalidateQueries({ queryKey: ["attendance-sessions"] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "تعذّر إغلاق الجلسة"),
  });

  function submitCreate() {
    if (!form.subjectId) {
      toast.error("اختر المادة أولاً");
      return;
    }
    if (!form.date || !form.startTime || !form.endTime) {
      toast.error("التاريخ ووقتا البداية والنهاية مطلوبة");
      return;
    }
    if (form.endTime <= form.startTime) {
      toast.error("وقت النهاية يجب أن يكون بعد وقت البداية");
      return;
    }
    createMut.mutate();
  }

  const subjects = subjectsQ.data?.items ?? [];
  const items = sessionsQ.data?.items ?? [];

  return (
    <div className="space-y-4">
      <PageHeader
        title="جلسات الحضور"
        description="إدارة جلسات المحاضرات وتسجيل الحضور"
        icon={<CalendarCheck className="w-6 h-6" />}
        actions={
          canManage && (
            <Button onClick={() => setCreateOpen(true)} className="gap-2">
              <CalendarPlus className="w-4 h-4" />
              إنشاء جلسة
            </Button>
          )
        }
      />

      {/* فلترة بالمادة */}
      <div className="flex items-center gap-2">
        <Select value={subjectFilter} onValueChange={setSubjectFilter}>
          <SelectTrigger className="w-full sm:w-72" aria-label="فلترة بالمادة">
            <SelectValue placeholder="كل المواد" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل المواد</SelectItem>
            {subjects.map((s) => (
              <SelectItem key={s.id} value={s.id}>
                {s.nameAr} — {s.branchName}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {subjectsQ.isLoading && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />}
      </div>

      {/* القائمة */}
      {sessionsQ.isLoading ? (
        <LoadingRows rows={6} />
      ) : sessionsQ.error ? (
        <ErrorState
          message={sessionsQ.error instanceof Error ? sessionsQ.error.message : "تعذّر تحميل الجلسات"}
          onRetry={() => void sessionsQ.refetch()}
        />
      ) : items.length === 0 ? (
        <EmptyState
          message="لا توجد جلسات"
          sub={subjectFilter !== "all" ? "لا توجد جلسات لهذه المادة بعد" : "لم تُنشأ أي جلسة حضور بعد"}
          action={
            canManage && (
              <Button onClick={() => setCreateOpen(true)} className="gap-2">
                <CalendarPlus className="w-4 h-4" />
                إنشاء أول جلسة
              </Button>
            )
          }
        />
      ) : (
        <div className="space-y-3">
          {items.map((s) => (
            <Card key={s.id} className="rounded-2xl border-border/60 shadow-sm transition-shadow hover:shadow-md">
              <CardContent className="p-4 flex flex-col gap-3">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-bold truncate">{s.subjectName}</h3>
                      <SessionStatusBadge status={s.status} />
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {s.stageName} — {s.branchName}
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-1 text-sm">
                    <span className="font-semibold">{fmtDate(s.startsAt)}</span>
                    <span className="text-muted-foreground text-xs tabular-nums" dir="ltr">
                      {fmtTime(s.startsAt)} — {fmtTime(s.endsAt)}
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" />
                    {s.room ?? "بدون قاعة"}
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <Users className="w-3.5 h-3.5" />
                    {s.total} مسجّل
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <DoorOpen className="w-3.5 h-3.5" />
                    التأخير بعد {s.lateAfterMin} دقيقة
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-border/60">
                  <Button size="sm" className="gap-1.5" onClick={() => navigate(`/scan/${s.id}`)}>
                    <ScanLine className="w-4 h-4" />
                    الماسح
                  </Button>
                  {s.status !== "OPEN" && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-1.5 text-emerald-700 border-emerald-300 hover:bg-emerald-50 hover:text-emerald-800"
                      disabled={openMut.isPending}
                      onClick={() => openMut.mutate(s.id)}
                    >
                      {openMut.isPending && openMut.variables === s.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <DoorOpen className="w-4 h-4" />
                      )}
                      فتح الجلسة
                    </Button>
                  )}
                  {s.status === "OPEN" && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-1.5"
                      disabled={closeMut.isPending}
                      onClick={() => closeMut.mutate(s.id)}
                    >
                      {closeMut.isPending && closeMut.variables === s.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <DoorClosed className="w-4 h-4" />
                      )}
                      إغلاق
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* ===== حوار إنشاء جلسة ===== */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>إنشاء جلسة حضور</DialogTitle>
            <DialogDescription>حدّد المادة والتاريخ والأوقات — تُنشأ الجلسة بحالة «مجدولة»</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-1">
            <div className="grid gap-2">
              <Label htmlFor="subj">المادة</Label>
              <Select value={form.subjectId} onValueChange={(v) => setForm((f) => ({ ...f, subjectId: v }))}>
                <SelectTrigger id="subj" className="w-full">
                  <SelectValue placeholder="اختر المادة" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.nameAr} — {s.branchName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label htmlFor="date">التاريخ</Label>
                <Input id="date" type="date" value={form.date} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="room">القاعة</Label>
                <Input id="room" placeholder="مثال: قاعة 12" value={form.room} onChange={(e) => setForm((f) => ({ ...f, room: e.target.value }))} />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="grid gap-2">
                <Label htmlFor="start">وقت البداية</Label>
                <Input id="start" type="time" value={form.startTime} onChange={(e) => setForm((f) => ({ ...f, startTime: e.target.value }))} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="end">وقت النهاية</Label>
                <Input id="end" type="time" value={form.endTime} onChange={(e) => setForm((f) => ({ ...f, endTime: e.target.value }))} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="late">التأخير بعد (دقيقة)</Label>
                <Input id="late" type="number" min={0} max={120} value={form.lateAfterMin} onChange={(e) => setForm((f) => ({ ...f, lateAfterMin: e.target.value }))} />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>
              إلغاء
            </Button>
            <Button onClick={submitCreate} disabled={createMut.isPending} className="gap-2">
              {createMut.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
              إنشاء الجلسة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
