"use client";
// تقارير الحضور — مصفوفة (طلاب × جلسات) + فلاتر + تصدير واستيراد Excel
import { useDeferredValue, useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/client/api";
import { useApp } from "@/lib/client/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { EmptyState, ErrorState, LoadingPage, PageHeader } from "@/components/app/shared/ui-bits";
import { fmtShort } from "@/lib/date-fmt";
import { STATUS_COLORS, STATUS_LABELS, STATUS_SYMBOLS, type AttendanceStatus } from "@/lib/constants";
import {
  AlertTriangle,
  Download,
  FileSpreadsheet,
  Loader2,
  PieChart,
  Search,
  Upload,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type SubjectItem = { id: string; code: string; nameAr: string; branchName: string; stageName: string };

type MatrixRow = {
  no: number;
  id: string;
  name: string;
  universityId: string | null;
  cells: AttendanceStatus[];
  cellSymbols: string[];
  present: number;
  absent: number;
  late: number;
  excused: number;
  attendancePct: number;
  atRisk: boolean;
};

type ReportData = {
  subject: { id: string; nameAr: string; code: string; branchName: string; stageName: string };
  sessions: { id: string; date: string; room: string | null }[];
  rows: MatrixRow[];
};

type ImportDiff = { name: string; universityId: string; sessionDate: string; from: string; to: string };

function asStatus(s: string): AttendanceStatus {
  const all: readonly string[] = ["PRESENT", "ABSENT", "LATE", "EXCUSED"];
  return (all.includes(s) ? s : "ABSENT") as AttendanceStatus;
}

function pctColor(pct: number) {
  if (pct >= 75) return "text-emerald-600 dark:text-emerald-400";
  if (pct >= 50) return "text-amber-600 dark:text-amber-400";
  return "text-red-600 dark:text-red-400";
}

export function ReportsView() {
  const { hasScope } = useApp();
  const canExport = hasScope("attendance.export");
  const canImport = hasScope("attendance.import");

  const [subjectId, setSubjectId] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [student, setStudent] = useState("");
  const studentDebounced = useDeferredValue(student);

  // ===== حوار الاستيراد =====
  const [importOpen, setImportOpen] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importReason, setImportReason] = useState("");
  const [importPreview, setImportPreview] = useState<{ preview: ImportDiff[]; errors: string[] } | null>(null);
  const [importBusy, setImportBusy] = useState(false);
  const [applyConfirmOpen, setApplyConfirmOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const subjectsQ = useQuery({
    queryKey: ["subjects-all"],
    queryFn: () => api<{ items: SubjectItem[] }>("/api/subjects"),
  });

  // المادة الافتراضية: ?subject= من الرابط أو أول مادة
  useEffect(() => {
    if (subjectId || !subjectsQ.data?.items.length) return;
    const fromUrl = new URLSearchParams(window.location.hash.split("?")[1] ?? "").get("subject");
    if (fromUrl && subjectsQ.data.items.some((s) => s.id === fromUrl)) {
      setSubjectId(fromUrl);
    } else {
      setSubjectId(subjectsQ.data.items[0].id);
    }
  }, [subjectsQ.data, subjectId]);

  const reportQ = useQuery({
    queryKey: ["report-attendance", subjectId, from, to, studentDebounced],
    queryFn: () => {
      const params = new URLSearchParams({ subjectId });
      if (from) params.set("from", from);
      if (to) params.set("to", to);
      if (studentDebounced.trim()) params.set("student", studentDebounced.trim());
      return api<ReportData>(`/api/reports/attendance?${params.toString()}`);
    },
    enabled: !!subjectId,
  });

  const sessions = reportQ.data?.sessions ?? [];
  const rows = reportQ.data?.rows ?? [];
  const atRiskCount = useMemo(() => rows.filter((r) => r.atRisk).length, [rows]);

  // ===== التصدير =====
  function exportExcel() {
    if (!subjectId) return;
    window.open(`/api/export/attendance?subjectId=${encodeURIComponent(subjectId)}`, "_blank");
    toast.success("جارٍ تنزيل ملف Excel");
  }

  // ===== الاستيراد: معاينة =====
  async function runImport(mode: "preview" | "apply") {
    if (!importFile) {
      toast.error("اختر ملف Excel (xlsx) أولاً");
      return;
    }
    if (importReason.trim().length < 3) {
      toast.error("سبب التعديل إلزامي (3 أحرف على الأقل)");
      return;
    }
    setImportBusy(true);
    try {
      const fd = new FormData();
      fd.append("subjectId", subjectId);
      fd.append("mode", mode);
      fd.append("reason", importReason.trim());
      fd.append("file", importFile);
      const res = await api<{ preview?: ImportDiff[]; errors: string[]; applied?: number }>("/api/import/attendance", {
        method: "POST",
        body: fd,
      });
      if (mode === "preview") {
        setImportPreview({ preview: res.preview ?? [], errors: res.errors ?? [] });
        if (!res.preview?.length && !res.errors.length) {
          toast.info("لا توجد فروقات — الملف مطابق للحالة الحالية");
        }
      } else {
        toast.success(`تم تطبيق ${res.applied ?? 0} تغييراً بنجاح`);
        if (res.errors.length) toast.warning(`${res.errors.length} صف تعذّر تطبيقه — راجع الأخطاء`);
        closeImport();
        void reportQ.refetch();
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "تعذّر الاستيراد");
    } finally {
      setImportBusy(false);
    }
  }

  function closeImport() {
    setImportOpen(false);
    setImportFile(null);
    setImportReason("");
    setImportPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  return (
    <div className="space-y-4">
      <PageHeader
        title="تقارير الحضور"
        description="مصفوفة الحضور لكل مادة مع التصدير والاستيراد"
        icon={<PieChart className="w-6 h-6" />}
        actions={
          <div className="flex flex-wrap gap-2">
            {canExport && (
              <Button variant="outline" onClick={exportExcel} disabled={!subjectId} className="gap-2">
                <Download className="w-4 h-4" />
                تصدير Excel
              </Button>
            )}
            {canImport && (
              <Button onClick={() => setImportOpen(true)} disabled={!subjectId} className="gap-2">
                <Upload className="w-4 h-4" />
                استيراد Excel
              </Button>
            )}
          </div>
        }
      />

      {/* الفلاتر */}
      <Card className="rounded-2xl border-border/60 shadow-sm">
        <CardContent className="p-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="grid gap-1.5">
            <Label htmlFor="subject">المادة</Label>
            <Select value={subjectId} onValueChange={setSubjectId}>
              <SelectTrigger id="subject" className="w-full">
                <SelectValue placeholder={subjectsQ.isLoading ? "جارٍ التحميل..." : "اختر المادة"} />
              </SelectTrigger>
              <SelectContent>
                {(subjectsQ.data?.items ?? []).map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.nameAr} — {s.branchName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="from">من تاريخ</Label>
            <Input id="from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="to">إلى تاريخ</Label>
            <Input id="to" type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="student">بحث بالاسم أو الرقم الجامعي</Label>
            <div className="relative">
              <Search className="absolute top-1/2 -translate-y-1/2 start-2.5 w-4 h-4 text-muted-foreground" />
              <Input id="student" className="ps-8" placeholder="اسم الطالب..." value={student} onChange={(e) => setStudent(e.target.value)} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* تنبيه الحرمان */}
      {atRiskCount > 0 && (
        <div className="flex items-center gap-2.5 rounded-xl border border-red-200 bg-red-50 dark:bg-red-950/30 dark:border-red-900 px-4 py-3 text-red-800 dark:text-red-300" role="alert">
          <AlertTriangle className="w-5 h-5 shrink-0" />
          <p className="text-sm font-semibold">
            يوجد {atRiskCount} طالباً معرّضاً للحرمان (غياب أكثر من 25%)
          </p>
        </div>
      )}

      {/* المصفوفة */}
      {!subjectId ? (
        subjectsQ.isLoading ? (
          <LoadingPage />
        ) : (
          <EmptyState message="لا توجد مواد متاحة" sub="لا يمكن عرض التقارير قبل إضافة مواد" />
        )
      ) : reportQ.isLoading ? (
        <LoadingPage cards={2} />
      ) : reportQ.error ? (
        <ErrorState
          message={reportQ.error instanceof Error ? reportQ.error.message : "تعذّر تحميل التقرير"}
          onRetry={() => void reportQ.refetch()}
        />
      ) : sessions.length === 0 ? (
        <EmptyState
          message="لا توجد جلسات لهذه المادة"
          sub="أنشئ جلسات حضور أولاً لتظهر المصفوفة"
        />
      ) : rows.length === 0 ? (
        <EmptyState message="لا يوجد طلاب مطابقون للبحث" />
      ) : (
        <Card className="rounded-2xl border-border/60 shadow-sm">
          <CardContent className="p-0">
            {/* دليل الرموز */}
            <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-b border-border/60 text-xs">
              {(Object.keys(STATUS_SYMBOLS) as AttendanceStatus[]).map((st) => (
                <span key={st} className={cn("inline-flex items-center gap-1 px-2 py-0.5 rounded-full border font-semibold", STATUS_COLORS[st])}>
                  {STATUS_SYMBOLS[st]} = {STATUS_LABELS[st]}
                </span>
              ))}
              <span className="text-muted-foreground ms-auto">
                {sessions.length} جلسة — {rows.length} طالباً
              </span>
            </div>

            <div className="max-w-full">
              <Table className="min-w-max">
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="sticky right-0 z-30 bg-background text-start w-44 min-w-44 border-s-0">
                      اسم الطالب
                    </TableHead>
                    <TableHead className="sticky right-44 z-30 bg-background text-center w-24 min-w-24">
                      الرقم الجامعي
                    </TableHead>
                    {sessions.map((s) => (
                      <TableHead key={s.id} className="text-center min-w-10" title={s.room ?? undefined}>
                        {fmtShort(s.date)}
                      </TableHead>
                    ))}
                    <TableHead className="text-center">حاضر</TableHead>
                    <TableHead className="text-center">غائب</TableHead>
                    <TableHead className="text-center">النسبة %</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((r) => (
                    <TableRow
                      key={r.id}
                      className={cn(
                        "hover:bg-transparent",
                        r.atRisk && "bg-red-50/70 dark:bg-red-950/20"
                      )}
                    >
                      <TableCell
                        className={cn(
                          "sticky right-0 z-20 w-44 min-w-44 font-medium",
                          r.atRisk ? "bg-red-50 dark:bg-red-950/40" : "bg-background"
                        )}
                      >
                        <span className="flex items-center gap-1.5">
                          {r.atRisk && (
                            <AlertTriangle
                              className="w-4 h-4 text-red-600 shrink-0"
                              aria-label="معرّض للحرمان"
                            />
                          )}
                          <span className="truncate">{r.name}</span>
                        </span>
                      </TableCell>
                      <TableCell
                        className={cn(
                          "sticky right-44 z-20 w-24 min-w-24 text-center text-xs tabular-nums text-muted-foreground",
                          r.atRisk ? "bg-red-50 dark:bg-red-950/40" : "bg-background"
                        )}
                        dir="ltr"
                      >
                        {r.universityId ?? "—"}
                      </TableCell>
                      {r.cells.map((st, i) => (
                        <TableCell key={i} className="p-1 text-center">
                          <span
                            className={cn(
                              "inline-flex items-center justify-center w-7 h-7 rounded-md border text-xs font-bold",
                              STATUS_COLORS[st]
                            )}
                            title={STATUS_LABELS[st]}
                          >
                            {r.cellSymbols[i]}
                          </span>
                        </TableCell>
                      ))}
                      <TableCell className="text-center font-semibold tabular-nums">{r.present}</TableCell>
                      <TableCell className="text-center font-semibold tabular-nums text-red-600 dark:text-red-400">
                        {r.absent}
                      </TableCell>
                      <TableCell className={cn("text-center font-extrabold tabular-nums", pctColor(r.attendancePct))}>
                        {r.attendancePct}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ===== حوار الاستيراد ===== */}
      <Dialog open={importOpen} onOpenChange={(o) => (o ? setImportOpen(true) : closeImport())}>
        <DialogContent className="sm:max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-primary" />
              استيراد الحضور من Excel
            </DialogTitle>
            <DialogDescription>
              ارفع ملف المصفوفة المصدَّر (بعد تعديله) — ستُعرض الفروقات قبل التطبيق
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-1">
            <div className="grid gap-2">
              <Label htmlFor="xlsx">ملف Excel (xlsx)</Label>
              <Input
                id="xlsx"
                ref={fileInputRef}
                type="file"
                accept=".xlsx"
                onChange={(e) => {
                  setImportFile(e.target.files?.[0] ?? null);
                  setImportPreview(null);
                }}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="reason">سبب التعديل (إلزامي)</Label>
              <Input
                id="reason"
                placeholder="مثال: تصحيح الغياب بعد إبراز العذر الطبي"
                value={importReason}
                onChange={(e) => setImportReason(e.target.value)}
              />
            </div>

            {importPreview && (
              <div className="space-y-3">
                {importPreview.preview.length > 0 && (
                  <div className="rounded-xl border border-border/60 overflow-hidden">
                    <div className="max-h-64 overflow-y-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>الطالب</TableHead>
                            <TableHead>الجلسة</TableHead>
                            <TableHead>كان</TableHead>
                            <TableHead>صار</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {importPreview.preview.map((d, i) => (
                            <TableRow key={i}>
                              <TableCell className="font-medium">
                                {d.name}
                                <span className="block text-[11px] text-muted-foreground tabular-nums" dir="ltr">
                                  {d.universityId}
                                </span>
                              </TableCell>
                              <TableCell className="tabular-nums">{d.sessionDate}</TableCell>
                              <TableCell>
                                <span className={cn("px-2 py-0.5 rounded-md border text-xs font-semibold", STATUS_COLORS[asStatus(d.from)])}>
                                  {STATUS_LABELS[asStatus(d.from)]}
                                </span>
                              </TableCell>
                              <TableCell>
                                <span className={cn("px-2 py-0.5 rounded-md border text-xs font-semibold", STATUS_COLORS[asStatus(d.to)])}>
                                  {STATUS_LABELS[asStatus(d.to)]}
                                </span>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                )}

                {importPreview.errors.length > 0 && (
                  <div className="rounded-xl border border-red-200 bg-red-50 dark:bg-red-950/30 dark:border-red-900 p-3">
                    <p className="text-sm font-semibold text-red-800 dark:text-red-300 mb-1">
                      أخطاء ({importPreview.errors.length}):
                    </p>
                    <ul className="text-xs text-red-700 dark:text-red-300 list-disc ps-4 space-y-0.5 max-h-32 overflow-y-auto">
                      {importPreview.errors.map((e, i) => (
                        <li key={i}>{e}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>

          <DialogFooter className="flex-wrap gap-2">
            <Button variant="outline" onClick={() => (importPreview ? void runImport("preview") : closeImport())} disabled={importBusy}>
              {importPreview ? "إعادة المعاينة" : "إلغاء"}
            </Button>
            <Button onClick={() => void runImport("preview")} disabled={importBusy || !importFile} className="gap-2">
              {importBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileSpreadsheet className="w-4 h-4" />}
              معاينة الفروقات
            </Button>
            {importPreview && importPreview.preview.length > 0 && (
              <Button onClick={() => setApplyConfirmOpen(true)} disabled={importBusy} className="gap-2">
                <Upload className="w-4 h-4" />
                تطبيق التغييرات ({importPreview.preview.length})
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* تأكيد التطبيق */}
      <AlertDialog open={applyConfirmOpen} onOpenChange={setApplyConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد تطبيق التغييرات</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم تعديل {importPreview?.preview.length ?? 0} سجل حضور إلى الحالات الجديدة بأسلوب «استيراد
              Excel» مع تسجيل السبب في سجل التدقيق. لا يمكن التراجع تلقائياً.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>تراجع</AlertDialogCancel>
            <AlertDialogAction onClick={() => void runImport("apply")}>تطبيق التغييرات</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
