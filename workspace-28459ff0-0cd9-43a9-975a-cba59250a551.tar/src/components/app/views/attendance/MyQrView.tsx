"use client";
// باركودي — QR متغيّر (يتجدد كل 30 ثانية) + البطاقة المطبوعة بباركود Code128 ثابت
import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import QRCode from "qrcode";
import JsBarcode from "jsbarcode";
import { api } from "@/lib/client/api";
import { useApp } from "@/lib/client/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { ErrorState, LoadingPage, PageHeader } from "@/components/app/shared/ui-bits";
import { IdCard, Maximize2, Printer, QrCode, RefreshCw, ShieldCheck, Sun } from "lucide-react";
import { toast } from "sonner";

type MyQrData = {
  token: string;
  secondsLeft: number;
  step: number;
  staticCode: string | null;
  fullName: string;
  universityId: string | null;
  photoUrl: string | null;
};

const QR_DARK = "#0f172a";

export function MyQrView() {
  const { user } = useApp();
  const { data, isLoading, error, refetch, isFetching, dataUpdatedAt } = useQuery({
    queryKey: ["my-qr"],
    queryFn: () => api<MyQrData>("/api/my/qr"),
  });

  const [now, setNow] = useState(() => Date.now());
  const [qrSmall, setQrSmall] = useState<string | null>(null);
  const [qrBig, setQrBig] = useState<string | null>(null);
  const [staticQr, setStaticQr] = useState<string | null>(null);
  const [zoomOpen, setZoomOpen] = useState(false);
  const barcodeCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const token = data?.token ?? null;
  const staticCode = data?.staticCode ?? null;
  const step = data?.step ?? 30;

  // ===== العدّاد التنازلي (مشتق من وقت الاستجابة) =====
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const secondsLeft = data
    ? Math.max(0, Math.min(step, Math.round(data.secondsLeft - (now - dataUpdatedAt) / 1000)))
    : 0;

  // عند الوصول للصفر: أعد الجلب ليتجدد الكود
  useEffect(() => {
    if (data && secondsLeft <= 0 && !isFetching) void refetch();
  }, [data, secondsLeft, isFetching, refetch]);

  // ===== توليد صور QR (صغير + كبير) عند كل توكن جديد =====
  useEffect(() => {
    let cancelled = false;
    if (!token) return;
    void Promise.all([
      QRCode.toDataURL(token, { width: 280, margin: 1, color: { dark: QR_DARK } }),
      QRCode.toDataURL(token, { width: 420, margin: 2, color: { dark: QR_DARK } }),
    ]).then(([small, big]) => {
      if (cancelled) return;
      setQrSmall(small);
      setQrBig(big);
    });
    return () => {
      cancelled = true;
    };
  }, [token]);

  // ===== QR ثابت من الرقم الجامعي (للبطاقة المطبوعة) =====
  useEffect(() => {
    let cancelled = false;
    if (!staticCode) return;
    void QRCode.toDataURL(staticCode, { width: 240, margin: 1, color: { dark: QR_DARK } }).then((url) => {
      if (!cancelled) setStaticQr(url);
    });
    return () => {
      cancelled = true;
    };
  }, [staticCode]);

  // ===== الباركود الثابت Code128 على canvas =====
  useEffect(() => {
    const canvas = barcodeCanvasRef.current;
    if (!staticCode || !canvas) return;
    try {
      JsBarcode(canvas, staticCode, {
        format: "CODE128",
        height: 60,
        fontSize: 16,
        displayValue: true,
        margin: 10,
        lineColor: QR_DARK,
        background: "#ffffff",
      });
    } catch {
      toast.error("تعذّر توليد الباركود الثابت");
    }
  }, [staticCode]);

  // ===== طباعة البطاقة: نافذة جديدة ببطاقة أنيقة ثم print() =====
  function printCard() {
    const barcodeUrl = barcodeCanvasRef.current?.toDataURL("image/png") ?? "";
    const w = window.open("", "_blank", "width=640,height=900");
    if (!w) {
      toast.error("تعذّر فتح نافذة الطباعة — اسمح بالنوافذ المنبثقة لهذا الموقع");
      return;
    }
    w.document.write(`<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8">
<title>بطاقة الطالب — ${data?.fullName ?? ""}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: "Cairo", "Segoe UI", Tahoma, sans-serif; background: #f1f5f9; display: flex; justify-content: center; padding: 24px; }
  .card { width: 320px; border: 2px solid #166534; border-radius: 16px; overflow: hidden; background: #fff; }
  .head { background: #166534; color: #fff; text-align: center; padding: 10px 12px; }
  .head h1 { font-size: 17px; }
  .head p { font-size: 11px; opacity: .85; margin-top: 2px; }
  .body { padding: 14px 16px; text-align: center; }
  .name { font-size: 16px; font-weight: 800; color: #0f172a; }
  .uid { font-size: 13px; color: #475569; margin-top: 2px; direction: ltr; }
  .row { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-top: 12px; }
  .row img { max-width: 100%; }
  .barcode { width: 100%; }
  .qr { width: 92px; }
  .hint { font-size: 10px; color: #64748b; margin-top: 10px; border-top: 1px dashed #cbd5e1; padding-top: 8px; }
  @media print { body { background: #fff; padding: 0; } }
</style>
</head>
<body>
  <div class="card">
    <div class="head">
      <h1>نظام إدارة الكلية</h1>
      <p>البطاقة الجامعية — بطاقة الحضور</p>
    </div>
    <div class="body">
      <p class="name">${data?.fullName ?? ""}</p>
      <p class="uid">${data?.universityId ?? ""}</p>
      ${barcodeUrl ? `<div class="row"><img class="barcode" src="${barcodeUrl}" alt="باركود"></div>` : ""}
      ${staticQr ? `<div class="row"><img class="qr" src="${staticQr}" alt="رمز QR"></div>` : ""}
      <p class="hint">هذا الباركود خاص بك ويُستخدم لتسجيل الحضور — لا تُشاركه مع أحد</p>
    </div>
  </div>
</body>
</html>`);
    w.document.close();
    w.focus();
    setTimeout(() => w.print(), 400);
  }

  if (isLoading) return <LoadingPage cards={2} />;
  if (error)
    return (
      <ErrorState
        message={error instanceof Error ? error.message : "تعذّر تحميل الباركود"}
        onRetry={() => void refetch()}
      />
    );
  if (!data) return null;

  // هندسة الحلقة الدائرية للعدّاد
  const R = 26;
  const CIRC = 2 * Math.PI * R;
  const ratio = step > 0 ? Math.max(0, Math.min(1, secondsLeft / step)) : 0;

  return (
    <div className="space-y-6">
      <PageHeader
        title="باركودي"
        description="اعرض الكود عند المدخل لتسجيل حضورك"
        icon={<QrCode className="w-6 h-6" />}
      />

      <div className="grid lg:grid-cols-2 gap-4 items-start">
        {/* ===== بطاقة QR المتغيّر ===== */}
        <Card className="rounded-2xl border-border/60 shadow-sm">
          <CardContent className="p-6 flex flex-col items-center text-center gap-4">
            <div className="relative">
              <div className="bg-white rounded-2xl p-3 border border-border/60 shadow-inner">
                {qrSmall ? (
                  <img
                    src={qrSmall}
                    alt="رمز الحضور المتغيّر"
                    width={280}
                    height={280}
                    className={`w-56 h-56 sm:w-64 sm:h-64 transition-opacity duration-500 ${isFetching ? "opacity-30" : "opacity-100"}`}
                  />
                ) : (
                  <div className="w-56 h-56 sm:w-64 sm:h-64 flex items-center justify-center">
                    <RefreshCw className="w-8 h-8 animate-spin text-muted-foreground" />
                  </div>
                )}
              </div>

              {/* العدّاد الدائري فوق زاوية الكود */}
              <div className="absolute -bottom-3 -start-3 bg-background rounded-full border border-border/60 shadow-sm p-1">
                <div className="relative w-14 h-14">
                  <svg viewBox="0 0 64 64" className="w-14 h-14 -rotate-90">
                    <circle cx="32" cy="32" r={R} fill="none" strokeWidth="6" className="stroke-muted" />
                    <circle
                      cx="32"
                      cy="32"
                      r={R}
                      fill="none"
                      strokeWidth="6"
                      strokeLinecap="round"
                      className={secondsLeft <= 5 ? "stroke-red-500" : "stroke-primary"}
                      strokeDasharray={CIRC}
                      strokeDashoffset={CIRC * (1 - ratio)}
                      style={{ transition: "stroke-dashoffset 1s linear" }}
                    />
                  </svg>
                  <span
                    className={`absolute inset-0 flex items-center justify-center text-sm font-extrabold tabular-nums ${secondsLeft <= 5 ? "text-red-600" : ""}`}
                    aria-live="polite"
                  >
                    {secondsLeft}
                  </span>
                </div>
              </div>
            </div>

            <div>
              <p className="font-bold text-lg">{data.fullName}</p>
              <p className="text-sm text-muted-foreground tabular-nums" dir="ltr">
                {data.universityId ?? "—"}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <Button onClick={() => setZoomOpen(true)} className="gap-2">
                <Maximize2 className="w-4 h-4" />
                تكبير
              </Button>
            </div>

            <p className="text-xs text-muted-foreground flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-primary" />
              الكود يتجدد تلقائياً كل {step} ثانية لحمايتك من مشاركته
            </p>
          </CardContent>
        </Card>

        {/* ===== قسم البطاقة المطبوعة ===== */}
        <Card className="rounded-2xl border-border/60 shadow-sm">
          <CardContent className="p-6 space-y-4">
            <div className="flex items-center gap-2">
              <IdCard className="w-5 h-5 text-primary" />
              <h3 className="font-bold">البطاقة المطبوعة</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              هذا باركودك الثابت الخاص بالبطاقة الجامعية — يعمل حتى دون تجديد تلقائي، ويصلح لقارئ الباركود
              عند المدخل.
            </p>

            <div className="rounded-xl border border-dashed border-border bg-white p-3 flex justify-center">
              <canvas
                ref={barcodeCanvasRef}
                className="max-w-full h-auto"
                aria-label={`باركود ثابت ${data.staticCode ?? ""}`}
              />
            </div>

            {staticQr && (
              <div className="flex items-center justify-center gap-4">
                <img
                  src={staticQr}
                  alt="رمز QR ثابت للبطاقة"
                  width={96}
                  height={96}
                  className="w-24 h-24 rounded-lg border border-border/60"
                />
                <p className="text-xs text-muted-foreground max-w-40">
                  رمز QR ثابت مطبوع على البطاقة (يُقرأ كـ{" "}
                  <span dir="ltr" className="font-mono">
                    {data.staticCode}
                  </span>
                  )
                </p>
              </div>
            )}

            <Button onClick={printCard} className="w-full gap-2" disabled={!staticCode}>
              <Printer className="w-4 h-4" />
              طباعة البطاقة
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* ===== حوار التكبير ===== */}
      <Dialog open={zoomOpen} onOpenChange={setZoomOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>رمز الحضور</DialogTitle>
            <DialogDescription>أظهر هذا الكود للمسؤول عند المدخل</DialogDescription>
          </DialogHeader>
          <div className="flex flex-col items-center gap-4 py-2">
            <div className="bg-white rounded-2xl p-4 border border-border/60 shadow-inner">
              {qrBig ? (
                <img
                  src={qrBig}
                  alt="رمز الحضور مكبّراً"
                  width={420}
                  height={420}
                  className={`w-72 h-72 sm:w-80 sm:h-80 transition-opacity duration-500 ${isFetching ? "opacity-30" : "opacity-100"}`}
                />
              ) : (
                <div className="w-72 h-72 sm:w-80 sm:h-80 flex items-center justify-center">
                  <RefreshCw className="w-8 h-8 animate-spin text-muted-foreground" />
                </div>
              )}
            </div>
            <Separator />
            <p className="text-sm font-semibold flex items-center gap-2">
              <Sun className="w-4 h-4 text-amber-500" />
              ارفع سطوع شاشتك إلى الأقصى لضمان قراءة سريعة
            </p>
            <p className="text-xs text-muted-foreground">
              يتجدد الكود خلال {secondsLeft} ثانية — {user?.fullName}
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
