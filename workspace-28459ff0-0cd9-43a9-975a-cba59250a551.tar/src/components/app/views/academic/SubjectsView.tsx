"use client";
// مواد الفرع التدريسي — بطاقات + CRUD + إسناد التدريسيين (structure.manage)
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { api } from "@/lib/client/api";
import { navigate, useApp } from "@/lib/client/store";
import { EmptyState, ErrorState, PageHeader, StatCard } from "@/components/app/shared/ui-bits";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  BookOpen, GraduationCap, Video, CalendarCheck, Users, Plus, Pencil, Trash2, ChevronLeft,
  MoreVertical, Loader2, UserCog, Search,
} from "lucide-react";

// ===== الأنواع =====
type BranchItem = { id: string; nameAr: string; stageId: string; stageName: string; subjectsCount: number; studentsCount: number };
type SubjectItem = {
  id: string; code: string; nameAr: string; semester: number;
  branchId: string; branchName: string; stageId: string; stageName: string;
  instructors: { id: string; name: string }[];
  lecturesCount: number; sessionsCount: number;
};
type InstructorUser = { id: string; fullName: string; email: string };

function semesterLabel(s: number): string {
  return s === 2 ? "الفصل الثاني" : "الفصل الأول";
}

export function SubjectsView({ branchId }: { branchId?: string }) {
  if (!branchId) {
    return <ErrorState message="مسار غير صحيح — اختر فرعاً من صفحة المرحلة" onRetry={() => navigate("/stages")} />;
  }
  return <BranchSubjectsPage branchId={branchId} />;
}

function BranchSubjectsPage({ branchId }: { branchId: string }) {
  const canManage = useApp().hasScope("structure.manage");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<SubjectItem | null>(null);
  const [deleting, setDeleting] = useState<SubjectItem | null>(null);
  const [assigning, setAssigning] = useState<SubjectItem | null>(null);

  // مواد الفرع
  const subjectsQ = useQuery({
    queryKey: ["subjects", branchId],
    queryFn: () => api<{ items: SubjectItem[] }>(`/api/subjects?branchId=${encodeURIComponent(branchId)}`),
  });
  // كل الفروع لمعرفة اسم الفرع والمرحلة
  const branchesQ = useQuery({
    queryKey: ["branches", "all"],
    queryFn: () => api<{ items: BranchItem[] }>("/api/branches"),
  });
  const branch = branchesQ.data?.items.find((b) => b.id === branchId) ?? null;
  const subjects = subjectsQ.data?.items ?? [];

  const loading = subjectsQ.isLoading || branchesQ.isLoading;

  return (
    <div>
      {/* مسار التنقل */}
      <Breadcrumb className="mb-4" aria-label="مسار التنقل">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <button type="button" className="cursor-pointer" onClick={() => navigate("/dashboard")}>الرئيسية</button>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <button type="button" className="cursor-pointer" onClick={() => navigate("/stages")}>المراحل</button>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          {branch && (
            <>
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <button type="button" className="cursor-pointer" onClick={() => navigate(`/stages/${branch.stageId}`)}>{branch.stageName}</button>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
            </>
          )}
          <BreadcrumbItem>
            <BreadcrumbPage>{branch?.nameAr ?? "…"}</BreadcrumbPage>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      <PageHeader
        title={branch ? `مواد ${branch.nameAr}` : "مواد الفرع"}
        description={branch ? `${branch.stageName} — ${subjects.length} مادة` : "جارٍ التحميل…"}
        icon={<BookOpen className="w-6 h-6" />}
        actions={
          canManage && (
            <Button onClick={() => { setEditing(null); setDialogOpen(true); }}>
              <Plus className="w-4 h-4" />
              إضافة مادة
            </Button>
          )
        }
      />

      {loading && (
        <div className="space-y-4" aria-busy="true">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-44 rounded-2xl" />)}
          </div>
        </div>
      )}

      {subjectsQ.error && (
        <ErrorState
          message={subjectsQ.error instanceof Error ? subjectsQ.error.message : "تعذر تحميل المواد"}
          onRetry={() => subjectsQ.refetch()}
        />
      )}
      {branchesQ.error && !subjectsQ.error && (
        <ErrorState
          message={branchesQ.error instanceof Error ? branchesQ.error.message : "تعذر تحميل بيانات الفرع"}
          onRetry={() => branchesQ.refetch()}
        />
      )}

      {!loading && (subjects.length > 0 || branch) && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          <StatCard label="مواد الفرع" value={subjects.length} icon={<BookOpen className="w-5 h-5" />} tone="primary" />
          <StatCard label="طلاب الفرع" value={branch?.studentsCount ?? null} icon={<Users className="w-5 h-5" />} tone="accent" />
        </div>
      )}

      {!loading && subjects.length === 0 && (
        <EmptyState
          message="لا توجد مواد في هذا الفرع بعد"
          sub={canManage ? "أضف أول مادة لهذا الفرع التدريسي" : "لم تُضَف مواد لهذا الفرع بعد"}
          action={canManage && (
            <Button onClick={() => { setEditing(null); setDialogOpen(true); }}>
              <Plus className="w-4 h-4" />
              أضف أول مادة
            </Button>
          )}
        />
      )}

      {subjects.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {subjects.map((s) => (
            <Card key={s.id} className="rounded-2xl border-border/60 shadow-sm hover:shadow-md transition-all">
              <CardContent className="p-5">
                <button
                  type="button"
                  className="w-full text-start cursor-pointer group"
                  onClick={() => navigate(`/subjects/${s.id}`)}
                  aria-label={`فتح ${s.nameAr}`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <Badge variant="secondary" className="font-mono text-xs">{s.code}</Badge>
                    <div className="flex items-center gap-1">
                      <Badge variant="outline" className="text-[11px]">{semesterLabel(s.semester)}</Badge>
                      <ChevronLeft className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:-translate-x-0.5 transition-all shrink-0" />
                    </div>
                  </div>
                  <p className="font-bold text-base sm:text-lg mt-2 leading-snug min-h-[1.75rem]">{s.nameAr}</p>
                  <div className="mt-2 flex items-start gap-1.5 text-xs text-muted-foreground min-h-8">
                    <GraduationCap className="w-4 h-4 shrink-0 mt-0.5 text-primary/70" />
                    <span className="leading-5">
                      {s.instructors.length > 0 ? s.instructors.map((i) => i.name).join("، ") : "لا يوجد تدريسيون مسندون"}
                    </span>
                  </div>
                  <div className="mt-3 flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="inline-flex items-center gap-1.5">
                      <Video className="w-4 h-4 text-primary/70" />
                      {s.lecturesCount} محاضرات
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <CalendarCheck className="w-4 h-4 text-primary/70" />
                      {s.sessionsCount} جلسات
                    </span>
                  </div>
                </button>
                {canManage && (
                  <div className="mt-4 pt-3 border-t border-border/60 flex items-center justify-between">
                    <span className="text-[11px] text-muted-foreground/70">إدارة المادة</span>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-9 w-9" aria-label={`خيارات ${s.nameAr}`}>
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuItem onClick={() => { setEditing(s); setDialogOpen(true); }}>
                          <Pencil className="w-4 h-4" />
                          تعديل المادة
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setAssigning(s)}>
                          <UserCog className="w-4 h-4" />
                          إسناد التدريسيين
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem variant="destructive" onClick={() => setDeleting(s)}>
                          <Trash2 className="w-4 h-4" />
                          حذف المادة
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* نافذة إنشاء/تعديل مادة */}
      {dialogOpen && (
        <SubjectDialog
          open
          onOpenChange={(v) => { if (!v) { setDialogOpen(false); setEditing(null); } }}
          branchId={branchId}
          subject={editing}
        />
      )}

      {/* نافذة إسناد التدريسيين */}
      {assigning && (
        <AssignInstructorsDialog
          subject={assigning}
          onClose={() => setAssigning(null)}
        />
      )}

      {/* تأكيد حذف مادة */}
      <DeleteSubjectDialog
        subject={deleting}
        branchId={branchId}
        onClose={() => setDeleting(null)}
      />
    </div>
  );
}

// ===== نافذة إنشاء/تعديل مادة =====
function SubjectDialog({
  open, onOpenChange, branchId, subject,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  branchId: string;
  subject: SubjectItem | null;
}) {
  const qc = useQueryClient();
  // يُركّب المكوّن من جديد عند كل فتح فتُهيّأ القيم مباشرة من الخصائص
  const [code, setCode] = useState(subject?.code ?? "");
  const [nameAr, setNameAr] = useState(subject?.nameAr ?? "");
  const [semester, setSemester] = useState(String(subject?.semester ?? 1));

  const valid = code.trim().length >= 2 && nameAr.trim().length >= 2;

  const mutation = useMutation({
    mutationFn: () => {
      const body = JSON.stringify({
        code: code.trim(),
        nameAr: nameAr.trim(),
        semester: Number(semester),
        ...(subject ? {} : { branchId }),
      });
      return subject
        ? api(`/api/subjects/${subject.id}`, { method: "PATCH", body })
        : api("/api/subjects", { method: "POST", body });
    },
    onSuccess: () => {
      toast.success(subject ? "تم تعديل المادة" : "تمت إضافة المادة");
      onOpenChange(false);
      qc.invalidateQueries({ queryKey: ["subjects", branchId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{subject ? "تعديل المادة" : "إضافة مادة"}</DialogTitle>
          <DialogDescription>
            {subject ? "عدّل بيانات المادة الأساسية" : "أدخل رمز المادة واسمها وفصلها"}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="subject-code">رمز المادة</Label>
            <Input
              id="subject-code"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="مثال: CS101"
              maxLength={20}
              className="font-mono"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="subject-name">اسم المادة</Label>
            <Input
              id="subject-name"
              value={nameAr}
              onChange={(e) => setNameAr(e.target.value)}
              placeholder="مثال: البرمجة الكينونية"
              maxLength={80}
            />
          </div>
          <div className="space-y-2">
            <Label>الفصل الدراسي</Label>
            <Select value={semester} onValueChange={setSemester}>
              <SelectTrigger className="w-full" aria-label="الفصل الدراسي">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">الفصل الأول</SelectItem>
                <SelectItem value="2">الفصل الثاني</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button disabled={!valid || mutation.isPending} onClick={() => mutation.mutate()}>
            {mutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            {subject ? "حفظ التعديلات" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ===== نافذة إسناد التدريسيين =====
function AssignInstructorsDialog({
  subject, onClose,
}: {
  subject: SubjectItem | null;
  onClose: () => void;
}) {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  // يُركّب المكوّن من جديد عند كل فتح فتُهيّأ القيم مباشرة من الخصائص
  const [selected, setSelected] = useState<Set<string>>(
    () => new Set(subject?.instructors.map((i) => i.id) ?? [])
  );

  // المكوّن يُركّب فقط عند وجود مادة — نجلب التدريسيين مباشرة
  const instructorsQ = useQuery({
    queryKey: ["admin-users", "INSTRUCTOR"],
    queryFn: () => api<{ items: InstructorUser[] }>("/api/admin/users?role=INSTRUCTOR"),
    enabled: !!subject,
  });

  const filtered = useMemo(() => {
    const q = search.trim();
    const items = instructorsQ.data?.items ?? [];
    if (!q) return items;
    return items.filter((u) => u.fullName.includes(q) || u.email.includes(q));
  }, [instructorsQ.data, search]);

  const toggle = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const mutation = useMutation({
    mutationFn: () => {
      if (!subject) throw new Error("لا توجد مادة");
      return api(`/api/subjects/${subject.id}`, {
        method: "PATCH",
        body: JSON.stringify({ instructorIds: [...selected] }),
      });
    },
    onSuccess: () => {
      toast.success("تم تحديث التدريسيين المسندين للمادة");
      onClose();
      qc.invalidateQueries({ queryKey: ["subjects"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={!!subject} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserCog className="w-5 h-5 text-primary" />
            إسناد التدريسيين
          </DialogTitle>
          <DialogDescription>
            اختر التدريسيين المسندين لمادة «{subject?.nameAr}» — يتم استبدال القائمة الحالية
          </DialogDescription>
        </DialogHeader>

        <div className="relative">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث بالاسم أو البريد…"
            className="ps-9"
          />
        </div>

        <div className="rounded-xl border border-border/60">
          {instructorsQ.isLoading && (
            <div className="p-4 space-y-2" aria-busy="true">
              {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-10" />)}
            </div>
          )}
          {instructorsQ.error && (
            <ErrorState
              message={instructorsQ.error instanceof Error ? instructorsQ.error.message : "تعذر تحميل التدريسيين"}
              onRetry={() => instructorsQ.refetch()}
            />
          )}
          {instructorsQ.data && filtered.length === 0 && (
            <p className="p-6 text-center text-sm text-muted-foreground">
              {search ? "لا نتائج مطابقة للبحث" : "لا يوجد تدريسيون في النظام"}
            </p>
          )}
          {filtered.length > 0 && (
            <ScrollArea className="h-64">
              <div className="p-2 space-y-1">
                {filtered.map((u) => (
                  <label
                    key={u.id}
                    className="flex items-center gap-3 rounded-lg px-3 py-2.5 hover:bg-muted/60 cursor-pointer transition-colors"
                  >
                    <Checkbox
                      checked={selected.has(u.id)}
                      onCheckedChange={() => toggle(u.id)}
                      aria-label={`إسناد ${u.fullName}`}
                    />
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
                        <GraduationCap className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{u.fullName}</p>
                        <p className="text-xs text-muted-foreground truncate">{u.email}</p>
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            </ScrollArea>
          )}
        </div>

        <DialogFooter className="items-center sm:justify-between">
          <p className="text-xs text-muted-foreground">المحددون: {selected.size}</p>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>إلغاء</Button>
            <Button disabled={instructorsQ.isLoading || mutation.isPending} onClick={() => mutation.mutate()}>
              {mutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
              حفظ الإسناد
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ===== تأكيد حذف مادة =====
function DeleteSubjectDialog({
  subject, branchId, onClose,
}: {
  subject: SubjectItem | null;
  branchId: string;
  onClose: () => void;
}) {
  const qc = useQueryClient();
  const mutation = useMutation({
    mutationFn: (id: string) => api(`/api/subjects/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      toast.success("تم حذف المادة");
      onClose();
      qc.invalidateQueries({ queryKey: ["subjects", branchId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <AlertDialog open={!!subject} onOpenChange={(v) => !v && onClose()}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>حذف المادة</AlertDialogTitle>
          <AlertDialogDescription>
            هل أنت متأكد من حذف «{subject?.nameAr}» ({subject?.code})؟ سيتم حذف محاضراتها وجلساتها. لا يمكن التراجع عن هذا الإجراء.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>إلغاء</AlertDialogCancel>
          <AlertDialogAction
            className="bg-destructive text-white hover:bg-destructive/90"
            onClick={(e) => {
              if (subject) mutation.mutate(subject.id);
              e.preventDefault();
            }}
          >
            {mutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
            حذف نهائي
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
