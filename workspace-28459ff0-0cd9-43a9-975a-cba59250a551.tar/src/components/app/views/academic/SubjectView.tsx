"use client";
// صفحة المادة — تبويبات: المحاضرات / جلسات الحضور / الطلاب
import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import ReactMarkdown, { type Components } from "react-markdown";
import remarkGfm from "remark-gfm";
import { api } from "@/lib/client/api";
import { navigate, useApp } from "@/lib/client/store";
import { EmptyState, ErrorState, PageHeader, StatCard } from "@/components/app/shared/ui-bits";
import { fmtDate, fmtDateTime, fmtTime, fmtWeekday } from "@/lib/date-fmt";
import { ALLOWED_UPLOAD_MIME, LECTURE_TYPE_LABELS, SESSION_STATUS_LABELS, type LectureType, type SessionStatus } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  BookOpen, GraduationCap, Video, CalendarCheck, Users, Plus, Pencil, Trash2, ChevronLeft,
  MoreVertical, Loader2, FileText, Upload, ExternalLink, QrCode, Table2, Search, Eye, PenLine,
} from "lucide-react";

// ===== الأنواع =====
type SubjectDetail = {
  id: string; code: string; nameAr: string; semester: number;
  branchId: string; branchName: string; stageId: string; stageName: string;
  instructors: { id: string; name: string; email: string }[];
  lecturesCount: number; sessionsCount: number; studentsCount: number;
};
type LectureFileDTO = { id: string; name: string; url: string; mime: string; sizeBytes: number };
type LectureItem = {
  id: string; title: string; summary: string | null; contentMd: string | null;
  weekNo: number | null; type: string; videoUrl: string | null; isPublished: boolean;
  files: LectureFileDTO[]; createdByName: string; createdById: string; createdAt: string;
};
type SessionItem = {
  id: string; subjectId: string; subjectName: string; branchName: string; stageName: string;
  date: string; startsAt: string; endsAt: string; room: string | null; lateAfterMin: number;
  status: string; total: number;
};
type StudentUser = {
  id: string; fullName: string; universityId: string | null;
  branchName: string | null; academicYear: string | null; photoUrl: string | null;
};

// ===== أدوات مساعدة =====
function fmtSize(bytes: number): string {
  if (bytes >= 1024 * 1024) return `${(bytes / 1048576).toFixed(1)} MB`;
  if (bytes >= 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${bytes} بايت`;
}

function baghdadToday(): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Baghdad", year: "numeric", month: "2-digit", day: "2-digit",
  }).format(new Date());
}

// ===== عرض Markdown بتنسيق يدوي (جداول/قوائم/أكواد) =====
const MD_COMPONENTS: Components = {
  h1: ({ children }) => <h1 className="text-xl font-extrabold mt-5 mb-3 first:mt-0">{children}</h1>,
  h2: ({ children }) => <h2 className="text-lg font-bold mt-4 mb-2 first:mt-0">{children}</h2>,
  h3: ({ children }) => <h3 className="text-base font-bold mt-3 mb-1.5 first:mt-0">{children}</h3>,
  p: ({ children }) => <p className="leading-8 my-2.5 first:mt-0 last:mb-0">{children}</p>,
  ul: ({ children }) => <ul className="list-disc ps-6 my-2.5 space-y-1">{children}</ul>,
  ol: ({ children }) => <ol className="list-decimal ps-6 my-2.5 space-y-1">{children}</ol>,
  li: ({ children }) => <li className="leading-7">{children}</li>,
  strong: ({ children }) => <strong className="font-bold">{children}</strong>,
  blockquote: ({ children }) => (
    <blockquote className="border-s-4 border-primary/40 ps-4 py-1 my-3 text-muted-foreground">{children}</blockquote>
  ),
  a: ({ href, children }) => (
    <a href={href} className="text-primary underline underline-offset-4 break-all" target="_blank" rel="noreferrer">{children}</a>
  ),
  img: ({ src, alt }) => <img src={src} alt={alt ?? ""} className="max-w-full rounded-xl my-3" loading="lazy" />,
  hr: () => <hr className="my-4 border-border" />,
  table: ({ children }) => (
    <div className="overflow-x-auto my-4 rounded-lg border border-border">
      <table className="w-full text-sm border-collapse">{children}</table>
    </div>
  ),
  thead: ({ children }) => <thead className="bg-muted/70">{children}</thead>,
  th: ({ children }) => <th className="border border-border px-3 py-2 text-start font-bold whitespace-nowrap">{children}</th>,
  td: ({ children }) => <td className="border border-border px-3 py-2 align-top">{children}</td>,
  pre: ({ children }) => (
    <pre dir="ltr" className="bg-muted rounded-lg p-4 my-3 overflow-x-auto text-[13px] leading-6 font-mono text-start">{children}</pre>
  ),
  code: (props) => {
    const isBlock = typeof props.className === "string" && props.className.includes("language-");
    if (isBlock) return <code className="font-mono text-[13px]">{props.children}</code>;
    return <code dir="ltr" className="bg-muted rounded px-1.5 py-0.5 font-mono text-[13px] text-primary">{props.children}</code>;
  },
};

function MarkdownView({ text }: { text: string }) {
  if (!text.trim()) {
    return <p className="text-sm text-muted-foreground">لا يوجد محتوى تفصيلي لهذه المحاضرة بعد.</p>;
  }
  return (
    <div dir="auto" className="text-[15px]">
      <ReactMarkdown remarkPlugins={[remarkGfm]} components={MD_COMPONENTS}>{text}</ReactMarkdown>
    </div>
  );
}

// ==================================================================
// الصفحة الرئيسية للمادة
// ==================================================================
export function SubjectView({ subjectId }: { subjectId: string }) {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["subject", subjectId],
    queryFn: () => api<{ subject: SubjectDetail }>(`/api/subjects/${encodeURIComponent(subjectId)}`),
  });
  const subject = data?.subject ?? null;

  if (isLoading) {
    return (
      <div className="space-y-4" aria-busy="true">
        <Skeleton className="h-5 w-72" />
        <Skeleton className="h-12 w-96" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}
        </div>
        <Skeleton className="h-64 rounded-2xl" />
      </div>
    );
  }
  if (error) {
    return <ErrorState message={error instanceof Error ? error.message : "تعذر تحميل المادة"} onRetry={refetch} />;
  }
  if (!subject) return <ErrorState message="المادة غير موجودة" onRetry={() => navigate("/stages")} />;

  return (
    <div>
      {/* مسار التنقل */}
      <Breadcrumb className="mb-4" aria-label="مسار التنقل">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <button type="button" className="cursor-pointer" onClick={() => navigate("/dashboard")}>الرئيسية</button>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <button type="button" className="cursor-pointer" onClick={() => navigate("/stages")}>المراحل</button>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <button type="button" className="cursor-pointer" onClick={() => navigate(`/stages/${subject.stageId}`)}>{subject.stageName}</button>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <button type="button" className="cursor-pointer" onClick={() => navigate(`/branches/${subject.branchId}`)}>{subject.branchName}</button>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbPage>{subject.nameAr}</BreadcrumbPage>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      <PageHeader
        title={subject.nameAr}
        description={`${subject.code} — ${subject.branchName} — ${subject.stageName}`}
        icon={<BookOpen className="w-6 h-6" />}
      />

      {/* التدريسيون */}
      <div className="flex flex-wrap items-center gap-2 mb-4">
        <span className="text-sm text-muted-foreground inline-flex items-center gap-1.5">
          <GraduationCap className="w-4 h-4" />
          التدريسيون:
        </span>
        {subject.instructors.length > 0 ? (
          subject.instructors.map((i) => (
            <Badge key={i.id} variant="secondary" className="gap-1 py-1 px-2.5">
              {i.name}
            </Badge>
          ))
        ) : (
          <span className="text-sm text-muted-foreground/70">لا يوجد تدريسيون مسندون</span>
        )}
      </div>

      {/* أرقام سريعة */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        <StatCard label="محاضرات" value={subject.lecturesCount} icon={<Video className="w-5 h-5" />} tone="primary" />
        <StatCard label="جلسات حضور" value={subject.sessionsCount} icon={<CalendarCheck className="w-5 h-5" />} tone="accent" />
        <StatCard label="طلاب الفرع" value={subject.studentsCount} icon={<Users className="w-5 h-5" />} tone="warning" />
        <StatCard label="تدريسيون" value={subject.instructors.length} icon={<GraduationCap className="w-5 h-5" />} tone="neutral" />
      </div>

      {/* التبويبات */}
      <Tabs defaultValue="lectures">
        <TabsList className="w-full grid grid-cols-3 mb-4">
          <TabsTrigger value="lectures" className="gap-1.5">
            <Video className="w-4 h-4" />
            المحاضرات
          </TabsTrigger>
          <TabsTrigger value="sessions" className="gap-1.5">
            <CalendarCheck className="w-4 h-4" />
            جلسات الحضور
          </TabsTrigger>
          <TabsTrigger value="students" className="gap-1.5">
            <Users className="w-4 h-4" />
            الطلاب
          </TabsTrigger>
        </TabsList>

        <TabsContent value="lectures">
          <LecturesTab subjectId={subjectId} />
        </TabsContent>
        <TabsContent value="sessions">
          <SessionsTab subjectId={subjectId} />
        </TabsContent>
        <TabsContent value="students">
          <StudentsTab subject={subject} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ==================================================================
// تبويب المحاضرات
// ==================================================================
function LecturesTab({ subjectId }: { subjectId: string }) {
  const { hasScope } = useApp();
  const canCreate = hasScope("lectures.create");
  const canUpdate = hasScope("lectures.update");
  const canDelete = hasScope("lectures.delete");

  const qc = useQueryClient();
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState<LectureItem | null>(null);
  const [viewing, setViewing] = useState<LectureItem | null>(null);

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["lectures", subjectId],
    queryFn: () => api<{ items: LectureItem[] }>(`/api/lectures?subjectId=${encodeURIComponent(subjectId)}`),
  });
  const lectures = data?.items ?? [];
  const editing = lectures.find((l) => l.id === editingId) ?? null;

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api(`/api/lectures/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      toast.success("تم حذف المحاضرة");
      setDeleting(null);
      qc.invalidateQueries({ queryKey: ["lectures", subjectId] });
      qc.invalidateQueries({ queryKey: ["subject", subjectId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <p className="text-sm text-muted-foreground">
          {lectures.length > 0 ? `${lectures.length} محاضرة — مرتبة حسب الأسبوع` : "قائمة محاضرات المادة"}
        </p>
        {canCreate && (
          <Button onClick={() => { setEditingId(null); setFormOpen(true); }}>
            <Plus className="w-4 h-4" />
            محاضرة جديدة
          </Button>
        )}
      </div>

      {isLoading && (
        <div className="space-y-3" aria-busy="true">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-36 rounded-2xl" />)}
        </div>
      )}
      {error && (
        <ErrorState message={error instanceof Error ? error.message : "تعذر تحميل المحاضرات"} onRetry={refetch} />
      )}
      {!isLoading && lectures.length === 0 && (
        <EmptyState
          message="لا توجد محاضرات بعد"
          sub={canCreate ? "أضف أول محاضرة بشرحها وملفاتها" : "لم تُضَف محاضرات لهذه المادة بعد"}
          action={canCreate && (
            <Button onClick={() => { setEditingId(null); setFormOpen(true); }}>
              <Plus className="w-4 h-4" />
              أضف أول محاضرة
            </Button>
          )}
        />
      )}

      <div className="space-y-3">
        {lectures.map((l) => (
          <Card key={l.id} className="rounded-2xl border-border/60 shadow-sm hover:shadow-md transition-all">
            <CardContent className="p-4 sm:p-5">
              <button
                type="button"
                className="w-full text-start cursor-pointer group"
                onClick={() => setViewing(l)}
                aria-label={`فتح محاضرة ${l.title}`}
              >
                <div className="flex flex-wrap items-center gap-2">
                  <Badge className={l.type === "PRACTICAL"
                    ? "bg-amber-100 text-amber-800 border-amber-200 hover:bg-amber-100"
                    : "bg-primary/10 text-primary border-primary/20 hover:bg-primary/10"}
                  >
                    {LECTURE_TYPE_LABELS[l.type as LectureType] ?? l.type}
                  </Badge>
                  {l.weekNo != null && (
                    <Badge variant="outline" className="text-[11px]">الأسبوع {l.weekNo}</Badge>
                  )}
                  {!l.isPublished && (
                    <Badge variant="outline" className="text-[11px] border-amber-300 text-amber-700 bg-amber-50">مسودة</Badge>
                  )}
                  <ChevronLeft className="w-5 h-5 ms-auto text-muted-foreground group-hover:text-primary group-hover:-translate-x-0.5 transition-all shrink-0" />
                </div>
                <p className="font-bold text-base sm:text-lg mt-2 leading-snug group-hover:text-primary transition-colors">{l.title}</p>
                {l.summary && (
                  <p className="text-sm text-muted-foreground mt-1.5 leading-6 line-clamp-2">{l.summary}</p>
                )}
                <p className="text-xs text-muted-foreground/80 mt-2.5">
                  {l.createdByName} — {fmtDateTime(l.createdAt)}
                </p>
              </button>

              {/* الملفات المرفقة */}
              {l.files.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {l.files.map((f) => (
                    <a
                      key={f.id}
                      href={f.url}
                      download
                      className="inline-flex items-center gap-1.5 rounded-lg border border-border/60 bg-muted/40 px-2.5 py-1.5 text-xs hover:bg-muted transition-colors"
                      aria-label={`تنزيل ${f.name}`}
                    >
                      <FileText className="w-3.5 h-3.5 text-primary/70" />
                      <span className="max-w-40 truncate font-medium">{f.name}</span>
                      <span className="text-muted-foreground text-[10px]">{fmtSize(f.sizeBytes)}</span>
                    </a>
                  ))}
                </div>
              )}

              {/* أدوات */}
              {(l.videoUrl || canUpdate || canDelete) && (
                <div className="mt-3 pt-3 border-t border-border/60 flex items-center justify-between gap-2">
                  {l.videoUrl ? (
                    <a
                      href={l.videoUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 text-sm text-primary hover:underline underline-offset-4"
                    >
                      <Video className="w-4 h-4" />
                      فيديو المحاضرة
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  ) : (
                    <span className="text-[11px] text-muted-foreground/60">
                      {l.files.length > 0 ? `${l.files.length} ملف مرفق` : "لا مرفقات"}
                    </span>
                  )}
                  {(canUpdate || canDelete) && (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-9 w-9" aria-label={`خيارات ${l.title}`}>
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-44">
                        <DropdownMenuItem onClick={() => setViewing(l)}>
                          <Eye className="w-4 h-4" />
                          عرض المحاضرة
                        </DropdownMenuItem>
                        {canUpdate && (
                          <DropdownMenuItem onClick={() => { setEditingId(l.id); setFormOpen(true); }}>
                            <Pencil className="w-4 h-4" />
                            تعديل المحاضرة
                          </DropdownMenuItem>
                        )}
                        {canDelete && (
                          <>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem variant="destructive" onClick={() => setDeleting(l)}>
                              <Trash2 className="w-4 h-4" />
                              حذف المحاضرة
                            </DropdownMenuItem>
                          </>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* نافذة عرض المحاضرة */}
      <LectureViewerDialog lecture={viewing} onClose={() => setViewing(null)} />

      {/* نافذة إنشاء/تعديل محاضرة */}
      {formOpen && (
        <LectureFormDialog
          open
          onOpenChange={(v) => { if (!v) { setFormOpen(false); setEditingId(null); } }}
          subjectId={subjectId}
          lecture={editing}
        />
      )}

      {/* تأكيد حذف محاضرة */}
      <AlertDialog open={!!deleting} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف المحاضرة</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف «{deleting?.title}» وكل ملفاتها المرفقة؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={(e) => {
                if (deleting) deleteMutation.mutate(deleting.id);
                e.preventDefault();
              }}
            >
              {deleteMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              حذف نهائي
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ===== نافذة عرض المحاضرة (شبه ملء الشاشة) =====
function LectureViewerDialog({ lecture, onClose }: { lecture: LectureItem | null; onClose: () => void }) {
  if (!lecture) return null;
  return (
    <Dialog open={!!lecture} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader className="text-start">
          <div className="flex flex-wrap items-center gap-2">
            <Badge className={lecture.type === "PRACTICAL"
              ? "bg-amber-100 text-amber-800 border-amber-200 hover:bg-amber-100"
              : "bg-primary/10 text-primary border-primary/20 hover:bg-primary/10"}
            >
              {LECTURE_TYPE_LABELS[lecture.type as LectureType] ?? lecture.type}
            </Badge>
            {lecture.weekNo != null && <Badge variant="outline">الأسبوع {lecture.weekNo}</Badge>}
            {!lecture.isPublished && (
              <Badge variant="outline" className="border-amber-300 text-amber-700 bg-amber-50">مسودة — غير منشورة</Badge>
            )}
          </div>
          <DialogTitle className="text-xl sm:text-2xl leading-snug text-start">{lecture.title}</DialogTitle>
          <DialogDescription className="text-start">
            {lecture.createdByName} — {fmtDateTime(lecture.createdAt)}
          </DialogDescription>
        </DialogHeader>

        {lecture.summary && (
          <p className="text-sm text-muted-foreground leading-7 rounded-xl bg-muted/50 p-3">{lecture.summary}</p>
        )}

        {lecture.videoUrl && (
          <a
            href={lecture.videoUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline underline-offset-4"
          >
            <Video className="w-4 h-4" />
            مشاهدة فيديو المحاضرة
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        )}

        <div className="rounded-xl border border-border/60 p-4 sm:p-5 bg-background">
          <MarkdownView text={lecture.contentMd ?? ""} />
        </div>

        {lecture.files.length > 0 && (
          <div>
            <p className="text-sm font-semibold mb-2">الملفات المرفقة ({lecture.files.length})</p>
            <div className="flex flex-wrap gap-2">
              {lecture.files.map((f) => (
                <a
                  key={f.id}
                  href={f.url}
                  download
                  className="inline-flex items-center gap-2 rounded-xl border border-border/60 bg-muted/40 px-3 py-2 text-xs hover:bg-muted transition-colors"
                  aria-label={`تنزيل ${f.name}`}
                >
                  <FileText className="w-4 h-4 text-primary" />
                  <span className="max-w-48 truncate font-medium">{f.name}</span>
                  <span className="text-muted-foreground">{fmtSize(f.sizeBytes)}</span>
                </a>
              ))}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ===== نافذة إنشاء/تعديل محاضرة (مع محرر Markdown ورفع ملفات) =====
function LectureFormDialog({
  open, onOpenChange, subjectId, lecture,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  subjectId: string;
  lecture: LectureItem | null;
}) {
  const qc = useQueryClient();
  // يُركّب المكوّن من جديد عند كل فتح فتُهيّأ القيم مباشرة من الخصائص
  const [title, setTitle] = useState(lecture?.title ?? "");
  const [summary, setSummary] = useState(lecture?.summary ?? "");
  const [weekNo, setWeekNo] = useState(lecture?.weekNo != null ? String(lecture.weekNo) : "");
  const [type, setType] = useState<LectureType>(lecture?.type === "PRACTICAL" ? "PRACTICAL" : "THEORY");
  const [videoUrl, setVideoUrl] = useState(lecture?.videoUrl ?? "");
  const [isPublished, setIsPublished] = useState(lecture?.isPublished ?? true);
  const [contentMd, setContentMd] = useState(lecture?.contentMd ?? "");
  const [filePick, setFilePick] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const valid = title.trim().length >= 3;

  const saveMutation = useMutation({
    mutationFn: () => {
      const body = JSON.stringify({
        title: title.trim(),
        summary: summary.trim() || null,
        contentMd: contentMd || null,
        weekNo: weekNo ? Number(weekNo) : null,
        type,
        videoUrl: videoUrl.trim() || null,
        isPublished,
        ...(lecture ? {} : { subjectId }),
      });
      return lecture
        ? api(`/api/lectures/${lecture.id}`, { method: "PATCH", body })
        : api("/api/lectures", { method: "POST", body });
    },
    onSuccess: () => {
      toast.success(lecture ? "تم تعديل المحاضرة" : "تمت إضافة المحاضرة");
      onOpenChange(false);
      qc.invalidateQueries({ queryKey: ["lectures", subjectId] });
      qc.invalidateQueries({ queryKey: ["subject", subjectId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  // رفع ملف مرفق (متاح في وضع التعديل فقط — المحاضرة يجب أن تكون منشأة)
  const uploadMutation = useMutation({
    mutationFn: async () => {
      if (!lecture || !filePick) throw new Error("اختر ملفاً أولاً");
      const fd = new FormData();
      fd.append("lectureId", lecture.id);
      fd.append("file", filePick);
      return api<{ file: LectureFileDTO }>("/api/files", { method: "POST", body: fd });
    },
    onSuccess: () => {
      toast.success("تم رفع الملف بنجاح");
      setFilePick(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
      qc.invalidateQueries({ queryKey: ["lectures", subjectId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="text-start">
          <DialogTitle>{lecture ? "تعديل المحاضرة" : "محاضرة جديدة"}</DialogTitle>
          <DialogDescription>
            {lecture ? "عدّل بيانات المحاضرة ومحتواها وملفاتها" : "أدخل بيانات المحاضرة وشرحها بصيغة Markdown"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="lecture-title">عنوان المحاضرة</Label>
              <Input
                id="lecture-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="مثال: مقدمة في الشبكات"
                maxLength={120}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lecture-week">رقم الأسبوع</Label>
              <Input
                id="lecture-week"
                type="number"
                min={1}
                max={30}
                value={weekNo}
                onChange={(e) => setWeekNo(e.target.value)}
                placeholder="1"
              />
            </div>
            <div className="space-y-2">
              <Label>نوع المحاضرة</Label>
              <Select value={type} onValueChange={(v) => setType(v === "PRACTICAL" ? "PRACTICAL" : "THEORY")}>
                <SelectTrigger className="w-full" aria-label="نوع المحاضرة">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="THEORY">نظري</SelectItem>
                  <SelectItem value="PRACTICAL">عملي</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="lecture-summary">ملخص</Label>
              <Input
                id="lecture-summary"
                value={summary}
                onChange={(e) => setSummary(e.target.value)}
                placeholder="سطر موجز يظهر في قائمة المحاضرات"
                maxLength={200}
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="lecture-video">رابط الفيديو (اختياري)</Label>
              <Input
                id="lecture-video"
                type="url"
                dir="ltr"
                value={videoUrl}
                onChange={(e) => setVideoUrl(e.target.value)}
                placeholder="https://youtube.com/watch?v=…"
              />
            </div>
          </div>

          {/* محرر Markdown بسيط: كتابة + معاينة */}
          <div className="space-y-2">
            <Label>شرح المحاضرة (Markdown)</Label>
            <Tabs defaultValue="write">
              <TabsList className="mb-2">
                <TabsTrigger value="write" className="gap-1.5 text-xs">
                  <PenLine className="w-3.5 h-3.5" />
                  كتابة
                </TabsTrigger>
                <TabsTrigger value="preview" className="gap-1.5 text-xs">
                  <Eye className="w-3.5 h-3.5" />
                  معاينة
                </TabsTrigger>
              </TabsList>
              <TabsContent value="write">
                <Textarea
                  value={contentMd}
                  onChange={(e) => setContentMd(e.target.value)}
                  dir="auto"
                  rows={10}
                  placeholder={"# عنوان\n\nاكتب الشرح هنا… يدعم **عريض** وقوائم وجداول:\n\n| المفهوم | الوصف |\n|---|---|\n| OSI | 7 طبقات |"}
                  className="leading-7 font-inherit"
                />
                <p className="text-[11px] text-muted-foreground mt-1.5">
                  يدعم العناوين (#)، القوائم، الجداول، والأكواد — تُعرض كما ستظهر للطالب
                </p>
              </TabsContent>
              <TabsContent value="preview">
                <div className="min-h-40 rounded-xl border border-border/60 p-4 bg-muted/20">
                  <MarkdownView text={contentMd} />
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* رفع الملفات — في وضع التعديل فقط */}
          {lecture && (
            <div className="space-y-2.5 rounded-xl border border-border/60 p-4">
              <Label className="flex items-center gap-2">
                <Upload className="w-4 h-4 text-primary" />
                الملفات المرفقة
              </Label>
              {lecture.files.length > 0 ? (
                <div className="space-y-1.5">
                  {lecture.files.map((f) => (
                    <div key={f.id} className="flex items-center gap-2 text-xs rounded-lg bg-muted/40 px-2.5 py-2">
                      <FileText className="w-4 h-4 text-primary/70 shrink-0" />
                      <a href={f.url} download className="truncate font-medium hover:text-primary hover:underline underline-offset-4">{f.name}</a>
                      <span className="text-muted-foreground ms-auto shrink-0">{fmtSize(f.sizeBytes)}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground">لا ملفات مرفقة بعد</p>
              )}
              <div className="flex flex-col sm:flex-row gap-2">
                <Input
                  ref={fileInputRef}
                  type="file"
                  accept={ALLOWED_UPLOAD_MIME.join(",")}
                  onChange={(e) => setFilePick(e.target.files?.[0] ?? null)}
                  className="text-xs"
                  aria-label="اختيار ملف للرفع"
                />
                <Button
                  type="button"
                  variant="secondary"
                  className="shrink-0"
                  disabled={!filePick || uploadMutation.isPending}
                  onClick={() => uploadMutation.mutate()}
                >
                  {uploadMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                  رفع الملف
                </Button>
              </div>
              <p className="text-[11px] text-muted-foreground">
                PDF / PowerPoint / Word / صور — بحد أقصى 25MB للملف
              </p>
            </div>
          )}

          {/* مفتاح النشر */}
          <div className="flex items-center justify-between rounded-xl border border-border/60 px-4 py-3">
            <div>
              <Label htmlFor="lecture-publish" className="cursor-pointer">نشر المحاضرة للطلاب</Label>
              <p className="text-xs text-muted-foreground mt-0.5">
                {isPublished ? "مرئية لطلاب المرحلة" : "مسودة — يراها التدريسيون والإدارة فقط"}
              </p>
            </div>
            <Switch
              id="lecture-publish"
              checked={isPublished}
              onCheckedChange={setIsPublished}
              aria-label="نشر المحاضرة"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button disabled={!valid || saveMutation.isPending} onClick={() => saveMutation.mutate()}>
            {saveMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            {lecture ? "حفظ التعديلات" : "إضافة المحاضرة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ==================================================================
// تبويب جلسات الحضور
// ==================================================================
function SessionsTab({ subjectId }: { subjectId: string }) {
  const { hasScope } = useApp();
  const canManageSessions = hasScope("attendance.session.manage");
  const canScan = hasScope("attendance.scan");

  const [dialogOpen, setDialogOpen] = useState(false);

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["sessions", subjectId],
    queryFn: () => api<{ items: SessionItem[] }>(`/api/attendance/sessions?subjectId=${encodeURIComponent(subjectId)}`),
  });
  const sessions = useMemo(
    () => [...(data?.items ?? [])].sort((a, b) => new Date(b.startsAt).getTime() - new Date(a.startsAt).getTime()),
    [data],
  );

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <p className="text-sm text-muted-foreground">
          {sessions.length > 0 ? `${sessions.length} جلسة حضور للمادة` : "جلسات حضور المادة"}
        </p>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => navigate(`/reports?subject=${encodeURIComponent(subjectId)}`)}
          >
            <Table2 className="w-4 h-4" />
            المصفوفة
          </Button>
          {canManageSessions && (
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="w-4 h-4" />
              إنشاء جلسة
            </Button>
          )}
        </div>
      </div>

      {isLoading && (
        <div className="space-y-3" aria-busy="true">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-32 rounded-2xl" />)}
        </div>
      )}
      {error && (
        <ErrorState message={error instanceof Error ? error.message : "تعذر تحميل الجلسات"} onRetry={refetch} />
      )}
      {!isLoading && sessions.length === 0 && (
        <EmptyState
          message="لا توجد جلسات حضور بعد"
          sub={canManageSessions ? "أنشئ أول جلسة ثم افتح الماسح لتسجيل الحضور" : "لم تُنشأ جلسات لهذه المادة بعد"}
          action={canManageSessions && (
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="w-4 h-4" />
              إنشاء أول جلسة
            </Button>
          )}
        />
      )}

      <div className="space-y-3">
        {sessions.map((s) => (
          <Card key={s.id} className="rounded-2xl border-border/60 shadow-sm">
            <CardContent className="p-4 sm:p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="p-2.5 rounded-xl bg-sky-100 text-sky-700 shrink-0">
                    <CalendarCheck className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold">{fmtWeekday(s.date)} — {fmtDate(s.date)}</p>
                    <p className="text-sm text-muted-foreground mt-0.5 tabular-nums">
                      {fmtTime(s.startsAt)} — {fmtTime(s.endsAt)}
                      {s.room && <span className="mx-1.5">•</span>}
                      {s.room ? `قاعة ${s.room}` : "بدون قاعة"}
                    </p>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <SessionStatusBadge status={s.status} />
                  <Badge variant="outline" className="text-[11px]">
                    مسجلون: {s.total}
                  </Badge>
                  <Badge variant="outline" className="text-[11px]">
                    تأخير بعد {s.lateAfterMin} د
                  </Badge>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-border/60 flex flex-wrap items-center gap-2">
                {canScan && (
                  <Button size="sm" onClick={() => navigate(`/scan/${s.id}`)}>
                    <QrCode className="w-4 h-4" />
                    فتح الماسح
                  </Button>
                )}
                <Button size="sm" variant="outline" onClick={() => navigate(`/reports?subject=${encodeURIComponent(subjectId)}`)}>
                  <Table2 className="w-4 h-4" />
                  المصفوفة
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {dialogOpen && (
        <SessionFormDialog
          open
          onOpenChange={setDialogOpen}
          subjectId={subjectId}
        />
      )}
    </div>
  );
}

function SessionStatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    OPEN: "bg-emerald-100 text-emerald-800 border-emerald-200",
    CLOSED: "bg-muted text-muted-foreground border-border",
    SCHEDULED: "bg-sky-100 text-sky-800 border-sky-200",
  };
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold border ${map[status] ?? map.SCHEDULED}`}>
      <span aria-hidden="true" className={`w-2 h-2 rounded-full ${status === "OPEN" ? "bg-emerald-500" : status === "CLOSED" ? "bg-muted-foreground/50" : "bg-sky-500"}`} />
      {SESSION_STATUS_LABELS[status as SessionStatus] ?? status}
    </span>
  );
}

// ===== نافذة إنشاء جلسة حضور =====
function SessionFormDialog({
  open, onOpenChange, subjectId,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  subjectId: string;
}) {
  const qc = useQueryClient();
  // يُركّب المكوّن من جديد عند كل فتح فتُهيّأ القيم مباشرة من الخصائص
  const [date, setDate] = useState(baghdadToday());
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("10:30");
  const [room, setRoom] = useState("");
  const [lateAfterMin, setLateAfterMin] = useState("15");

  const valid = !!date && /^\d{2}:\d{2}$/.test(startTime) && /^\d{2}:\d{2}$/.test(endTime) && startTime < endTime;

  const mutation = useMutation({
    mutationFn: () =>
      api("/api/attendance/sessions", {
        method: "POST",
        body: JSON.stringify({
          subjectId,
          date,
          startTime,
          endTime,
          room: room.trim() || null,
          lateAfterMin: Number(lateAfterMin) || 15,
        }),
      }),
    onSuccess: () => {
      toast.success("تم إنشاء جلسة الحضور");
      onOpenChange(false);
      qc.invalidateQueries({ queryKey: ["sessions", subjectId] });
      qc.invalidateQueries({ queryKey: ["subject", subjectId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>إنشاء جلسة حضور</DialogTitle>
          <DialogDescription>حدد التاريخ والأوقات والقاعة — بالتوقيت المحلي (بغداد)</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="session-date">التاريخ</Label>
            <Input id="session-date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="session-start">وقت البداية</Label>
              <Input id="session-start" type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="session-end">وقت النهاية</Label>
              <Input id="session-end" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="session-room">القاعة (اختياري)</Label>
              <Input id="session-room" value={room} onChange={(e) => setRoom(e.target.value)} placeholder="مثال: قاعة 2" maxLength={40} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="session-late">التأخير بعد (دقائق)</Label>
              <Input id="session-late" type="number" min={0} max={120} value={lateAfterMin} onChange={(e) => setLateAfterMin(e.target.value)} />
            </div>
          </div>
          {!valid && (startTime >= endTime) && (
            <p className="text-xs text-destructive">وقت النهاية يجب أن يكون بعد وقت البداية</p>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button disabled={!valid || mutation.isPending} onClick={() => mutation.mutate()}>
            {mutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            إنشاء الجلسة
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ==================================================================
// تبويب الطلاب
// ==================================================================
function StudentsTab({ subject }: { subject: SubjectDetail }) {
  const { hasScope } = useApp();
  const canListStudents = hasScope("users.manage");
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <div>
      <div className="grid sm:grid-cols-2 gap-3">
        <StatCard
          label={`طلاب ${subject.branchName}`}
          value={subject.studentsCount}
          icon={<Users className="w-5 h-5" />}
          tone="primary"
          hint={`المرحلة: ${subject.stageName}`}
        />
        <Card className="rounded-2xl border-border/60 shadow-sm">
          <CardContent className="p-4 flex flex-col items-start justify-center gap-3 h-full">
            <p className="text-sm text-muted-foreground leading-6">
              {canListStudents
                ? "اعرض قائمة طلاب الفرع المسجّلين في هذه المادة مع أرقامهم الجامعية."
                : "القائمة التفصيلية للطلاب متاحة لمديري النظام وأصحاب صلاحية إدارة المستخدمين."}
            </p>
            {canListStudents && (
              <Button variant="secondary" onClick={() => setDialogOpen(true)}>
                <Users className="w-4 h-4" />
                عرض الطلاب
              </Button>
            )}
          </CardContent>
        </Card>
      </div>

      {dialogOpen && (
        <StudentsDialog
          open
          onOpenChange={setDialogOpen}
          branchName={subject.branchName}
        />
      )}
    </div>
  );
}

// ===== نافذة قائمة طلاب الفرع =====
function StudentsDialog({
  open, onOpenChange, branchName,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  branchName: string;
}) {
  const [search, setSearch] = useState("");

  const studentsQ = useQuery({
    queryKey: ["admin-users", "STUDENT"],
    queryFn: () => api<{ items: StudentUser[] }>("/api/admin/users?role=STUDENT"),
    enabled: open,
  });

  const branchStudents = useMemo(
    () => (studentsQ.data?.items ?? []).filter((u) => u.branchName === branchName),
    [studentsQ.data, branchName],
  );
  const filtered = useMemo(() => {
    const q = search.trim();
    if (!q) return branchStudents;
    return branchStudents.filter(
      (u) => u.fullName.includes(q) || (u.universityId ?? "").includes(q),
    );
  }, [branchStudents, search]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            طلاب {branchName}
          </DialogTitle>
          <DialogDescription>
            {studentsQ.isLoading ? "جارٍ التحميل…" : `${branchStudents.length} طالب مسجّل في هذا الفرع`}
          </DialogDescription>
        </DialogHeader>

        <div className="relative">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث بالاسم أو الرقم الجامعي…"
            className="ps-9"
          />
        </div>

        {studentsQ.isLoading && (
          <div className="space-y-2" aria-busy="true">
            {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-14 rounded-xl" />)}
          </div>
        )}
        {studentsQ.error && (
          <ErrorState
            message={studentsQ.error instanceof Error ? studentsQ.error.message : "تعذر تحميل الطلاب"}
            onRetry={() => studentsQ.refetch()}
          />
        )}
        {studentsQ.data && filtered.length === 0 && (
          <p className="py-8 text-center text-sm text-muted-foreground">
            {search ? "لا نتائج مطابقة للبحث" : "لا يوجد طلاب في هذا الفرع"}
          </p>
        )}
        {filtered.length > 0 && (
          <ScrollArea className="h-80 rounded-xl border border-border/60">
            <div className="divide-y divide-border/60">
              {filtered.map((u, idx) => (
                <div key={u.id} className="flex items-center gap-3 px-4 py-3">
                  <span className="w-8 h-8 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center shrink-0 tabular-nums" aria-hidden="true">
                    {idx + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold truncate">{u.fullName}</p>
                    <p className="text-xs text-muted-foreground tabular-nums">
                      {u.universityId ?? "—"}
                      {u.academicYear && <span> • {u.academicYear}</span>}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </DialogContent>
    </Dialog>
  );
}
