"use client";
// المراحل والفروع — شبكة بطاقات + CRUD كامل (structure.manage)
import { Fragment, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { api } from "@/lib/client/api";
import { navigate, useApp } from "@/lib/client/store";
import { EmptyState, ErrorState, PageHeader } from "@/components/app/shared/ui-bits";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  Layers, School, GitBranch, Users, Plus, Pencil, Trash2, ChevronLeft, Loader2,
} from "lucide-react";

// ===== الأنواع =====
type StageItem = { id: string; nameAr: string; level: number; branchesCount: number; studentsCount: number };
type BranchItem = { id: string; nameAr: string; stageId: string; stageName: string; subjectsCount: number; studentsCount: number };

// ===== نقطة الدخول — وضعان: قائمة المراحل أو صفحة مرحلة =====
export function StagesView({ stageId }: { stageId?: string }) {
  return stageId ? <StageDetailPage stageId={stageId} /> : <StagesListPage />;
}

// ===== مسار التنقل =====
function Crumbs({ items }: { items: { label: string; onClick?: () => void }[] }) {
  return (
    <Breadcrumb className="mb-4" aria-label="مسار التنقل">
      <BreadcrumbList>
        {items.map((it, i) => (
          <Fragment key={`${it.label}-${i}`}>
            <BreadcrumbItem>
              {it.onClick ? (
                <BreadcrumbLink asChild>
                  <button type="button" onClick={it.onClick} className="cursor-pointer">{it.label}</button>
                </BreadcrumbLink>
              ) : (
                <BreadcrumbPage>{it.label}</BreadcrumbPage>
              )}
            </BreadcrumbItem>
            {i < items.length - 1 && <BreadcrumbSeparator />}
          </Fragment>
        ))}
      </BreadcrumbList>
    </Breadcrumb>
  );
}

// ==================================================================
// القائمة الرئيسية — كل المراحل
// ==================================================================
function StagesListPage() {
  const canManage = useApp().hasScope("structure.manage");
  const qc = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<StageItem | null>(null);
  const [deleting, setDeleting] = useState<StageItem | null>(null);

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["stages"],
    queryFn: () => api<{ items: StageItem[] }>("/api/stages"),
  });

  const removeMutation = useMutation({
    mutationFn: (id: string) => api(`/api/stages/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      toast.success("تم حذف المرحلة");
      setDeleting(null);
      qc.invalidateQueries({ queryKey: ["stages"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div>
      <Crumbs items={[{ label: "الرئيسية", onClick: () => navigate("/dashboard") }, { label: "المراحل" }]} />
      <PageHeader
        title="المراحل الدراسية"
        description="تصفح مراحل الكلية وفروعها التدريسية"
        icon={<Layers className="w-6 h-6" />}
        actions={
          canManage && (
            <Button
              onClick={() => { setEditing(null); setDialogOpen(true); }}
            >
              <Plus className="w-4 h-4" />
              إضافة مرحلة
            </Button>
          )
        }
      />

      {isLoading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4" aria-busy="true">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-40 rounded-2xl" />
          ))}
        </div>
      )}

      {error && <ErrorState message={error instanceof Error ? error.message : "تعذر تحميل المراحل"} onRetry={refetch} />}

      {data && data.items.length === 0 && (
        <EmptyState
          message="لا توجد مراحل بعد"
          sub={canManage ? "أضف أول مرحلة لبدء بناء الهيكل الأكاديمي للكلية" : "لم يُضِف أي هيكل أكاديمي بعد"}
          action={canManage && (
            <Button onClick={() => { setEditing(null); setDialogOpen(true); }}>
              <Plus className="w-4 h-4" />
              أضف أول مرحلة
            </Button>
          )}
        />
      )}

      {data && data.items.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.items.map((s) => (
            <Card key={s.id} className="rounded-2xl border-border/60 shadow-sm hover:shadow-md transition-all">
              <CardContent className="p-5">
                <button
                  type="button"
                  className="w-full text-start cursor-pointer group"
                  onClick={() => navigate(`/stages/${s.id}`)}
                  aria-label={`فتح ${s.nameAr}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-primary/10 text-primary shrink-0">
                      <School className="w-5 h-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-bold text-base sm:text-lg truncate">{s.nameAr}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">المرحلة رقم {s.level}</p>
                    </div>
                    <ChevronLeft className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:-translate-x-0.5 transition-all shrink-0" />
                  </div>
                  <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="inline-flex items-center gap-1.5">
                      <GitBranch className="w-4 h-4 text-primary/70" />
                      {s.branchesCount} فروع
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-primary/70" />
                      {s.studentsCount} طالب
                    </span>
                  </div>
                </button>
                {canManage && (
                  <div className="mt-4 pt-3 border-t border-border/60 flex items-center justify-end gap-1">
                    <Button
                      variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-foreground"
                      aria-label={`تعديل ${s.nameAr}`}
                      onClick={() => { setEditing(s); setDialogOpen(true); }}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-destructive"
                      aria-label={`حذف ${s.nameAr}`}
                      onClick={() => setDeleting(s)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* نافذة إنشاء/تعديل مرحلة */}
      {dialogOpen && (
        <StageDialog
          open
          onOpenChange={(v) => { if (!v) { setDialogOpen(false); setEditing(null); } }}
          stage={editing}
        />
      )}

      {/* تأكيد حذف مرحلة */}
      <AlertDialog open={!!deleting} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف المرحلة</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف «{deleting?.nameAr}»؟ سيتم حذف كل الفروع والمواد التابعة لها. لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={(e) => {
                if (deleting) removeMutation.mutate(deleting.id, { onSuccess: () => setDeleting(null) });
                e.preventDefault();
              }}
            >
              {removeMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              حذف نهائي
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ==================================================================
// صفحة المرحلة — الفروع التدريسية
// ==================================================================
function StageDetailPage({ stageId }: { stageId: string }) {
  const canManage = useApp().hasScope("structure.manage");
  const qc = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<StageItem | null>(null);
  const [deleting, setDeleting] = useState<StageItem | null>(null);
  const [branchDialogOpen, setBranchDialogOpen] = useState(false);
  const [editingBranch, setEditingBranch] = useState<BranchItem | null>(null);
  const [deletingBranch, setDeletingBranch] = useState<BranchItem | null>(null);

  const stagesQ = useQuery({
    queryKey: ["stages"],
    queryFn: () => api<{ items: StageItem[] }>("/api/stages"),
  });
  const stage = stagesQ.data?.items.find((s) => s.id === stageId) ?? null;

  const branchesQ = useQuery({
    queryKey: ["branches", stageId],
    queryFn: () => api<{ items: BranchItem[] }>(`/api/branches?stageId=${encodeURIComponent(stageId)}`),
    enabled: !!stage,
  });

  const removeStageMutation = useMutation({
    mutationFn: (id: string) => api(`/api/stages/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      toast.success("تم حذف المرحلة");
      setDeleting(null);
      qc.invalidateQueries({ queryKey: ["stages"] });
      navigate("/stages");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const removeBranchMutation = useMutation({
    mutationFn: (id: string) => api(`/api/branches/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      toast.success("تم حذف الفرع");
      setDeletingBranch(null);
      qc.invalidateQueries({ queryKey: ["branches", stageId] });
      qc.invalidateQueries({ queryKey: ["stages"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (stagesQ.isLoading) {
    return (
      <div className="space-y-4" aria-busy="true">
        <Skeleton className="h-5 w-64" />
        <Skeleton className="h-10 w-72" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-40 rounded-2xl" />)}
        </div>
      </div>
    );
  }
  if (stagesQ.error) {
    return <ErrorState message={stagesQ.error instanceof Error ? stagesQ.error.message : "تعذر تحميل المرحلة"} onRetry={() => stagesQ.refetch()} />;
  }
  if (!stage) {
    return (
      <ErrorState
        message="المرحلة غير موجودة"
        onRetry={() => navigate("/stages")}
      />
    );
  }

  return (
    <div>
      <Crumbs
        items={[
          { label: "الرئيسية", onClick: () => navigate("/dashboard") },
          { label: "المراحل", onClick: () => navigate("/stages") },
          { label: stage.nameAr },
        ]}
      />
      <PageHeader
        title={stage.nameAr}
        description={`${stage.branchesCount} فروع تدريسية — ${stage.studentsCount} طالب`}
        icon={<School className="w-6 h-6" />}
        actions={
          <>
            {canManage && (
              <>
                <Button
                  variant="outline"
                  onClick={() => { setEditing(stage); setDialogOpen(true); }}
                >
                  <Pencil className="w-4 h-4" />
                  تعديل المرحلة
                </Button>
                <Button
                  variant="outline"
                  className="text-destructive hover:text-destructive"
                  onClick={() => setDeleting(stage)}
                >
                  <Trash2 className="w-4 h-4" />
                  حذف
                </Button>
                <Button onClick={() => { setEditingBranch(null); setBranchDialogOpen(true); }}>
                  <Plus className="w-4 h-4" />
                  إضافة فرع
                </Button>
              </>
            )}
          </>
        }
      />

      {branchesQ.isLoading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4" aria-busy="true">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-40 rounded-2xl" />)}
        </div>
      )}
      {branchesQ.error && (
        <ErrorState
          message={branchesQ.error instanceof Error ? branchesQ.error.message : "تعذر تحميل الفروع"}
          onRetry={() => branchesQ.refetch()}
        />
      )}
      {branchesQ.data && branchesQ.data.items.length === 0 && (
        <EmptyState
          message="لا توجد فروع في هذه المرحلة بعد"
          sub={canManage ? "أضف أول فرع تدريسي لهذه المرحلة" : "لم تُضَف فروع لهذه المرحلة بعد"}
          action={canManage && (
            <Button onClick={() => { setEditingBranch(null); setBranchDialogOpen(true); }}>
              <Plus className="w-4 h-4" />
              أضف أول فرع
            </Button>
          )}
        />
      )}
      {branchesQ.data && branchesQ.data.items.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {branchesQ.data.items.map((b) => (
            <Card key={b.id} className="rounded-2xl border-border/60 shadow-sm hover:shadow-md transition-all">
              <CardContent className="p-5">
                <button
                  type="button"
                  className="w-full text-start cursor-pointer group"
                  onClick={() => navigate(`/branches/${b.id}`)}
                  aria-label={`فتح مواد ${b.nameAr}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-sky-100 text-sky-700 shrink-0">
                      <GitBranch className="w-5 h-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-bold text-base sm:text-lg truncate">{b.nameAr}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">فرع تدريسي</p>
                    </div>
                    <ChevronLeft className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:-translate-x-0.5 transition-all shrink-0" />
                  </div>
                  <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="inline-flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-primary/70" />
                      {b.subjectsCount} مواد
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-primary/70" />
                      {b.studentsCount} طالب
                    </span>
                  </div>
                </button>
                {canManage && (
                  <div className="mt-4 pt-3 border-t border-border/60 flex items-center justify-end gap-1">
                    <Button
                      variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-foreground"
                      aria-label={`تعديل ${b.nameAr}`}
                      onClick={() => { setEditingBranch(b); setBranchDialogOpen(true); }}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-destructive"
                      aria-label={`حذف ${b.nameAr}`}
                      onClick={() => setDeletingBranch(b)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* نافذة تعديل المرحلة نفسها */}
      {dialogOpen && (
        <StageDialog
          open
          onOpenChange={(v) => { if (!v) { setDialogOpen(false); setEditing(null); } }}
          stage={editing}
        />
      )}
      {/* نافذة إنشاء/تعديل فرع */}
      {branchDialogOpen && (
        <BranchDialog
          open
          onOpenChange={(v) => { if (!v) { setBranchDialogOpen(false); setEditingBranch(null); } }}
          stageId={stageId}
          branch={editingBranch}
        />
      )}

      {/* تأكيد حذف المرحلة */}
      <AlertDialog open={!!deleting} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف المرحلة</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف «{deleting?.nameAr}»؟ سيتم حذف كل الفروع والمواد التابعة لها. لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={(e) => {
                if (deleting) removeStageMutation.mutate(deleting.id);
                e.preventDefault();
              }}
            >
              {removeStageMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              حذف نهائي
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* تأكيد حذف فرع */}
      <AlertDialog open={!!deletingBranch} onOpenChange={(v) => !v && setDeletingBranch(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف الفرع</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف «{deletingBranch?.nameAr}»؟ سيتم حذف كل المواد والمحاضرات التابعة له. لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={(e) => {
                if (deletingBranch) removeBranchMutation.mutate(deletingBranch.id);
                e.preventDefault();
              }}
            >
              {removeBranchMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              حذف نهائي
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ===== نافذة إنشاء/تعديل مرحلة =====
function StageDialog({
  open, onOpenChange, stage,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  stage: StageItem | null;
}) {
  const qc = useQueryClient();
  // يُركّب المكوّن من جديد عند كل فتح فتُهيّأ القيم مباشرة من الخصائص
  const [nameAr, setNameAr] = useState(stage?.nameAr ?? "");
  const [level, setLevel] = useState(String(stage?.level ?? 1));

  const valid = nameAr.trim().length >= 2;

  const mutation = useMutation({
    mutationFn: () => {
      const body = JSON.stringify({ nameAr: nameAr.trim(), level: Number(level) });
      return stage
        ? api(`/api/stages/${stage.id}`, { method: "PATCH", body })
        : api("/api/stages", { method: "POST", body });
    },
    onSuccess: () => {
      toast.success(stage ? "تم تعديل المرحلة" : "تمت إضافة المرحلة");
      onOpenChange(false);
      qc.invalidateQueries({ queryKey: ["stages"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{stage ? "تعديل المرحلة" : "إضافة مرحلة"}</DialogTitle>
          <DialogDescription>
            {stage ? "عدّل اسم المرحلة أو رقمها" : "أدخل اسم المرحلة ورقمها (من 1 إلى 10)"}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="stage-name">اسم المرحلة</Label>
            <Input
              id="stage-name"
              value={nameAr}
              onChange={(e) => setNameAr(e.target.value)}
              placeholder="مثال: المرحلة الثالثة"
              maxLength={60}
            />
          </div>
          <div className="space-y-2">
            <Label>رقم المرحلة</Label>
            <Select value={level} onValueChange={setLevel}>
              <SelectTrigger className="w-full" aria-label="رقم المرحلة">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => (
                  <SelectItem key={n} value={String(n)}>المرحلة {n}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button disabled={!valid || mutation.isPending} onClick={() => mutation.mutate()}>
            {mutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            {stage ? "حفظ التعديلات" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ===== نافذة إنشاء/تعديل فرع =====
function BranchDialog({
  open, onOpenChange, stageId, branch,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  stageId: string;
  branch: BranchItem | null;
}) {
  const qc = useQueryClient();
  // يُركّب المكوّن من جديد عند كل فتح فتُهيّأ القيم مباشرة من الخصائص
  const [nameAr, setNameAr] = useState(branch?.nameAr ?? "");

  const valid = nameAr.trim().length >= 2;

  const mutation = useMutation({
    mutationFn: () => {
      const body = JSON.stringify(branch ? { nameAr: nameAr.trim() } : { stageId, nameAr: nameAr.trim() });
      return branch
        ? api(`/api/branches/${branch.id}`, { method: "PATCH", body })
        : api("/api/branches", { method: "POST", body });
    },
    onSuccess: () => {
      toast.success(branch ? "تم تعديل الفرع" : "تمت إضافة الفرع");
      onOpenChange(false);
      qc.invalidateQueries({ queryKey: ["branches", stageId] });
      qc.invalidateQueries({ queryKey: ["stages"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{branch ? "تعديل الفرع" : "إضافة فرع"}</DialogTitle>
          <DialogDescription>
            {branch ? "عدّل اسم الفرع التدريسي" : "أدخل اسم الفرع التدريسي الجديد"}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-2">
          <Label htmlFor="branch-name">اسم الفرع</Label>
          <Input
            id="branch-name"
            value={nameAr}
            onChange={(e) => setNameAr(e.target.value)}
            placeholder="مثال: علوم الحاسوب"
            maxLength={60}
          />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button disabled={!valid || mutation.isPending} onClick={() => mutation.mutate()}>
            {mutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            {branch ? "حفظ التعديلات" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
