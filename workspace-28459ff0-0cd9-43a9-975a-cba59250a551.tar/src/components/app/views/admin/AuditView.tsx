"use client";
// سجل التدقيق — آخر العمليات على النظام مع الفلترة والتفاصيل (قبل/بعد)
import { useMemo, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/client/api";
import { ROLE_LABELS } from "@/lib/constants";
import { fmtDateTime } from "@/lib/date-fmt";
import { EmptyState, ErrorState, LoadingRows, PageHeader, StatCard } from "@/components/app/shared/ui-bits";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  BookOpen,
  CalendarCheck,
  CheckCircle2,
  ChevronLeft,
  Globe,
  History,
  Megaphone,
  MessageSquareWarning,
  RefreshCw,
  Search,
  ShieldCheck,
  Users,
  X,
  XCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";

// ===== الأنواع =====
type AuditItem = {
  id: string;
  actorId: string;
  actorName: string;
  actorRole: string;
  action: string;
  entity: string;
  entityId: string | null;
  before: unknown;
  after: unknown;
  reason: string | null;
  ip: string | null;
  createdAt: string;
};

const THIN_SCROLL =
  "[scrollbar-width:thin] [scrollbar-color:var(--border)_transparent] [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border [&::-webkit-scrollbar-track]:bg-transparent";

// تسميات الكيانات بالعربية
const ENTITY_LABELS: Record<string, string> = {
  User: "مستخدم",
  Stage: "مرحلة",
  Branch: "فرع",
  Subject: "مادة",
  Lecture: "محاضرة",
  ClassSession: "جلسة حضور",
  Attendance: "سجل حضور",
  RolePermission: "صلاحيات الأدوار",
  Announcement: "تبليغ",
  Notification: "إشعار",
};

// أيقونة الفعل حسب بادئته (تُعيد عنصراً جاهزاً)
function auditIconEl(action: string, className?: string): ReactNode {
  switch (action.split(".")[0]) {
    case "users":
      return <Users className={className} aria-hidden="true" />;
    case "attendance":
      return <CalendarCheck className={className} aria-hidden="true" />;
    case "lectures":
      return <BookOpen className={className} aria-hidden="true" />;
    case "permissions":
      return <ShieldCheck className={className} aria-hidden="true" />;
    case "announcements":
      return <Megaphone className={className} aria-hidden="true" />;
    default:
      return <History className={className} aria-hidden="true" />;
  }
}

const ACTION_TONES: Record<string, string> = {
  users: "bg-primary/10 text-primary",
  attendance: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300",
  lectures: "bg-sky-100 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300",
  permissions: "bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300",
  announcements: "bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300",
};

const ROLE_BADGE: Record<string, string> = {
  OWNER: "bg-emerald-900 text-emerald-50 border-emerald-950 dark:bg-emerald-950 dark:text-emerald-100 dark:border-emerald-800",
  DEAN: "bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-900",
  INSTRUCTOR: "bg-sky-100 text-sky-800 border-sky-200 dark:bg-sky-950/60 dark:text-sky-300 dark:border-sky-900",
  STUDENT_ADMIN: "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-900",
  STUDENT: "bg-muted text-muted-foreground border-border",
};

function actionTone(action: string): string {
  return ACTION_TONES[action.split(".")[0]] ?? "bg-muted text-muted-foreground";
}

function shortId(id: string | null): string | null {
  if (!id) return null;
  return id.length > 10 ? id.slice(0, 10) : id;
}

// ===== كتلة JSON (قبل/بعد) =====
function JsonBlock({ label, value, tone }: { label: string; value: unknown; tone: "before" | "after" }) {
  const text = typeof value === "string" ? value : JSON.stringify(value, null, 2);
  const isBefore = tone === "before";
  return (
    <div>
      <div
        className={cn(
          "flex items-center gap-1.5 font-semibold text-sm mb-1.5",
          isBefore ? "text-red-600 dark:text-red-400" : "text-emerald-700 dark:text-emerald-400"
        )}
      >
        {isBefore ? <XCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
        {label}
      </div>
      <pre
        dir="ltr"
        className={cn(
          "whitespace-pre-wrap break-all text-start text-xs font-mono rounded-xl border p-3 max-h-64 overflow-auto",
          isBefore
            ? "bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-900 text-red-900 dark:text-red-200"
            : "bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900 text-emerald-900 dark:text-emerald-200",
          THIN_SCROLL
        )}
      >
        {text}
      </pre>
    </div>
  );
}

// ===== صف سجل =====
function AuditRow({ item, onClick }: { item: AuditItem; onClick: () => void }) {
  return (
    <Card
      className="rounded-2xl border-border/60 shadow-sm cursor-pointer transition-all hover:shadow-md hover:border-primary/30 focus-visible:border-primary focus-visible:outline-none"
      onClick={onClick}
      role="button"
      tabIndex={0}
      aria-label={`تفاصيل عملية ${item.action} بواسطة ${item.actorName}`}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onClick();
        }
      }}
    >
      <CardContent className="p-3.5 sm:p-4 flex items-start gap-3">
        <div className={cn("p-2.5 rounded-xl shrink-0", actionTone(item.action))}>
          {auditIconEl(item.action, "w-5 h-5")}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <span className="font-semibold text-sm">{item.actorName}</span>
            <span
              className={cn(
                "inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold border",
                ROLE_BADGE[item.actorRole] ?? "bg-muted text-muted-foreground border-border"
              )}
            >
              {ROLE_LABELS[item.actorRole] ?? item.actorRole}
            </span>
            <code className="text-[11px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded font-mono" dir="ltr">
              {item.action}
            </code>
          </div>
          <p className="text-xs text-muted-foreground mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-0.5">
            <span className="font-medium text-foreground/80">{ENTITY_LABELS[item.entity] ?? item.entity}</span>
            {item.entityId && (
              <code className="font-mono text-[10px]" dir="ltr">
                #{shortId(item.entityId)}
              </code>
            )}
            <span aria-hidden="true">•</span>
            <time dateTime={item.createdAt}>{fmtDateTime(item.createdAt)}</time>
            {item.ip && (
              <>
                <span aria-hidden="true">•</span>
                <span className="inline-flex items-center gap-1">
                  <Globe className="w-3 h-3" aria-hidden="true" />
                  <code className="font-mono text-[10px]" dir="ltr">
                    {item.ip}
                  </code>
                </span>
              </>
            )}
          </p>
          {item.reason && (
            <p className="text-xs mt-1.5 text-amber-700 dark:text-amber-400 font-medium flex items-center gap-1.5">
              <MessageSquareWarning className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              السبب: {item.reason}
            </p>
          )}
        </div>
        <ChevronLeft className="w-4 h-4 text-muted-foreground shrink-0 mt-2" aria-hidden="true" />
      </CardContent>
    </Card>
  );
}

// ===== الواجهة =====
export function AuditView() {
  const [actorSearch, setActorSearch] = useState("");
  const [actionFilter, setActionFilter] = useState("all");
  const [selected, setSelected] = useState<AuditItem | null>(null);

  const auditQuery = useQuery({
    queryKey: ["admin-audit", 100],
    queryFn: () => api<{ items: AuditItem[] }>("/api/admin/audit?limit=100"),
  });
  const items = useMemo(() => auditQuery.data?.items ?? [], [auditQuery.data]);

  // أفعال فريدة من البيانات
  const uniqueActions = useMemo(() => {
    const set = new Set(items.map((i) => i.action));
    return Array.from(set).sort();
  }, [items]);

  // فلترة محلية (الفعل + بحث الفاعل)
  const filtered = useMemo(() => {
    const term = actorSearch.trim().toLowerCase();
    return items.filter((i) => {
      if (actionFilter !== "all" && i.action !== actionFilter) return false;
      if (term && !i.actorName.toLowerCase().includes(term)) return false;
      return true;
    });
  }, [items, actionFilter, actorSearch]);

  if (auditQuery.isLoading) {
    return (
      <div>
        <PageHeader title="سجل التدقيق" description="آخر العمليات التي أُجريت على النظام" icon={<History className="w-5 h-5" />} />
        <LoadingRows rows={7} />
      </div>
    );
  }
  if (auditQuery.isError)
    return (
      <ErrorState
        message={auditQuery.error instanceof Error ? auditQuery.error.message : "تعذر تحميل سجل التدقيق"}
        onRetry={() => auditQuery.refetch()}
      />
    );

  const SelectedIconTone = selected ? actionTone(selected.action) : "bg-muted text-muted-foreground";

  return (
    <div>
      <PageHeader
        title="سجل التدقيق"
        description="آخر العمليات التي أُجريت على النظام — بالتسلسل الزمني"
        icon={<History className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="icon" className="h-11 w-11" onClick={() => auditQuery.refetch()} aria-label="تحديث السجل">
            <RefreshCw className={cn("w-4 h-4", auditQuery.isFetching && "animate-spin")} />
          </Button>
        }
      />

      {/* إحصاءات */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
        <StatCard label="إجمالي السجلات" value={items.length} icon={<History className="w-5 h-5" />} tone="primary" hint="آخر 100 عملية" />
        <StatCard label="أفعال فريدة" value={uniqueActions.length} icon={<ShieldCheck className="w-5 h-5" />} tone="accent" />
        <StatCard
          label="نتائج الفلترة الحالية"
          value={filtered.length}
          icon={<Search className="w-5 h-5" />}
          tone="neutral"
          hint={actionFilter !== "all" || actorSearch ? "مفلترة" : "بدون فلترة"}
        />
      </div>

      {/* فلترة */}
      <Card className="rounded-2xl border-border/60 shadow-sm mb-4">
        <CardContent className="p-3 sm:p-4 flex flex-col sm:flex-row gap-2.5">
          <div className="relative flex-1">
            <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" aria-hidden="true" />
            <Input
              value={actorSearch}
              onChange={(e) => setActorSearch(e.target.value)}
              placeholder="بحث باسم الفاعل..."
              className="ps-9 pe-9 h-11"
              aria-label="بحث باسم الفاعل"
            />
            {actorSearch && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute end-0.5 top-1/2 -translate-y-1/2 h-10 w-10 text-muted-foreground"
                onClick={() => setActorSearch("")}
                aria-label="مسح البحث"
              >
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
          <Select value={actionFilter} onValueChange={setActionFilter}>
            <SelectTrigger className="w-full sm:w-60 h-11" aria-label="فلترة حسب الفعل">
              <SelectValue placeholder="كل الأفعال" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الأفعال ({uniqueActions.length})</SelectItem>
              {uniqueActions.map((a) => (
                <SelectItem key={a} value={a} className="font-mono text-xs" dir="ltr">
                  {a}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* القائمة */}
      {filtered.length === 0 ? (
        <EmptyState
          message="لا توجد سجلات مطابقة"
          sub={items.length === 0 ? "لم تُسجَّل أي عملية بعد" : "جرّب تغيير البحث أو الفلتر"}
          action={
            (actorSearch || actionFilter !== "all") && (
              <Button
                variant="outline"
                onClick={() => {
                  setActorSearch("");
                  setActionFilter("all");
                }}
              >
                إظهار الكل
              </Button>
            )
          }
        />
      ) : (
        <div className={cn("space-y-2.5 max-h-[70vh] overflow-y-auto pe-1", THIN_SCROLL)}>
          {filtered.map((item) => (
            <AuditRow key={item.id} item={item} onClick={() => setSelected(item)} />
          ))}
        </div>
      )}

      {/* تفاصيل العملية */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <span className={cn("p-1.5 rounded-lg inline-flex", SelectedIconTone)}>
                {selected && auditIconEl(selected.action, "w-5 h-5")}
              </span>
              تفاصيل العملية
            </DialogTitle>
            <DialogDescription>
              {selected && (
                <>
                  أُجريت بواسطة <span className="font-semibold text-foreground">{selected.actorName}</span> — {fmtDateTime(selected.createdAt)}
                </>
              )}
            </DialogDescription>
          </DialogHeader>
          {selected && (
            <div className="space-y-3">
              <div className="rounded-xl border border-border/60 divide-y divide-border/60 text-sm">
                <div className="flex items-center justify-between gap-2 px-3 py-2">
                  <span className="text-muted-foreground">الفعل</span>
                  <code className="font-mono text-xs bg-muted px-1.5 py-0.5 rounded" dir="ltr">
                    {selected.action}
                  </code>
                </div>
                <div className="flex items-center justify-between gap-2 px-3 py-2">
                  <span className="text-muted-foreground">الكيان</span>
                  <span className="font-medium">
                    {ENTITY_LABELS[selected.entity] ?? selected.entity}
                    {selected.entityId && (
                      <code className="font-mono text-[10px] text-muted-foreground ms-1.5" dir="ltr">
                        #{shortId(selected.entityId)}
                      </code>
                    )}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2 px-3 py-2">
                  <span className="text-muted-foreground">دور الفاعل</span>
                  <span
                    className={cn(
                      "inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border",
                      ROLE_BADGE[selected.actorRole] ?? "bg-muted text-muted-foreground border-border"
                    )}
                  >
                    {ROLE_LABELS[selected.actorRole] ?? selected.actorRole}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2 px-3 py-2">
                  <span className="text-muted-foreground">عنوان IP</span>
                  <code className="font-mono text-xs" dir="ltr">
                    {selected.ip ?? "—"}
                  </code>
                </div>
                <div className="flex items-center justify-between gap-2 px-3 py-2">
                  <span className="text-muted-foreground">التاريخ والوقت</span>
                  <span className="font-medium">{fmtDateTime(selected.createdAt)}</span>
                </div>
                {selected.reason && (
                  <div className="flex items-start justify-between gap-2 px-3 py-2 bg-amber-50 dark:bg-amber-950/25">
                    <span className="text-muted-foreground flex items-center gap-1.5">
                      <MessageSquareWarning className="w-4 h-4 text-amber-600" aria-hidden="true" />
                      السبب
                    </span>
                    <span className="font-medium text-amber-700 dark:text-amber-400 text-end">{selected.reason}</span>
                  </div>
                )}
              </div>

              {selected.before == null && selected.after == null ? (
                <p className="text-sm text-muted-foreground text-center py-4">لا توجد بيانات تفصيلية (قبل/بعد) لهذه العملية.</p>
              ) : (
                <>
                  {selected.before != null && <JsonBlock label="قبل" value={selected.before} tone="before" />}
                  {selected.after != null && <JsonBlock label="بعد" value={selected.after} tone="after" />}
                </>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
