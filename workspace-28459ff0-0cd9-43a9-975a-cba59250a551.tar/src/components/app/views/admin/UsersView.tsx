"use client";
// إدارة المستخدمين — قائمة/بحث/إنشاء/تعديل/تعيين كلمة مرور/باركود/تعطيل/حذف
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/client/api";
import { ROLE_LABELS, ROLE_KEYS } from "@/lib/constants";
import { fmtDate } from "@/lib/date-fmt";
import { EmptyState, ErrorState, LoadingPage, PageHeader, StatCard } from "@/components/app/shared/ui-bits";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import {
  AlertTriangle,
  BookOpen,
  Copy,
  Eye,
  EyeOff,
  GraduationCap,
  KeyRound,
  Loader2,
  MoreVertical,
  Pencil,
  QrCode,
  RefreshCw,
  Search,
  Trash2,
  UserCheck,
  UserPlus,
  UserX,
  Upload,
  Download,
  FileSpreadsheet,
  Users as UsersIcon,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";

// ===== الأنواع =====
type AdminUser = {
  id: string;
  email: string;
  fullName: string;
  universityId: string | null;
  phone: string | null;
  photoUrl: string | null;
  isActive: boolean;
  roleKey: string;
  roleName: string;
  mustChangePassword: boolean;
  stageName: string | null;
  branchName: string | null;
  academicYear: string | null;
  subjects: { id: string; name: string; code: string }[];
  createdAt: string;
};

type StageItem = { id: string; nameAr: string; level: number; branchesCount: number; studentsCount: number };
type BranchItem = { id: string; nameAr: string; stageId: string; stageName: string; subjectsCount: number; studentsCount: number };

type UserFormState = {
  fullName: string;
  email: string;
  password: string;
  roleKey: string;
  universityId: string;
  phone: string;
  stageId: string;
  branchId: string;
  academicYear: string;
  isActive: boolean;
};

// صف استيراد Excel
 type ImportRow = {
  fullName: string;
  email: string;
  universityId: string | null;
  roleKey: string;
  stageName: string | null;
  branchName: string | null;
  academicYear: string | null;
  error?: string | null;
};

const emptyForm: UserFormState = {
  fullName: "",
  email: "",
  password: "",
  roleKey: "STUDENT",
  universityId: "",
  phone: "",
  stageId: "",
  branchId: "",
  academicYear: "2025-2026",
  isActive: true,
};

// ===== ألوان شارة الدور =====
const ROLE_BADGE: Record<string, string> = {
  OWNER: "bg-emerald-900 text-emerald-50 border-emerald-950 dark:bg-emerald-950 dark:text-emerald-100 dark:border-emerald-800",
  DEAN: "bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-900",
  INSTRUCTOR: "bg-sky-100 text-sky-800 border-sky-200 dark:bg-sky-950/60 dark:text-sky-300 dark:border-sky-900",
  STUDENT_ADMIN: "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-900",
  STUDENT: "bg-muted text-muted-foreground border-border",
};

const THIN_SCROLL =
  "[scrollbar-width:thin] [scrollbar-color:var(--border)_transparent] [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border [&::-webkit-scrollbar-track]:bg-transparent";

function isStudentRole(roleKey: string): boolean {
  return roleKey === "STUDENT" || roleKey === "STUDENT_ADMIN";
}

// ===== بحث مؤجّل (debounce) =====
function useDebounced<T>(value: T, ms = 350): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return debounced;
}

// ===== شارة الدور =====
function RoleBadge({ roleKey }: { roleKey: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border whitespace-nowrap",
        ROLE_BADGE[roleKey] ?? "bg-muted text-muted-foreground border-border"
      )}
    >
      {ROLE_LABELS[roleKey] ?? roleKey}
    </span>
  );
}

// ===== شارة الحالة =====
function ActiveBadge({ active }: { active: boolean }) {
  return active ? (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400">
      <span aria-hidden="true" className="w-2 h-2 rounded-full bg-emerald-500" />
      نشط
    </span>
  ) : (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-red-600 dark:text-red-400">
      <span aria-hidden="true" className="w-2 h-2 rounded-full bg-red-500" />
      معطّل
    </span>
  );
}

function initials(name: string): string {
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p.charAt(0))
    .join("");
}

// ===== قائمة الإجراءات (تُستخدم في الجدول والبطاقات) =====
function UserActions({
  user,
  onEdit,
  onReset,
  onRegen,
  onToggleActive,
  onDelete,
}: {
  user: AdminUser;
  onEdit: (u: AdminUser) => void;
  onReset: (u: AdminUser) => void;
  onRegen: (u: AdminUser) => void;
  onToggleActive: (u: AdminUser) => void;
  onDelete: (u: AdminUser) => void;
}) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="h-11 w-11 rounded-full" aria-label={`إجراءات ${user.fullName}`}>
          <MoreVertical className="w-5 h-5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuItem onClick={() => onEdit(user)} className="gap-2 py-2.5">
          <Pencil className="w-4 h-4" />
          تعديل البيانات
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => onReset(user)} className="gap-2 py-2.5">
          <KeyRound className="w-4 h-4" />
          تعيين كلمة مرور جديدة
        </DropdownMenuItem>
        {isStudentRole(user.roleKey) && (
          <DropdownMenuItem onClick={() => onRegen(user)} className="gap-2 py-2.5">
            <QrCode className="w-4 h-4" />
            توليد باركود جديد
          </DropdownMenuItem>
        )}
        <DropdownMenuItem onClick={() => onToggleActive(user)} className="gap-2 py-2.5">
          {user.isActive ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
          {user.isActive ? "تعطيل الحساب" : "تفعيل الحساب"}
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => onDelete(user)} className="gap-2 py-2.5 text-destructive focus:text-destructive">
          <Trash2 className="w-4 h-4" />
          حذف نهائي
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

// ===== نموذج إنشاء/تعديل مستخدم =====
function UserFormDialog({
  open,
  user,
  onClose,
  onSaved,
}: {
  open: boolean;
  user?: AdminUser | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const isEdit = !!user;
  const [form, setForm] = useState<UserFormState>(() =>
    user
      ? {
          fullName: user.fullName,
          email: user.email,
          password: "",
          roleKey: user.roleKey,
          universityId: user.universityId ?? "",
          phone: user.phone ?? "",
          stageId: "",
          branchId: "",
          academicYear: user.academicYear ?? "2025-2026",
          isActive: user.isActive,
        }
      : emptyForm
  );
  const [showPw, setShowPw] = useState(false);
  const isStudent = isStudentRole(form.roleKey);

  const stagesQuery = useQuery({
    queryKey: ["stages"],
    queryFn: () => api<{ items: StageItem[] }>("/api/stages"),
    enabled: open && isStudent,
  });

  // مطابقة المرحلة/الفرع الحاليين بالاسم عند التحرير (القائمة تعيد stageName وليس stageId)
  // — قيم مشتقة بدون تعديل الحالة، وتُستخدم ما لم يختر المستخدم قيمة يدوياً
  const matchedStageId = useMemo(
    () => (user?.stageName ? stagesQuery.data?.items.find((s) => s.nameAr === user.stageName)?.id : undefined),
    [user, stagesQuery.data]
  );
  const stageValue = form.stageId || matchedStageId || "";

  const branchesQuery = useQuery({
    queryKey: ["branches", stageValue],
    queryFn: () => api<{ items: BranchItem[] }>(`/api/branches?stageId=${stageValue}`),
    enabled: open && isStudent && !!stageValue,
  });
  const matchedBranchId = useMemo(
    () => (user?.branchName ? branchesQuery.data?.items.find((b) => b.nameAr === user.branchName)?.id : undefined),
    [user, branchesQuery.data]
  );
  const branchValue = form.branchId || (form.stageId ? "" : matchedBranchId) || "";

  const saveMutation = useMutation({
    mutationFn: async () => {
      if (isEdit && user) {
        const body: Record<string, unknown> = {
          fullName: form.fullName.trim(),
          phone: form.phone.trim() || null,
          roleKey: form.roleKey,
          isActive: form.isActive,
        };
        if (isStudent) {
          body.stageId = stageValue;
          body.branchId = branchValue;
          body.academicYear = form.academicYear.trim() || "2025-2026";
        }
        return api<{ ok: boolean }>(`/api/admin/users/${user.id}`, { method: "PATCH", body: JSON.stringify(body) });
      }
      const body: Record<string, unknown> = {
        fullName: form.fullName.trim(),
        email: form.email.trim(),
        password: form.password,
        roleKey: form.roleKey,
        universityId: form.universityId.trim() || null,
        phone: form.phone.trim() || null,
      };
      if (isStudent) {
        body.stageId = form.stageId;
        body.branchId = form.branchId;
        body.academicYear = form.academicYear.trim() || "2025-2026";
      }
      return api<{ user: { id: string } }>("/api/admin/users", { method: "POST", body: JSON.stringify(body) });
    },
    onSuccess: () => {
      toast.success(isEdit ? "تم تحديث بيانات المستخدم ✅" : "تم إنشاء المستخدم — سيُطلب منه تغيير كلمة المرور عند أول دخول");
      onSaved();
      onClose();
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : "فشل حفظ البيانات"),
  });

  const submit = () => {
    if (form.fullName.trim().length < 3) return toast.error("الاسم الكامل مطلوب (3 أحرف على الأقل)");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) return toast.error("البريد الإلكتروني غير صالح");
    if (!isEdit && form.password.length < 8) return toast.error("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
    if (isStudent && (!stageValue || !branchValue)) return toast.error("المرحلة والفرع مطلوبان لحساب الطالب");
    saveMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEdit ? `تعديل: ${user?.fullName}` : "إنشاء مستخدم جديد"}</DialogTitle>
          <DialogDescription>
            {isEdit ? "عدّل البيانات ثم احفظ التغييرات" : "أدخل بيانات الحساب الجديد — سيُطلب منه تغيير كلمة المرور عند أول دخول"}
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="uf-name">الاسم الكامل</Label>
            <Input id="uf-name" value={form.fullName} onChange={(e) => setForm((f) => ({ ...f, fullName: e.target.value }))} placeholder="مثال: أحمد محمد علي" />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="uf-email">البريد الإلكتروني</Label>
            <Input id="uf-email" dir="ltr" className="text-start" value={form.email} disabled={isEdit} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} placeholder="name@college.edu" />
            {isEdit && <p className="text-[11px] text-muted-foreground">البريد لا يمكن تعديله</p>}
          </div>

          {!isEdit && (
            <div className="space-y-1.5">
              <Label htmlFor="uf-pw">كلمة المرور</Label>
              <div className="relative">
                <Input
                  id="uf-pw"
                  dir="ltr"
                  className="text-start pe-10"
                  type={showPw ? "text" : "password"}
                  value={form.password}
                  onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
                  placeholder="8 أحرف على الأقل"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute end-0.5 top-1/2 -translate-y-1/2 h-9 w-9 text-muted-foreground"
                  onClick={() => setShowPw((v) => !v)}
                  aria-label={showPw ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}
                >
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <Label>الدور</Label>
            <Select value={form.roleKey} onValueChange={(v) => setForm((f) => ({ ...f, roleKey: v }))} disabled={isEdit && user?.roleKey === "OWNER"}>
              <SelectTrigger className="w-full h-10" aria-label="الدور">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ROLE_KEYS.map((r) => (
                  <SelectItem key={r} value={r}>
                    {ROLE_LABELS[r]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {isEdit && user?.roleKey === "OWNER" && <p className="text-[11px] text-muted-foreground">دور المالك ثابت</p>}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="uf-uid">الرقم الجامعي</Label>
            <Input
              id="uf-uid"
              dir="ltr"
              className="text-start font-mono"
              value={form.universityId}
              disabled={isEdit}
              onChange={(e) => setForm((f) => ({ ...f, universityId: e.target.value }))}
              placeholder="202512001"
            />
            {isEdit && <p className="text-[11px] text-muted-foreground">يُعيَّن عند الإنشاء</p>}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="uf-phone">الهاتف (اختياري)</Label>
            <Input id="uf-phone" dir="ltr" className="text-start" value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} placeholder="07xxxxxxxxx" />
          </div>

          {isStudent && (
            <div className="sm:col-span-2 rounded-xl bg-muted/40 border border-border/60 p-3 grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label>المرحلة</Label>
                <Select value={stageValue || undefined} onValueChange={(v) => setForm((f) => ({ ...f, stageId: v, branchId: "" }))}>
                  <SelectTrigger className="w-full h-10" aria-label="المرحلة" disabled={stagesQuery.isLoading}>
                    <SelectValue placeholder={stagesQuery.isLoading ? "جارٍ التحميل..." : "اختر المرحلة"} />
                  </SelectTrigger>
                  <SelectContent>
                    {(stagesQuery.data?.items ?? []).map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.nameAr}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>الفرع</Label>
                <Select value={branchValue || undefined} onValueChange={(v) => setForm((f) => ({ ...f, branchId: v }))} disabled={!stageValue}>
                  <SelectTrigger className="w-full h-10" aria-label="الفرع">
                    <SelectValue placeholder={stageValue ? "اختر الفرع" : "اختر المرحلة أولاً"} />
                  </SelectTrigger>
                  <SelectContent>
                    {(branchesQuery.data?.items ?? []).map((b) => (
                      <SelectItem key={b.id} value={b.id}>
                        {b.nameAr}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="uf-year">السنة الدراسية</Label>
                <Input id="uf-year" dir="ltr" className="text-start" value={form.academicYear} onChange={(e) => setForm((f) => ({ ...f, academicYear: e.target.value }))} placeholder="2025-2026" />
              </div>
            </div>
          )}

          {isEdit && (
            <div className="sm:col-span-2 flex items-center justify-between rounded-xl border border-border/60 px-4 py-3">
              <div>
                <p className="text-sm font-medium">حالة الحساب</p>
                <p className="text-xs text-muted-foreground">الحساب المعطّل لا يستطيع تسجيل الدخول</p>
              </div>
              <Switch checked={form.isActive} onCheckedChange={(v) => setForm((f) => ({ ...f, isActive: v }))} aria-label="حالة الحساب" />
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose} disabled={saveMutation.isPending}>
            إلغاء
          </Button>
          <Button onClick={submit} disabled={saveMutation.isPending} className="gap-2">
            {saveMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            {isEdit ? "حفظ التعديلات" : "إنشاء المستخدم"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ===== الواجهة الرئيسية =====
export function UsersView() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const debouncedSearch = useDebounced(search, 350);

  const [createOpen, setCreateOpen] = useState(false);
  const [editing, setEditing] = useState<AdminUser | null>(null);
  const [resetting, setResetting] = useState<AdminUser | null>(null);
  const [deleting, setDeleting] = useState<AdminUser | null>(null);
  const [tempPassword, setTempPassword] = useState<string | null>(null);

  // ===== استيراد Excel =====
  const [importOpen, setImportOpen] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importPreview, setImportPreview] = useState<ImportRow[] | null>(null);
  const [importBusy, setImportBusy] = useState(false);
  const [importConfirm, setImportConfirm] = useState(false);

  const roleParam = roleFilter === "all" ? "" : roleFilter;
  const listQuery = useQuery({
    queryKey: ["admin-users", debouncedSearch, roleParam],
    queryFn: () => api<{ items: AdminUser[] }>(`/api/admin/users?q=${encodeURIComponent(debouncedSearch)}&role=${roleParam}`),
  });
  const items = useMemo(() => listQuery.data?.items ?? [], [listQuery.data]);

  const invalidate = () => qc.invalidateQueries({ queryKey: ["admin-users"] });

  const stats = useMemo(
    () => ({
      total: items.length,
      students: items.filter((u) => isStudentRole(u.roleKey)).length,
      instructors: items.filter((u) => u.roleKey === "INSTRUCTOR").length,
      disabled: items.filter((u) => !u.isActive).length,
    }),
    [items]
  );

  // ===== معالجات استيراد Excel =====
  const doImportPreview = async () => {
    if (!importFile) return;
    setImportBusy(true);
    try {
      const fd = new FormData();
      fd.append("file", importFile);
      fd.append("mode", "preview");
      const res = await api<{ preview: ImportRow[]; validCount: number }>("/api/admin/users/import", { method: "POST", body: fd });
      setImportPreview(res.preview);
      if (res.preview.length === 0) toast.error("الملف لا يحتوي على صفوف");
      else toast.info(`تم تحليل ${res.preview.length} صفاً — ${res.validCount} صالحاً`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "تعذر تحليل الملف");
    } finally {
      setImportBusy(false);
    }
  };

  const doImportApply = async () => {
    if (!importFile) return;
    setImportBusy(true);
    try {
      const fd = new FormData();
      fd.append("file", importFile);
      fd.append("mode", "apply");
      const res = await api<{ created: number; errors: { email: string; error: string }[] }>("/api/admin/users/import", { method: "POST", body: fd });
      toast.success(`تم إنشاء ${res.created} مستخدماً بنجاح${res.errors.length ? ` وفشل ${res.errors.length}` : ""}`);
      setImportConfirm(false);
      setImportOpen(false);
      setImportFile(null);
      setImportPreview(null);
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "فشل الاستيراد");
    } finally {
      setImportBusy(false);
    }
  };

  // تعديلات سريعة (باركود / تعطيل / كلمة مرور)
  const patchMutation = useMutation({
    mutationFn: ({ id, body }: { id: string; body: Record<string, unknown> }) =>
      api<{ ok: boolean; tempPassword?: string | null }>(`/api/admin/users/${id}`, { method: "PATCH", body: JSON.stringify(body) }),
    onSuccess: (res, vars) => {
      invalidate();
      if (vars.body.resetPassword) {
        setTempPassword(res.tempPassword ?? null);
      } else if (vars.body.regenerateQr) {
        toast.success("تم توليد باركود جديد للطالب — الباركود القديم لم يعد صالحاً");
      } else {
        toast.success("تم تحديث حالة الحساب ✅");
      }
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : "فشلت العملية"),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api<{ ok: boolean; deleted?: boolean; deactivated?: boolean }>(`/api/admin/users/${id}`, { method: "DELETE" }),
    onSuccess: (res) => {
      invalidate();
      if (res.deactivated) {
        toast.success("لا يمكن حذف مستخدم لديه سجلات حضور — تم تعطيل حسابه بدلاً من الحذف");
      } else {
        toast.success("تم حذف المستخدم نهائياً");
      }
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : "فشل الحذف"),
  });

  const copyTempPassword = async () => {
    if (!tempPassword) return;
    try {
      await navigator.clipboard.writeText(tempPassword);
      toast.success("تم نسخ كلمة المرور");
    } catch {
      toast.error("تعذر النسخ التلقائي — انسخها يدوياً");
    }
  };

  if (listQuery.isLoading) return <LoadingPage cards={4} />;
  if (listQuery.isError)
    return <ErrorState message={listQuery.error instanceof Error ? listQuery.error.message : "تعذر تحميل المستخدمين"} onRetry={() => listQuery.refetch()} />;

  return (
    <div>
      <PageHeader
        title="المستخدمون"
        description="إدارة حسابات الكلية — إنشاء وتعديل وتعطيل"
        icon={<UsersIcon className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="icon" className="h-11 w-11" onClick={() => listQuery.refetch()} aria-label="تحديث القائمة">
              <RefreshCw className={cn("w-4 h-4", listQuery.isFetching && "animate-spin")} />
            </Button>
            <Button onClick={() => setCreateOpen(true)} className="gap-2 h-11">
              <UserPlus className="w-4 h-4" />
              مستخدم جديد
            </Button>
            <Button variant="outline" onClick={() => setImportOpen(true)} className="gap-2 h-11">
              <Upload className="w-4 h-4" />
              استيراد Excel
            </Button>
          </>
        }
      />

      {/* إحصاءات */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard label="إجمالي المستخدمين" value={stats.total} icon={<UsersIcon className="w-5 h-5" />} tone="primary" />
        <StatCard label="الطلاب (عادي + مسؤول)" value={stats.students} icon={<GraduationCap className="w-5 h-5" />} tone="accent" />
        <StatCard label="التدريسيون" value={stats.instructors} icon={<BookOpen className="w-5 h-5" />} tone="primary" />
        <StatCard label="حسابات معطّلة" value={stats.disabled} icon={<UserX className="w-5 h-5" />} tone="danger" />
      </div>

      {/* بحث وفلترة */}
      <Card className="rounded-2xl border-border/60 shadow-sm mb-4">
        <CardContent className="p-3 sm:p-4 flex flex-col sm:flex-row gap-2.5">
          <div className="relative flex-1">
            <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" aria-hidden="true" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث بالاسم أو البريد أو الرقم الجامعي..."
              className="ps-9 pe-9 h-11"
              aria-label="بحث في المستخدمين"
            />
            {search && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute end-0.5 top-1/2 -translate-y-1/2 h-10 w-10 text-muted-foreground"
                onClick={() => setSearch("")}
                aria-label="مسح البحث"
              >
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="w-full sm:w-48 h-11" aria-label="فلترة حسب الدور">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الأدوار</SelectItem>
              {ROLE_KEYS.map((r) => (
                <SelectItem key={r} value={r}>
                  {ROLE_LABELS[r]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {items.length === 0 ? (
        <EmptyState
          message="لا يوجد مستخدمون مطابقون"
          sub={search || roleFilter !== "all" ? "جرّب تغيير البحث أو الفلتر" : "ابدأ بإنشاء أول مستخدم"}
          action={
            (search || roleFilter !== "all") && (
              <Button
                variant="outline"
                onClick={() => {
                  setSearch("");
                  setRoleFilter("all");
                }}
              >
                إظهار الكل
              </Button>
            )
          }
        />
      ) : (
        <>
          {/* جدول — حاسوب */}
          <Card className="hidden md:block rounded-2xl border-border/60 shadow-sm overflow-hidden">
            <div className={cn("overflow-y-auto max-h-[65vh]", THIN_SCROLL)}>
              <Table className="min-w-[860px]">
                <TableHeader>
                  <TableRow className="bg-muted/50 hover:bg-muted/50">
                    <TableHead className="ps-4">المستخدم</TableHead>
                    <TableHead>الرقم الجامعي</TableHead>
                    <TableHead>الدور</TableHead>
                    <TableHead>المرحلة / الفرع</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead className="pe-2 w-16 text-center">
                      <span className="sr-only">إجراءات</span>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell className="ps-4">
                        <div className="flex items-center gap-2.5">
                          <Avatar className="w-9 h-9 border border-border/60">
                            {u.photoUrl && <AvatarImage src={u.photoUrl} alt={u.fullName} />}
                            <AvatarFallback className="text-xs bg-primary/10 text-primary font-semibold">{initials(u.fullName)}</AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <p className="font-semibold truncate max-w-[180px]">{u.fullName}</p>
                            <p className="text-xs text-muted-foreground truncate max-w-[180px]" dir="ltr">
                              {u.email}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {u.universityId ? (
                          <code className="text-xs font-mono" dir="ltr">
                            {u.universityId}
                          </code>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <RoleBadge roleKey={u.roleKey} />
                      </TableCell>
                      <TableCell>
                        {isStudentRole(u.roleKey) ? (
                          <div>
                            <p className="text-xs">
                              {u.stageName ?? "—"}
                              {u.branchName && <span className="text-muted-foreground"> — {u.branchName}</span>}
                            </p>
                            {u.academicYear && <p className="text-[11px] text-muted-foreground">{u.academicYear}</p>}
                          </div>
                        ) : u.subjects.length > 0 ? (
                          <span className="text-xs text-muted-foreground">{u.subjects.length} مواد مسندة</span>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <ActiveBadge active={u.isActive} />
                      </TableCell>
                      <TableCell className="pe-2">
                        <UserActions
                          user={u}
                          onEdit={setEditing}
                          onReset={setResetting}
                          onRegen={(usr) => patchMutation.mutate({ id: usr.id, body: { regenerateQr: true } })}
                          onToggleActive={(usr) => patchMutation.mutate({ id: usr.id, body: { isActive: !usr.isActive } })}
                          onDelete={setDeleting}
                        />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>

          {/* بطاقات — هاتف */}
          <div className={cn("md:hidden space-y-3 max-h-[70vh] overflow-y-auto", THIN_SCROLL)}>
            {items.map((u) => (
              <Card key={u.id} className="rounded-2xl border-border/60 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Avatar className="w-11 h-11 border border-border/60 shrink-0">
                      {u.photoUrl && <AvatarImage src={u.photoUrl} alt={u.fullName} />}
                      <AvatarFallback className="text-sm bg-primary/10 text-primary font-semibold">{initials(u.fullName)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <p className="font-semibold truncate">{u.fullName}</p>
                        <RoleBadge roleKey={u.roleKey} />
                      </div>
                      <p className="text-xs text-muted-foreground truncate mt-0.5" dir="ltr">
                        {u.email}
                      </p>
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1.5 text-xs text-muted-foreground">
                        {u.universityId && (
                          <span>
                            الرقم الجامعي:{" "}
                            <code className="font-mono" dir="ltr">
                              {u.universityId}
                            </code>
                          </span>
                        )}
                        {isStudentRole(u.roleKey) && (
                          <span>
                            {u.stageName ?? "—"}
                            {u.branchName ? ` — ${u.branchName}` : ""}
                          </span>
                        )}
                        {!isStudentRole(u.roleKey) && u.subjects.length > 0 && <span>{u.subjects.length} مواد مسندة</span>}
                      </div>
                    </div>
                    <div className="shrink-0">
                      <UserActions
                        user={u}
                        onEdit={setEditing}
                        onReset={setResetting}
                        onRegen={(usr) => patchMutation.mutate({ id: usr.id, body: { regenerateQr: true } })}
                        onToggleActive={(usr) => patchMutation.mutate({ id: usr.id, body: { isActive: !usr.isActive } })}
                        onDelete={setDeleting}
                      />
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-2 pt-2.5 border-t border-border/60">
                    <ActiveBadge active={u.isActive} />
                    <span className="text-[11px] text-muted-foreground">انضم {fmtDate(u.createdAt)}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}

      {/* إنشاء / تعديل */}
      {createOpen && <UserFormDialog key="create" open onClose={() => setCreateOpen(false)} onSaved={invalidate} />}
      {editing && <UserFormDialog key={editing.id} open user={editing} onClose={() => setEditing(null)} onSaved={invalidate} />}

      {/* تأكيد إعادة تعيين كلمة المرور */}
      <AlertDialog open={!!resetting} onOpenChange={(o) => !o && setResetting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>تعيين كلمة مرور جديدة؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم إبطال كلمة مرور «{resetting?.fullName}» الحالية وتوليد كلمة مرور مؤقتة جديدة. سيُطلب من المستخدم تغييرها عند أول دخول.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (!resetting) return;
                patchMutation.mutate({ id: resetting.id, body: { resetPassword: true } });
                setResetting(null);
              }}
            >
              متابعة
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* عرض كلمة المرور المؤقتة */}
      <Dialog open={!!tempPassword} onOpenChange={(o) => !o && setTempPassword(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-primary" />
              كلمة المرور المؤقتة
            </DialogTitle>
            <DialogDescription>انسخها وسلّمها للمستخدم بطريقة آمنة.</DialogDescription>
          </DialogHeader>
          <div className="rounded-xl border-2 border-dashed border-primary/40 bg-primary/5 p-4 text-center">
            <code dir="ltr" className="text-xl font-mono font-bold tracking-wider select-all">
              {tempPassword}
            </code>
          </div>
          <p className="text-xs text-amber-700 dark:text-amber-400 flex items-start gap-1.5" role="alert">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            سيُطلب من المستخدم تغييرها عند أول دخول.
          </p>
          <DialogFooter className="flex-row gap-2 sm:justify-start">
            <Button variant="outline" onClick={copyTempPassword} className="gap-2 flex-1">
              <Copy className="w-4 h-4" />
              نسخ
            </Button>
            <Button onClick={() => setTempPassword(null)} className="flex-1">
              تم
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* تأكيد الحذف */}
      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-destructive">حذف «{deleting?.fullName}»؟</AlertDialogTitle>
            <AlertDialogDescription>
              إذا كان للمستخدم سجلات حضور فسيتم تعطيل حسابه بدلاً من حذفه للحفاظ على السجلات، وإلا فسيُحذف نهائياً مع ملفه الطلابي.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => {
                if (!deleting) return;
                deleteMutation.mutate(deleting.id);
                setDeleting(null);
              }}
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ===== استيراد Excel ===== */}
      <Dialog open={importOpen} onOpenChange={(o) => { setImportOpen(o); if (!o) { setImportFile(null); setImportPreview(null); } }}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-primary" />
              استيراد مستخدمين من Excel
            </DialogTitle>
            <DialogDescription>
              الأعمدة المطلوبة: الاسم الكامل، البريد الإلكتروني، الرقم الجامعي، الدور، المرحلة، الفرع، السنة الدراسية.
              كلمة المرور المبدئية للطالب = <span dir="ltr" className="font-mono">Cg&laquo;الرقم الجامعي&raquo;@2025</span> ويُطلب تغييرها عند أول دخول.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <Input
                type="file"
                accept=".xlsx"
                onChange={(e) => { setImportFile(e.target.files?.[0] ?? null); setImportPreview(null); }}
                className="flex-1 min-w-48"
                aria-label="اختيار ملف Excel"
              />
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5"
                onClick={downloadTemplate}
              >
                <Download className="w-4 h-4" />
                تنزيل قالب فارغ
              </Button>
            </div>

            {importFile && !importPreview && (
              <Button className="w-full gap-2" onClick={doImportPreview} disabled={importBusy}>
                {importBusy && <Loader2 className="w-4 h-4 animate-spin" />}
                <Upload className="w-4 h-4" />
                معاينة الملف
              </Button>
            )}

            {importPreview && (
              <>
                <div className="rounded-xl border p-3 text-sm">
                  <p>
                    صفوف صالحة: <span className="font-bold text-primary">{importPreview.filter((r) => !r.error).length}</span>
                    {" — "}صفوف بها أخطاء: <span className="font-bold text-destructive">{importPreview.filter((r) => r.error).length}</span>
                  </p>
                </div>
                <div className="max-h-64 overflow-y-auto rounded-xl border">
                  <Table>
                    <TableHeader className="sticky top-0 bg-card">
                      <TableRow>
                        <TableHead>الاسم</TableHead>
                        <TableHead>البريد</TableHead>
                        <TableHead>الدور</TableHead>
                        <TableHead>الحالة</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {importPreview.map((r, i) => (
                        <TableRow key={i} className={r.error ? "bg-red-50 dark:bg-red-950/30" : "bg-emerald-50/50 dark:bg-emerald-950/20"}>
                          <TableCell className="font-medium truncate max-w-40">{r.fullName || "—"}</TableCell>
                          <TableCell dir="ltr" className="text-xs truncate max-w-44">{r.email || "—"}</TableCell>
                          <TableCell className="text-xs">{ROLE_LABELS[r.roleKey] ?? r.roleKey}</TableCell>
                          <TableCell className="text-xs">
                            {r.error ? <span className="text-destructive font-semibold">{r.error}</span> : <span className="text-primary font-semibold">جاهز للإضافة</span>}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                {importPreview.some((r) => !r.error) && (
                  <Button className="w-full gap-2" onClick={() => setImportConfirm(true)}>
                    <UserPlus className="w-4 h-4" />
                    استيراد الصفوف الصالحة ({importPreview.filter((r) => !r.error).length})
                  </Button>
                )}
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* تأكيد الاستيراد */}
      <AlertDialog open={importConfirm} onOpenChange={setImportConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد استيراد المستخدمين؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم إنشاء {importPreview?.filter((r) => !r.error).length ?? 0} حساباً جديداً بكلمات مرور مؤقتة. الحسابات الموجودة مسبقاً ستُتجاهَل.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={doImportApply}>تأكيد الاستيراد</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ===== دوال الاستيراد =====

// تنزيل قالب Excel فارغ (يُبنى محلياً بجدول CSV يدعم العربية في Excel)
function downloadTemplate() {
  const rows = [
    ["الاسم الكامل", "البريد الإلكتروني", "الرقم الجامعي", "الدور", "المرحلة", "الفرع", "السنة الدراسية"],
    ["مثال: سارة علي", "sara@college.edu", "202512021", "STUDENT", "المرحلة الأولى", "علوم الحاسوب", "2025-2026"],
  ];
  const csv = "\uFEFF" + rows.map((r) => r.join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "users-template.csv";
  a.click();
  URL.revokeObjectURL(a.href);
}
