"use client";
// مصفوفة الصلاحيات — عرض/تعديل نطاق كل صلاحية لكل دور مع تتبع التغييرات ومعاينة الفروقات
import { Fragment, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/client/api";
import { useApp } from "@/lib/client/store";
import { ROLE_KEYS, ROLE_LABELS } from "@/lib/constants";
import { ErrorState, LoadingPage, PageHeader } from "@/components/app/shared/ui-bits";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { toast } from "sonner";
import { AlertTriangle, Loader2, Lock, RotateCcw, Save, ShieldAlert, ShieldCheck, X } from "lucide-react";
import { cn } from "@/lib/utils";

// ===== الأنواع =====
type PermData = {
  roles: { id: string; key: string; nameAr: string }[];
  permissions: { key: string; group: string; nameAr: string }[];
  scopes: string[];
  scopeLabels: Record<string, string>;
  matrix: Record<string, Record<string, string>>;
  defaults: Record<string, Record<string, string>>;
  editableByRoles: string[];
};

type ChangeItem = { roleId: string; permissionKey: string; scope: string };

const THIN_SCROLL =
  "[scrollbar-width:thin] [scrollbar-color:var(--border)_transparent] [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border [&::-webkit-scrollbar-track]:bg-transparent";

// ===== خلية نطاق =====
function ScopeCell({
  value,
  changed,
  disabled,
  tooltip,
  scopes,
  scopeLabels,
  onChange,
}: {
  value: string;
  changed: boolean;
  disabled: boolean;
  tooltip?: string;
  scopes: string[];
  scopeLabels: Record<string, string>;
  onChange: (scope: string) => void;
}) {
  const select = (
    <Select value={value} onValueChange={onChange} disabled={disabled}>
      <SelectTrigger
        size="sm"
        aria-label="نطاق الصلاحية"
        className={cn(
          "h-8 text-xs w-full min-w-[112px]",
          changed && "border-amber-500 ring-2 ring-amber-300/60 dark:ring-amber-500/40"
        )}
      >
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {scopes.map((s) => (
          <SelectItem key={s} value={s} className="text-xs">
            {scopeLabels[s] ?? s}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );

  return (
    <td className={cn("px-2 py-1.5 text-center", changed && "bg-amber-50/70 dark:bg-amber-950/25")}>
      <div className="flex items-center justify-center gap-1.5">
        {changed && <span aria-label="قيد الحفظ" title="قيد الحفظ" className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />}
        {tooltip ? (
          <Tooltip>
            <TooltipTrigger asChild>
              <span className="inline-flex w-full cursor-not-allowed" tabIndex={0}>
                {select}
              </span>
            </TooltipTrigger>
            <TooltipContent side="top">{tooltip}</TooltipContent>
          </Tooltip>
        ) : (
          select
        )}
      </div>
    </td>
  );
}

// ===== الواجهة =====
export function PermissionsView() {
  const qc = useQueryClient();
  const { user } = useApp();
  const [edits, setEdits] = useState<Record<string, string>>({});
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const permsQuery = useQuery({
    queryKey: ["admin-permissions"],
    queryFn: () => api<PermData>("/api/admin/permissions"),
  });
  const data = permsQuery.data;

  // هل يستطيع المستخدم الحالي تعديل المصفوفة؟
  const canEdit = !!user && !!data && data.editableByRoles.includes(user.roleKey);

  // ترتيب الأدوار حسب الثوابت (المالك أولاً)
  const roles = useMemo(() => {
    if (!data) return [];
    return [...data.roles].sort((a, b) => {
      const ia = ROLE_KEYS.indexOf(a.key as (typeof ROLE_KEYS)[number]);
      const ib = ROLE_KEYS.indexOf(b.key as (typeof ROLE_KEYS)[number]);
      return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib);
    });
  }, [data]);

  // تجميع الصلاحيات بالأقسام مع الحفاظ على الترتيب
  const groups = useMemo(() => {
    if (!data) return [];
    const out: { group: string; perms: { key: string; nameAr: string }[] }[] = [];
    for (const p of data.permissions) {
      let g = out.find((x) => x.group === p.group);
      if (!g) {
        g = { group: p.group, perms: [] };
        out.push(g);
      }
      g.perms.push({ key: p.key, nameAr: p.nameAr });
    }
    return out;
  }, [data]);

  // التغييرات المعلّقة
  const changes = useMemo<ChangeItem[]>(() => {
    if (!data) return [];
    return Object.entries(edits).map(([key, scope]) => {
      const [roleId, permissionKey] = key.split("::");
      return { roleId, permissionKey, scope };
    });
  }, [edits, data]);

  // فروقات المعاينة قبل الحفظ
  const diffs = useMemo(() => {
    if (!data) return [];
    return changes.map((c) => {
      const role = data.roles.find((r) => r.id === c.roleId);
      const perm = data.permissions.find((p) => p.key === c.permissionKey);
      const oldScope = data.matrix[role?.key ?? ""]?.[c.permissionKey] ?? "NONE";
      return {
        roleName: role?.nameAr ?? c.roleId,
        permName: perm?.nameAr ?? c.permissionKey,
        oldLabel: data.scopeLabels[oldScope] ?? oldScope,
        newLabel: data.scopeLabels[c.scope] ?? c.scope,
      };
    });
  }, [changes, data]);

  const saveMutation = useMutation({
    mutationFn: (body: ChangeItem[]) =>
      api<{ ok: boolean; applied: number }>("/api/admin/permissions", { method: "PUT", body: JSON.stringify(body) }),
    onSuccess: async (res) => {
      setEdits({});
      setConfirmOpen(false);
      setSaveError(null);
      toast.success(`تم حفظ ${res.applied} تغييراً — انعكست الصلاحيات فوراً على المستخدمين`);
      await qc.invalidateQueries({ queryKey: ["admin-permissions"] });
      await permsQuery.refetch();
    },
    onError: (err) => {
      const msg = err instanceof Error ? err.message : "فشل حفظ الصلاحيات";
      setSaveError(msg);
      setConfirmOpen(false);
      toast.error(msg);
    },
  });

  // تعديل خلية — يُحسب مقابل قيمة السيرفر (العودة للقيمة الأصلية تلغي التعديل)
  const setCell = (roleId: string, roleKey: string, permKey: string, scope: string) => {
    if (!data) return;
    const key = `${roleId}::${permKey}`;
    const serverVal = data.matrix[roleKey]?.[permKey] ?? "NONE";
    setEdits((prev) => {
      const next = { ...prev };
      if (scope === serverVal) delete next[key];
      else next[key] = scope;
      return next;
    });
  };

  // استعادة المصفوفة الافتراضية كتعديلات معلّقة
  const applyDefaults = () => {
    if (!data) return;
    const next: Record<string, string> = {};
    for (const role of data.roles) {
      for (const perm of data.permissions) {
        const def = data.defaults[role.key]?.[perm.key] ?? "NONE";
        const serverVal = data.matrix[role.key]?.[perm.key] ?? "NONE";
        if (def !== serverVal) next[`${role.id}::${perm.key}`] = def;
      }
    }
    setEdits(next);
    if (Object.keys(next).length === 0) toast.info("المصفوفة الحالية مطابقة للافتراضية بالفعل");
    else toast.success(`تمت استعادة الافتراضي — ${Object.keys(next).length} تغييراً بانتظار المراجعة والحفظ`);
  };

  const discard = () => {
    setEdits({});
    setSaveError(null);
    toast.info("تم تجاهل التعديلات المعلّقة");
  };

  if (permsQuery.isLoading) return <LoadingPage cards={2} />;
  if (permsQuery.isError)
    return (
      <ErrorState
        message={permsQuery.error instanceof Error ? permsQuery.error.message : "تعذر تحميل الصلاحيات"}
        onRetry={() => permsQuery.refetch()}
      />
    );
  if (!data) return null;

  const editableRolesText = data.editableByRoles.map((r) => ROLE_LABELS[r] ?? r).join("، ");

  return (
    <div>
      <PageHeader
        title="مصفوفة الصلاحيات"
        description={
          changes.length > 0 ? `${changes.length} تغييراً معلّقاً بانتظار الحفظ` : "نطاق كل صلاحية لكل دور — حفظ فوري الانعكاس"
        }
        icon={<ShieldCheck className="w-5 h-5" />}
      />

      {/* ملاحظة أمان */}
      <div className="mb-4 flex items-start gap-2.5 rounded-xl border border-amber-200 bg-amber-50 dark:bg-amber-950/30 dark:border-amber-900 px-4 py-3 text-sm text-amber-800 dark:text-amber-300" role="note">
        <ShieldAlert className="w-5 h-5 shrink-0 mt-0.5" />
        <p>
          <span className="font-bold">ملاحظة أمان:</span> التغييرات تنعكس فوراً على المستخدمين لحظة الحفظ — راجع الفروقات قبل التأكيد.
        </p>
      </div>

      {/* خطأ السيرفر — بارز أعلى الجدول */}
      {saveError && (
        <div className="mb-4 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-destructive flex items-start justify-between gap-3" role="alert">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
            <p className="font-medium">{saveError}</p>
          </div>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive shrink-0" onClick={() => setSaveError(null)} aria-label="إغلاق رسالة الخطأ">
            <X className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* عدم توفر صلاحية التعديل */}
      {!canEdit && (
        <div className="mb-4 flex items-start gap-2.5 rounded-xl border border-border bg-muted/50 px-4 py-3 text-sm text-muted-foreground" role="note">
          <Lock className="w-5 h-5 shrink-0 mt-0.5" />
          <p>
            عرض فقط — تعديل المصفوفة متاح للأدوار: <span className="font-semibold text-foreground">{editableRolesText || "غير محدد"}</span>
          </p>
        </div>
      )}

      {/* أزرار الإجراءات */}
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <Button onClick={() => setConfirmOpen(true)} disabled={changes.length === 0 || !canEdit || saveMutation.isPending} className="gap-2 h-11">
          <Save className="w-4 h-4" />
          حفظ التغييرات ({changes.length})
        </Button>

        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="outline" disabled={!canEdit || saveMutation.isPending} className="gap-2 h-11">
              <RotateCcw className="w-4 h-4" />
              إعادة الافتراضي
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>استعادة المصفوفة الافتراضية؟</AlertDialogTitle>
              <AlertDialogDescription>
                سيتم استبدال كل قيم المصفوفة الحالية بالقيم الافتراضية للنظام، وستظهر الخلايا المختلفة كتغييرات معلّقة — لن يُطبَّق شيء
                حتى تضغط «حفظ التغييرات».
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>إلغاء</AlertDialogCancel>
              <AlertDialogAction onClick={applyDefaults}>استعادة الافتراضي</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        <Button variant="ghost" onClick={discard} disabled={changes.length === 0} className="gap-2 h-11">
          <X className="w-4 h-4" />
          تجاهل التعديلات
        </Button>
      </div>

      {/* دليل الخلية المعدّلة */}
      <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1.5">
        <span aria-hidden="true" className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
        خلية معدّلة «قيد الحفظ» — لم تُطبَّق بعد
      </p>

      {/* المصفوفة */}
      <Card className="rounded-2xl border-border/60 shadow-sm overflow-hidden p-0">
        <div className={cn("overflow-auto max-h-[70vh]", THIN_SCROLL)}>
          <table className="w-full border-collapse text-sm min-w-[980px]">
            <thead>
              <tr className="bg-muted/60">
                <th scope="col" className="sticky right-0 z-20 bg-muted text-start px-3 py-2.5 font-semibold min-w-[230px]">
                  الصلاحية
                </th>
                {roles.map((r) => (
                  <th scope="col" key={r.id} className="px-3 py-2.5 text-center font-semibold min-w-[136px] whitespace-nowrap">
                    {r.nameAr}
                    <span className="block text-[10px] font-normal text-muted-foreground font-mono" dir="ltr">
                      {r.key}
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {groups.map((g) => (
                <Fragment key={g.group}>
                  <tr className="bg-muted/70">
                    <td colSpan={roles.length + 1} className="px-3 py-1.5 font-bold text-xs text-foreground/80 bg-muted/70">
                      {g.group}
                    </td>
                  </tr>
                  {g.perms.map((p) => (
                    <tr key={p.key} className="hover:bg-muted/20">
                      <td className="sticky right-0 z-10 bg-card px-3 py-2 shadow-[-6px_0_8px_-8px_rgba(0,0,0,0.4)]">
                        <div className="font-medium text-sm">{p.nameAr}</div>
                        <div className="text-[10px] text-muted-foreground font-mono" dir="ltr">
                          {p.key}
                        </div>
                      </td>
                      {roles.map((r) => {
                        const key = `${r.id}::${p.key}`;
                        const serverVal = data.matrix[r.key]?.[p.key] ?? "NONE";
                        const value = edits[key] ?? serverVal;
                        const isOwnerManage = r.key === "OWNER" && p.key === "permissions.manage";
                        return (
                          <ScopeCell
                            key={key}
                            value={isOwnerManage ? "ALL" : value}
                            changed={!!edits[key] && !isOwnerManage}
                            disabled={!canEdit || isOwnerManage}
                            tooltip={isOwnerManage ? "لا يمكن سحبها من المالك" : undefined}
                            scopes={data.scopes}
                            scopeLabels={data.scopeLabels}
                            onChange={(scope) => setCell(r.id, r.key, p.key, scope)}
                          />
                        );
                      })}
                    </tr>
                  ))}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* معاينة الفروقات قبل الحفظ */}
      <Dialog open={confirmOpen} onOpenChange={(o) => !o && setConfirmOpen(false)}>
        <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-primary" />
              تأكيد حفظ التغييرات
            </DialogTitle>
            <DialogDescription>ستُطبَّق التغييرات التالية فوراً على جميع مستخدمي النظام:</DialogDescription>
          </DialogHeader>
          <ul className="space-y-2">
            {diffs.map((d, i) => (
              <li key={i} className="rounded-xl border border-border/60 bg-muted/30 px-3 py-2.5">
                <p className="font-semibold text-sm">
                  {d.roleName} — {d.permName}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  كان <span className="font-semibold text-foreground">{d.oldLabel}</span> ← صار{" "}
                  <span className="font-semibold text-primary">{d.newLabel}</span>
                </p>
              </li>
            ))}
          </ul>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setConfirmOpen(false)} disabled={saveMutation.isPending}>
              إلغاء
            </Button>
            <Button onClick={() => saveMutation.mutate(changes)} disabled={saveMutation.isPending} className="gap-2">
              {saveMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
              تأكيد الحفظ ({changes.length})
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
