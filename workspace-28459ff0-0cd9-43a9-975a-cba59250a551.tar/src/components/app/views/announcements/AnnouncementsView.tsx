"use client";
// التبليغات — قائمة مع فلاتر + عرض كامل وتعليم مقروء + إنشاء/تعديل/حذف حسب الصلاحيات
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { api } from "@/lib/client/api";
import { useApp } from "@/lib/client/store";
import { fmtDateTime } from "@/lib/date-fmt";
import { AUDIENCE_LABELS, PRIORITY_LABELS, type AudienceType, type Priority } from "@/lib/constants";
import {
  PageHeader,
  EmptyState,
  ErrorState,
  LoadingRows,
  PriorityBadge,
} from "@/components/app/shared/ui-bits";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import {
  Megaphone,
  Plus,
  MoreVertical,
  Pencil,
  Trash2,
  User,
  CalendarDays,
  Users2,
  Loader2,
} from "lucide-react";

// ===== الأنواع =====
type AnnouncementDTO = {
  id: string;
  title: string;
  body: string;
  priority: Priority;
  audienceType: AudienceType;
  stageName: string | null;
  branchName: string | null;
  subjectName: string | null;
  pinned: boolean;
  createdByName: string;
  createdById: string;
  publishedAt: string;
  expiresAt: string | null;
  isRead: boolean;
};

type StageDTO = { id: string; nameAr: string; level: number };
type BranchDTO = { id: string; nameAr: string; stageId: string; stageName: string };
type SubjectDTO = { id: string; code: string; nameAr: string; branchId: string; branchName: string; stageId: string; stageName: string };

type QuickFilter = "all" | "unread" | "pinned";

// ===== ثوابت محلية =====
const LIST_KEY = ["announcements"] as const;
const PRIORITY_OPTIONS: Priority[] = ["NORMAL", "IMPORTANT", "URGENT"];
const AUDIENCE_OPTIONS: AudienceType[] = ["ALL", "STAGE", "BRANCH", "SUBJECT"];

// ===== دوال مساعدة =====
function audienceText(a: {
  audienceType: AudienceType;
  stageName: string | null;
  branchName: string | null;
  subjectName: string | null;
}): string {
  switch (a.audienceType) {
    case "STAGE":
      return `مرحلة: ${a.stageName ?? "غير محددة"}`;
    case "BRANCH":
      return `فرع: ${a.branchName ?? "غير محدد"}`;
    case "SUBJECT":
      return `مادة: ${a.subjectName ?? "غير محددة"}`;
    default:
      return "الكل";
  }
}

// ============================================================
// الواجهة الرئيسية
// ============================================================
export function AnnouncementsView() {
  const qc = useQueryClient();
  const { user, hasScope } = useApp();
  const canCreate = hasScope("announcements.create");
  const canUpdate = hasScope("announcements.update");
  const canDelete = hasScope("announcements.delete");

  // ===== قائمة التبليغات =====
  const listQ = useQuery({
    queryKey: LIST_KEY,
    queryFn: () => api<{ items: AnnouncementDTO[] }>("/api/announcements"),
  });
  const items = useMemo(() => listQ.data?.items ?? [], [listQ.data]);

  // ===== الفلاتر =====
  const [quick, setQuick] = useState<QuickFilter>("all");
  const [priorityFilter, setPriorityFilter] = useState<"ALL" | Priority>("ALL");

  const unreadCount = useMemo(() => items.filter((a) => !a.isRead).length, [items]);
  const pinnedCount = useMemo(() => items.filter((a) => a.pinned).length, [items]);

  const filtered = useMemo(() => {
    let out = items;
    if (quick === "unread") out = out.filter((a) => !a.isRead);
    else if (quick === "pinned") out = out.filter((a) => a.pinned);
    if (priorityFilter !== "ALL") out = out.filter((a) => a.priority === priorityFilter);
    return out;
  }, [items, quick, priorityFilter]);

  // ===== توسيع النص داخل البطاقة =====
  const [expandedIds, setExpandedIds] = useState<Record<string, boolean>>({});
  const toggleExpand = (id: string) => setExpandedIds((m) => ({ ...m, [id]: !m[id] }));

  // ===== عرض التفاصيل + تعليم مقروء =====
  const [viewing, setViewing] = useState<AnnouncementDTO | null>(null);
  const openView = (a: AnnouncementDTO) => {
    setViewing(a);
    if (!a.isRead) {
      api(`/api/announcements/${a.id}/read`, { method: "POST" }).catch(() => {});
      qc.setQueryData<{ items: AnnouncementDTO[] }>(LIST_KEY, (old) =>
        old
          ? { items: old.items.map((x) => (x.id === a.id ? { ...x, isRead: true } : x)) }
          : old
      );
    }
  };

  // ===== نموذج الإنشاء/التعديل =====
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<AnnouncementDTO | null>(null);
  const openCreate = () => {
    setEditing(null);
    setEditorOpen(true);
  };
  const openEdit = (a: AnnouncementDTO) => {
    setViewing(null);
    setEditing(a);
    setEditorOpen(true);
  };

  // ===== الحذف =====
  const [deleting, setDeleting] = useState<AnnouncementDTO | null>(null);
  const deleteMut = useMutation({
    mutationFn: (id: string) => api<{ ok: boolean }>(`/api/announcements/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      toast.success("تم حذف التبليغ");
      setDeleting(null);
      qc.invalidateQueries({ queryKey: LIST_KEY });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  // أزرار التعديل/الحذف: لصاحب التبليغ (نطاق OWN) أو للمالك/العميد فقط
  const canManage = (a: AnnouncementDTO): boolean => {
    if (!user || !(canUpdate || canDelete)) return false;
    return a.createdById === user.id || user.roleKey === "OWNER" || user.roleKey === "DEAN";
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="التبليغات"
        description="إعلانات الكلية العامة والموجّهة للمراحل والفروع والمواد"
        icon={<Megaphone className="w-5 h-5" />}
        actions={
          canCreate ? (
            <Button onClick={openCreate}>
              <Plus className="w-4 h-4" />
              تبليغ جديد
            </Button>
          ) : undefined
        }
      />

      {/* ===== الفلاتر ===== */}
      <div className="flex flex-wrap items-center gap-2">
        <div
          className="inline-flex items-center gap-1 rounded-xl border border-border/60 bg-muted/50 p-1"
          role="group"
          aria-label="تصفية سريعة"
        >
          {(
            [
              { key: "all", label: `الكل (${items.length})` },
              { key: "unread", label: `غير المقروءة (${unreadCount})` },
              { key: "pinned", label: `المثبّتة (${pinnedCount})` },
            ] as { key: QuickFilter; label: string }[]
          ).map((q) => (
            <button
              key={q.key}
              type="button"
              onClick={() => setQuick(q.key)}
              aria-pressed={quick === q.key}
              className={cn(
                "h-11 sm:h-8 px-3 rounded-lg text-sm font-medium transition-colors",
                quick === q.key
                  ? "bg-background text-foreground shadow-sm border border-border/60"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {q.label}
            </button>
          ))}
        </div>

        <Select value={priorityFilter} onValueChange={(v) => setPriorityFilter(v as "ALL" | Priority)}>
          <SelectTrigger className="w-40 h-11 sm:h-9" aria-label="تصفية بالأولوية">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">كل الأولويات</SelectItem>
            {PRIORITY_OPTIONS.map((p) => (
              <SelectItem key={p} value={p}>
                {PRIORITY_LABELS[p]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* ===== القائمة ===== */}
      {listQ.isLoading ? (
        <LoadingRows rows={5} />
      ) : listQ.isError ? (
        <ErrorState
          message={listQ.error instanceof Error ? listQ.error.message : "تعذر تحميل التبليغات"}
          onRetry={() => listQ.refetch()}
        />
      ) : filtered.length === 0 ? (
        <EmptyState
          message={items.length === 0 ? "لا توجد تبليغات بعد" : "لا توجد تبليغات مطابقة للتصفية"}
          sub={
            items.length === 0
              ? "ستظهر هنا إعلانات الكلية فور نشرها"
              : "جرّب تغيير الفلاتر أو إزالتها"
          }
          action={
            items.length > 0 ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setQuick("all");
                  setPriorityFilter("ALL");
                }}
              >
                إزالة التصفية
              </Button>
            ) : undefined
          }
        />
      ) : (
        <div className="space-y-3">
          {filtered.map((a) => (
            <AnnouncementCard
              key={a.id}
              a={a}
              expanded={!!expandedIds[a.id]}
              onToggleExpand={() => toggleExpand(a.id)}
              onOpen={() => openView(a)}
              showMenu={canManage(a)}
              canUpdate={canUpdate}
              canDelete={canDelete}
              onEdit={() => openEdit(a)}
              onDelete={() => setDeleting(a)}
            />
          ))}
        </div>
      )}

      {/* ===== عرض التبليغ كاملاً ===== */}
      <Dialog open={!!viewing} onOpenChange={(v) => !v && setViewing(null)}>
        <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader className="text-start">
            <DialogTitle className="flex items-start gap-2 text-lg leading-7">
              {viewing?.pinned && <span aria-label="مثبّت">📌</span>}
              <span className="break-words">{viewing?.title}</span>
            </DialogTitle>
            <DialogDescription className="text-xs">
              {viewing
                ? `${audienceText(viewing)} — ${viewing.createdByName} — ${fmtDateTime(viewing.publishedAt)}`
                : ""}
            </DialogDescription>
          </DialogHeader>
          <div className="text-sm leading-7 whitespace-pre-line break-words text-foreground/90">
            {viewing?.body}
          </div>
          <div className="flex flex-wrap items-center gap-2 border-t pt-3">
            {viewing && <PriorityBadge priority={viewing.priority} />}
            {viewing?.expiresAt && (
              <span className="text-xs text-muted-foreground">
                ينتهي: {fmtDateTime(viewing.expiresAt)}
              </span>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== نموذج الإنشاء/التعديل ===== */}
      <AnnouncementFormDialog open={editorOpen} onOpenChange={setEditorOpen} editing={editing} />

      {/* ===== تأكيد الحذف ===== */}
      <AlertDialog open={!!deleting} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف التبليغ؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم حذف «{deleting?.title}» نهائياً عن جميع المستلمين. لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => deleting && deleteMut.mutate(deleting.id)}
              disabled={deleteMut.isPending}
            >
              {deleteMut.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ============================================================
// بطاقة تبليغ واحدة
// ============================================================
function AnnouncementCard({
  a,
  expanded,
  onToggleExpand,
  onOpen,
  showMenu,
  canUpdate,
  canDelete,
  onEdit,
  onDelete,
}: {
  a: AnnouncementDTO;
  expanded: boolean;
  onToggleExpand: () => void;
  onOpen: () => void;
  showMenu: boolean;
  canUpdate: boolean;
  canDelete: boolean;
  onEdit: () => void;
  onDelete: () => void;
}) {
  return (
    <Card
      className={cn(
        "rounded-2xl border-border/60 shadow-sm py-0 cursor-pointer transition-all hover:shadow-md",
        !a.isRead && "border-sky-200/70 bg-sky-50/40 dark:bg-sky-950/10"
      )}
      role="button"
      tabIndex={0}
      aria-label={`عرض تبليغ: ${a.title}`}
      onClick={onOpen}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onOpen();
        }
      }}
    >
      <CardContent className="p-4 sm:p-5">
        {/* العنوان + الشارات + القائمة */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1.5 min-w-0">
            <h3 className="font-bold text-[15px] sm:text-base break-words leading-6">
              {a.pinned && (
                <span title="مثبّت" aria-label="مثبّت">
                  📌{" "}
                </span>
              )}
              {a.title}
            </h3>
            <PriorityBadge priority={a.priority} />
            {!a.isRead && (
              <span className="shrink-0 px-2 py-0.5 rounded-full text-[11px] font-bold bg-sky-100 text-sky-800 border border-sky-200 dark:bg-sky-950 dark:text-sky-300 dark:border-sky-900">
                جديد
              </span>
            )}
          </div>

          {showMenu && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-11 w-11 sm:h-9 sm:w-9 shrink-0 text-muted-foreground"
                  aria-label="خيارات التبليغ"
                  onClick={(e) => e.stopPropagation()}
                >
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40">
                {canUpdate && (
                  <DropdownMenuItem onClick={onEdit}>
                    <Pencil className="w-4 h-4" />
                    تعديل
                  </DropdownMenuItem>
                )}
                {canDelete && (
                  <DropdownMenuItem onClick={onDelete} className="text-destructive focus:text-destructive">
                    <Trash2 className="w-4 h-4" />
                    حذف
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>

        {/* النص — قابل للتوسيع بالنقر (line-clamp-3) */}
        <p
          role="button"
          tabIndex={0}
          aria-expanded={expanded}
          title={expanded ? "اضغط للطي" : "اضغط للتوسيع"}
          onClick={(e) => {
            e.stopPropagation();
            onToggleExpand();
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              e.stopPropagation();
              onToggleExpand();
            }
          }}
          className={cn(
            "mt-2 text-sm leading-6 text-foreground/85 whitespace-pre-line break-words cursor-pointer",
            !expanded && "line-clamp-3"
          )}
        >
          {a.body}
        </p>

        {/* المعلومات */}
        <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <User className="w-3.5 h-3.5" aria-hidden="true" />
            {a.createdByName}
          </span>
          <span className="inline-flex items-center gap-1">
            <CalendarDays className="w-3.5 h-3.5" aria-hidden="true" />
            {fmtDateTime(a.publishedAt)}
          </span>
          <span className="inline-flex items-center gap-1">
            <Users2 className="w-3.5 h-3.5" aria-hidden="true" />
            {audienceText(a)}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================
// نموذج الإنشاء/التعديل — جمهور متدرّج (مرحلة ← فرع ← مادة)
// ============================================================
function AnnouncementFormDialog({
  open,
  onOpenChange,
  editing,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: AnnouncementDTO | null;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader className="text-start">
          <DialogTitle>{editing ? "تعديل التبليغ" : "تبليغ جديد"}</DialogTitle>
          <DialogDescription>
            {editing
              ? "عدّل بيانات التبليغ ثم احفظ التغييرات"
              : "سيصل التبليغ إلى المستخدمين المستهدفين فور نشره"}
          </DialogDescription>
        </DialogHeader>
        <AnnouncementForm
          key={editing?.id ?? "new"}
          editing={editing}
          onCancel={() => onOpenChange(false)}
        />
      </DialogContent>
    </Dialog>
  );
}

// جسم النموذج — يُركَّب فقط عند فتح النافذة فيبدأ بحالة معبأة (تعديل) أو نظيفة (إنشاء) دون تأثيرات
function AnnouncementForm({
  editing,
  onCancel,
}: {
  editing: AnnouncementDTO | null;
  onCancel: () => void;
}) {
  const qc = useQueryClient();

  const [title, setTitle] = useState(editing?.title ?? "");
  const [body, setBody] = useState(editing?.body ?? "");
  const [priority, setPriority] = useState<Priority>(editing?.priority ?? "NORMAL");
  const [pinned, setPinned] = useState(editing?.pinned ?? false);
  const [audienceType, setAudienceType] = useState<AudienceType>(editing?.audienceType ?? "ALL");
  const [stageId, setStageId] = useState("");
  const [branchId, setBranchId] = useState("");
  const [subjectId, setSubjectId] = useState("");

  // ===== قوائم الجمهور — تُجلب فقط عند الحاجة (إنشاء + جمهور محدد) =====
  const stagesQ = useQuery({
    queryKey: ["stages"],
    queryFn: () => api<{ items: StageDTO[] }>("/api/stages"),
    enabled: !editing && audienceType !== "ALL",
    staleTime: 60_000,
  });

  const branchesQ = useQuery({
    queryKey: ["branches", stageId],
    queryFn: () => api<{ items: BranchDTO[] }>(`/api/branches?stageId=${encodeURIComponent(stageId)}`),
    enabled: !editing && (audienceType === "BRANCH" || audienceType === "SUBJECT") && !!stageId,
    staleTime: 60_000,
  });

  const subjectsQ = useQuery({
    queryKey: ["subjects", branchId],
    queryFn: () => api<{ items: SubjectDTO[] }>(`/api/subjects?branchId=${encodeURIComponent(branchId)}`),
    enabled: !editing && audienceType === "SUBJECT" && !!branchId,
    staleTime: 60_000,
  });

  const pickStage = (v: string) => {
    setStageId(v);
    setBranchId("");
    setSubjectId("");
  };
  const pickBranch = (v: string) => {
    setBranchId(v);
    setSubjectId("");
  };

  // ===== الحفظ (إنشاء POST / تعديل PATCH) =====
  const saveMut = useMutation({
    mutationFn: (): Promise<{ announcement: { id: string }; recipients?: number }> => {
      if (editing) {
        return api<{ announcement: { id: string } }>(`/api/announcements/${editing.id}`, {
          method: "PATCH",
          body: JSON.stringify({ title, body, priority, pinned }),
        });
      }
      return api<{ announcement: { id: string }; recipients: number }>("/api/announcements", {
        method: "POST",
        body: JSON.stringify({
          title,
          body,
          priority,
          audienceType,
          pinned,
          stageId: audienceType === "STAGE" ? stageId : null,
          branchId: audienceType === "BRANCH" ? branchId : null,
          subjectId: audienceType === "SUBJECT" ? subjectId : null,
        }),
      });
    },
    onSuccess: (data) => {
      if (editing) {
        toast.success("تم حفظ التعديلات");
      } else {
        toast.success(`تم النشر لـ ${data.recipients ?? 0} مستخدماً`);
      }
      qc.invalidateQueries({ queryKey: LIST_KEY });
      onCancel();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const submit = () => {
    if (title.trim().length < 3) {
      toast.error("العنوان مطلوب (3 أحرف على الأقل)");
      return;
    }
    if (body.trim().length < 3) {
      toast.error("نص التبليغ مطلوب (3 أحرف على الأقل)");
      return;
    }
    if (!editing) {
      if (audienceType === "STAGE" && !stageId) {
        toast.error("اختر المرحلة المستهدفة");
        return;
      }
      if (audienceType === "BRANCH" && !branchId) {
        toast.error("اختر الفرع المستهدف");
        return;
      }
      if (audienceType === "SUBJECT" && !subjectId) {
        toast.error("اختر المادة المستهدفة");
        return;
      }
    }
    saveMut.mutate();
  };

  return (
    <div className="space-y-4">
      {/* العنوان */}
          <div className="space-y-1.5">
            <Label htmlFor="an-title">العنوان *</Label>
            <Input
              id="an-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثال: بدء الدوام الصباحي للفصل الدراسي"
              maxLength={200}
            />
          </div>

          {/* النص */}
          <div className="space-y-1.5">
            <Label htmlFor="an-body">النص *</Label>
            <Textarea
              id="an-body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="اكتب نص التبليغ هنا..."
              rows={5}
              className="min-h-28"
            />
          </div>

          {/* الأولوية */}
          <div className="space-y-1.5">
            <Label>الأولوية</Label>
            <RadioGroup
              value={priority}
              onValueChange={(v) => setPriority(v as Priority)}
              className="grid grid-cols-3 gap-2"
            >
              {PRIORITY_OPTIONS.map((p) => (
                <Label
                  key={p}
                  htmlFor={`prio-${p}`}
                  className="flex items-center justify-center gap-2 rounded-xl border px-2 py-2.5 cursor-pointer text-sm font-medium transition-colors has-[button[data-state=checked]]:border-primary has-[button[data-state=checked]]:bg-primary/5"
                >
                  <RadioGroupItem id={`prio-${p}`} value={p} />
                  {PRIORITY_LABELS[p]}
                </Label>
              ))}
            </RadioGroup>
          </div>

          {/* الجمهور */}
          <div className="space-y-1.5">
            <Label>الجمهور المستهدف</Label>
            {editing ? (
              <p className="rounded-xl bg-muted/60 border px-3 py-2.5 text-sm break-words">
                {audienceText(editing)}
                <span className="text-xs text-muted-foreground"> (لا يمكن تغيير الجمهور بعد النشر)</span>
              </p>
            ) : (
              <>
                <RadioGroup
                  value={audienceType}
                  onValueChange={(v) => setAudienceType(v as AudienceType)}
                  className="grid grid-cols-2 sm:grid-cols-4 gap-2"
                >
                  {AUDIENCE_OPTIONS.map((t) => (
                    <Label
                      key={t}
                      htmlFor={`aud-${t}`}
                      className="flex items-center justify-center gap-1.5 rounded-xl border px-2 py-2.5 cursor-pointer text-sm font-medium transition-colors has-[button[data-state=checked]]:border-primary has-[button[data-state=checked]]:bg-primary/5"
                    >
                      <RadioGroupItem id={`aud-${t}`} value={t} />
                      {AUDIENCE_LABELS[t]}
                    </Label>
                  ))}
                </RadioGroup>

                {/* قوائم الجمهور المتتالية: مرحلة ← فرع ← مادة */}
                {audienceType !== "ALL" && (
                  <div className="grid gap-2 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label className="text-xs text-muted-foreground">المرحلة</Label>
                      <Select value={stageId} onValueChange={pickStage} disabled={stagesQ.isLoading}>
                        <SelectTrigger className="w-full">
                          <SelectValue
                            placeholder={stagesQ.isLoading ? "جارٍ التحميل..." : "اختر المرحلة"}
                          />
                        </SelectTrigger>
                        <SelectContent>
                          {stagesQ.data?.items.map((s) => (
                            <SelectItem key={s.id} value={s.id}>
                              {s.nameAr}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {(audienceType === "BRANCH" || audienceType === "SUBJECT") && (
                      <div className="space-y-1.5">
                        <Label className="text-xs text-muted-foreground">الفرع</Label>
                        <Select
                          value={branchId}
                          onValueChange={pickBranch}
                          disabled={!stageId || branchesQ.isLoading}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue
                              placeholder={
                                !stageId
                                  ? "اختر مرحلة أولاً"
                                  : branchesQ.isLoading
                                    ? "جارٍ التحميل..."
                                    : "اختر الفرع"
                              }
                            />
                          </SelectTrigger>
                          <SelectContent>
                            {branchesQ.data?.items.map((b) => (
                              <SelectItem key={b.id} value={b.id}>
                                {b.nameAr}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    {audienceType === "SUBJECT" && (
                      <div className="space-y-1.5 sm:col-span-2">
                        <Label className="text-xs text-muted-foreground">المادة</Label>
                        <Select
                          value={subjectId}
                          onValueChange={setSubjectId}
                          disabled={!branchId || subjectsQ.isLoading}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue
                              placeholder={
                                !branchId
                                  ? "اختر فرعاً أولاً"
                                  : subjectsQ.isLoading
                                    ? "جارٍ التحميل..."
                                    : "اختر المادة"
                              }
                            />
                          </SelectTrigger>
                          <SelectContent>
                            {subjectsQ.data?.items.map((s) => (
                              <SelectItem key={s.id} value={s.id}>
                                {s.nameAr} — {s.code}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </div>
                )}
                <p className="text-xs text-muted-foreground leading-5">
                  ملاحظة: قد تكون خيارات الجمهور محدودة بصلاحياتك — التدريسي عادةً ينشر لجمهور مادة من مواده
                  المسندة، والطالب المسؤول لجمهور مرحلته. سيظهر خطأ واضح إن اخترت جمهوراً خارج نطاقك.
                </p>
              </>
            )}
          </div>

          {/* التثبيت */}
          <div className="flex items-center justify-between rounded-xl border px-3 py-3">
            <div>
              <Label htmlFor="an-pinned" className="cursor-pointer">
                تثبيت التبليغ
              </Label>
              <p className="text-xs text-muted-foreground mt-0.5">يظهر المثبّت في أعلى القائمة دائماً</p>
            </div>
            <Switch id="an-pinned" checked={pinned} onCheckedChange={setPinned} aria-label="تثبيت التبليغ" />
          </div>

      <DialogFooter className="pt-2">
        <Button variant="outline" onClick={onCancel} disabled={saveMut.isPending}>
          إلغاء
        </Button>
        <Button onClick={submit} disabled={saveMut.isPending}>
          {saveMut.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
          {editing ? "حفظ التعديلات" : "نشر التبليغ"}
        </Button>
      </DialogFooter>
    </div>
  );
}
