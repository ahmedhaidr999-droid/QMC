"use client";
// صفحة تسجيل الدخول — تصميم أنيق ببطاقات حسابات تجريبية للاختبار
import { useState } from "react";
import { useApp, navigate } from "@/lib/client/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GraduationCap, LogIn, Loader2, KeyRound, User } from "lucide-react";
import { toast } from "sonner";

const DEMO_ACCOUNTS = [
  { label: "مالك النظام", email: "owner@college.edu", pass: "Owner@123", desc: "كل الصلاحيات + تعديل المصفوفة" },
  { label: "عميد الكلية", email: "dean@college.edu", pass: "Dean@123", desc: "إشراف كامل" },
  { label: "تدريسي", email: "inst1@college.edu", pass: "Inst@123", desc: "مواده المسندة فقط" },
  { label: "طالب مسؤول", email: "student1@college.edu", pass: "StAdmin@123", desc: "محاضرات مرحلته" },
  { label: "طالب", email: "student2@college.edu", pass: "Student@123", desc: "تصفح + باركوده" },
];

export function LoginView() {
  const { login } = useApp();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const doLogin = async (e?: string, p?: string) => {
    const em = e ?? email;
    const pw = p ?? password;
    if (!em || !pw) {
      toast.error("أدخل البريد وكلمة المرور");
      return;
    }
    setLoading(true);
    try {
      const user = await login(em, pw);
      toast.success(`أهلاً ${user.fullName} 👋`);
      navigate("/dashboard");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "فشل تسجيل الدخول");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-primary/5 via-sky-50 to-white dark:from-primary/10 p-4 gap-6">
      <div className="text-center">
        <div className="inline-flex p-4 rounded-3xl brand-gradient text-white shadow-lg mb-4">
          <GraduationCap className="w-12 h-12" />
        </div>
        <h1 className="text-3xl font-extrabold">نظام إدارة الكلية</h1>
        <p className="text-muted-foreground mt-2">حضور بالباركود • محاضرات • تبليغات • صلاحيات ديناميكية</p>
      </div>

      <Card className="w-full max-w-md rounded-3xl shadow-xl border-border/60">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <LogIn className="w-5 h-5 text-primary" />
            تسجيل الدخول
          </CardTitle>
          <CardDescription>لا يوجد تسجيل ذاتي — الحسابات تُنشأ من إدارة الكلية</CardDescription>
        </CardHeader>
        <CardContent>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              doLogin();
            }}
          >
            <div className="space-y-2">
              <Label htmlFor="email">
                <User className="w-4 h-4 inline ml-1" />
                البريد الإلكتروني
              </Label>
              <Input
                id="email"
                type="email"
                dir="ltr"
                placeholder="you@college.edu"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">
                <KeyRound className="w-4 h-4 inline ml-1" />
                كلمة المرور
              </Label>
              <Input
                id="password"
                type="password"
                dir="ltr"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                required
              />
            </div>
            <Button type="submit" className="w-full gap-2 h-11" size="lg" disabled={loading}>
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <LogIn className="w-4 h-4" />}
              دخول
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* حسابات تجريبية للاختبار السريع */}
      <div className="w-full max-w-md">
        <p className="text-xs text-muted-foreground text-center mb-2">حسابات تجريبية — اضغط للدخول المباشر</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {DEMO_ACCOUNTS.map((a) => (
            <button
              key={a.email}
              onClick={() => doLogin(a.email, a.pass)}
              disabled={loading}
              className="rounded-xl border bg-card hover:border-primary/50 hover:shadow-md transition-all p-2.5 text-center disabled:opacity-50"
              title={a.desc}
            >
              <p className="text-xs font-bold">{a.label}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5 truncate">{a.email}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
