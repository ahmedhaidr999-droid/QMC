"use client";
// الإعدادات — تغيير كلمة المرور + تفعيل الإشعارات + معلومات التطبيق + تسجيل خروج
import { useState } from "react";
import { useApp, navigate } from "@/lib/client/store";
import { api } from "@/lib/client/api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Bell, KeyRound, Loader2, LogOut, Smartphone, CheckCircle2, XCircle, Info } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/app/shared/ui-bits";

function urlBase64ToUint8Array(base64: string) {
  const padding = "=".repeat((4 - (base64.length % 4)) % 4);
  const b64 = (base64 + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(b64);
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}

export function SettingsView() {
  const { user, logout } = useApp();
  const [cur, setCur] = useState("");
  const [next, setNext] = useState("");
  const [conf, setConf] = useState("");
  const [saving, setSaving] = useState(false);
  const [pushState, setPushState] = useState<"unknown" | "on" | "off" | "unsupported">("unknown");
  const [enabling, setEnabling] = useState(false);

  // فحص حالة الإشعارات
  const checkPush = async () => {
    if (typeof Notification === "undefined" || !("serviceWorker" in navigator) || !("PushManager" in window)) {
      setPushState("unsupported");
      return;
    }
    const perm = await Notification.requestPermission().catch(() => "denied");
    if (perm !== "granted") return setPushState("off");
    try {
      const reg = await navigator.serviceWorker.ready;
      const vapid = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
      if (!vapid) return setPushState("off");
      const existing = await reg.pushManager.getSubscription();
      const sub = existing ?? (await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(vapid) }));
      const json = sub.toJSON();
      await api("/api/push/subscribe", {
        method: "POST",
        body: JSON.stringify({ endpoint: json.endpoint, keys: { p256dh: json.keys?.p256dh ?? "", auth: json.keys?.auth ?? "" } }),
      });
      setPushState("on");
      toast.success("تم تفعيل الإشعارات 🔔");
    } catch {
      setPushState("off");
      toast.error("تعذر تفعيل الإشعارات — تحقق من دعم المتصفح");
    }
  };

  const changePassword = async () => {
    if (next.length < 8) return toast.error("كلمة المرور الجديدة قصيرة (8 أحرف على الأقل)");
    if (next !== conf) return toast.error("التأكيد لا يطابق");
    setSaving(true);
    try {
      await api("/api/auth/change-password", {
        method: "POST",
        body: JSON.stringify({ currentPassword: cur, newPassword: next }),
      });
      toast.success("تم تغيير كلمة المرور ✅");
      setCur(""); setNext(""); setConf("");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "فشل التغيير");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <PageHeader title="الإعدادات" description="حسابك وإشعاراتك وخصائص التطبيق" icon={<KeyRound className="w-5 h-5" />} />

      <div className="grid lg:grid-cols-2 gap-4 max-w-4xl">
        {/* معلومات الحساب */}
        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle className="text-base">معلومات الحساب</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <InfoRow label="الاسم" value={user?.fullName} />
            <InfoRow label="البريد" value={user?.email} />
            <InfoRow label="الدور" value={user?.roleName} />
            {user?.universityId && <InfoRow label="الرقم الجامعي" value={user.universityId} />}
            {user?.stageId && <InfoRow label="المرحلة / الفرع" value={`${user.academicYear ?? ""}`} />}
          </CardContent>
        </Card>

        {/* الإشعارات */}
        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Bell className="w-4 h-4 text-primary" />
              إشعارات المذكرة (Push)
            </CardTitle>
            <CardDescription>تصلك التبليغات فور نشرها — الإشعار يفتح الصفحة مباشرة</CardDescription>
          </CardHeader>
          <CardContent>
            {pushState === "on" ? (
              <div className="flex items-center gap-2 text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl p-3 text-sm font-medium">
                <CheckCircle2 className="w-5 h-5" />
                الإشعارات مفعّلة على هذا الجهاز
              </div>
            ) : (
              <Button onClick={checkPush} disabled={enabling || pushState === "unsupported"} className="gap-2 w-full sm:w-auto">
                {enabling ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bell className="w-4 h-4" />}
                تفعيل الإشعارات
              </Button>
            )}
            {pushState === "unsupported" && (
              <p className="text-xs text-muted-foreground mt-2">متصفحك لا يدعم الإشعارات — ستبقى الإشعارات داخل التطبيق تعمل.</p>
            )}
            <p className="text-xs text-muted-foreground mt-2">
              لاحظ: على آيفون تعمل الإشعارات بعد إضافة التطبيق للشاشة الرئيسية (iOS 16.4+).
            </p>
          </CardContent>
        </Card>

        {/* تغيير كلمة المرور */}
        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle className="text-base">تغيير كلمة المرور</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1.5">
              <Label>الحالية</Label>
              <Input type="password" dir="ltr" value={cur} onChange={(e) => setCur(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>الجديدة</Label>
              <Input type="password" dir="ltr" value={next} onChange={(e) => setNext(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>تأكيد الجديدة</Label>
              <Input type="password" dir="ltr" value={conf} onChange={(e) => setConf(e.target.value)} />
            </div>
            <Button onClick={changePassword} disabled={saving} className="gap-2">
              {saving && <Loader2 className="w-4 h-4 animate-spin" />}
              حفظ
            </Button>
          </CardContent>
        </Card>

        {/* التطبيق */}
        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-primary" />
              التطبيق (PWA)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-muted-foreground">
            <p className="flex items-start gap-2">
              <Info className="w-4 h-4 mt-0.5 shrink-0" />
              يعمل النظام كتطبيق قابل للتثبيت على Android و iOS دون متاجر، ويُحدَّث فور نشر نسخة جديدة.
            </p>
            <p className="text-xs">الإصدار 1.0.0</p>
            <Button
              variant="destructive"
              className="gap-2 w-full sm:w-auto"
              onClick={async () => {
                await logout();
                toast.success("تم تسجيل الخروج");
              }}
            >
              <LogOut className="w-4 h-4" />
              تسجيل الخروج
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value?: string | null }) {
  return (
    <div className="flex items-center justify-between gap-2 border-b last:border-0 pb-2">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium text-end">{value ?? "—"}</span>
    </div>
  );
}
