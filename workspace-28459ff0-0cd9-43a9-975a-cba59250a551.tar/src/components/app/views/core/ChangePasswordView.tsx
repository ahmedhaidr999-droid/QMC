"use client";
// إجبار تغيير كلمة المرور عند أول دخول (mustChangePassword)
import { useState } from "react";
import { useApp, navigate } from "@/lib/client/store";
import { api } from "@/lib/client/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { KeyRound, Loader2, ShieldAlert } from "lucide-react";
import { toast } from "sonner";

export function ChangePasswordView() {
  const { fetchMe } = useApp();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (next.length < 8) return toast.error("كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل");
    if (next !== confirm) return toast.error("التأكيد لا يطابق كلمة المرور الجديدة");
    setLoading(true);
    try {
      await api("/api/auth/change-password", {
        method: "POST",
        body: JSON.stringify({ currentPassword: current, newPassword: next }),
      });
      toast.success("تم تغيير كلمة المرور بنجاح");
      await fetchMe();
      navigate("/dashboard");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "فشل التغيير");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-amber-50 to-white dark:from-amber-950/30 p-4">
      <Card className="w-full max-w-md rounded-3xl shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-500" />
            تغيير كلمة المرور إلزامي
          </CardTitle>
          <CardDescription>لأمان حسابك، يجب تغيير كلمة المرور المؤقتة قبل استخدام النظام</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="cur">كلمة المرور الحالية (المؤقتة)</Label>
            <Input id="cur" type="password" dir="ltr" value={current} onChange={(e) => setCurrent(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="next">كلمة المرور الجديدة</Label>
            <Input id="next" type="password" dir="ltr" value={next} onChange={(e) => setNext(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="conf">تأكيد كلمة المرور الجديدة</Label>
            <Input id="conf" type="password" dir="ltr" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
          </div>
          <Button className="w-full gap-2 h-11" size="lg" onClick={submit} disabled={loading}>
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />}
            حفظ كلمة المرور الجديدة
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
