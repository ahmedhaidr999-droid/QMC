"use client";
// لوحة التحكم — مختلفة لكل دور (مالك/عميد، تدريسي، طالب)
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/client/api";
import { useApp, navigate } from "@/lib/client/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ErrorState, StatCard } from "@/components/app/shared/ui-bits";
import { fmtDateTime } from "@/lib/date-fmt";
import {
  Users, GraduationCap, BookOpen, Layers, CalendarCheck, QrCode, Megaphone,
  Percent, AlertTriangle, School, History, Video, DoorOpen, type LucideIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";

type DashboardData = {
  role: string;
  stats: Record<string, number | string | null>;
  atRisk?: { id: string; name: string; uid: string | null; absent: number; pct: number }[];
  announcements?: { id: string; title: string; priority: string; pinned: boolean; by: string; at: string }[];
  recentEdits?: { id: string; by: string; reason: string | null; at: string; entityId: string | null }[];
  mySubjects?: { id: string; nameAr: string; code: string; branchName: string }[];
  todaySessions?: { id: string; subjectName: string; startsAt: string; status: string; room: string | null; total: number }[];
  recentLectures?: { id: string; title: string; subjectName: string; createdAt: string; isPublished: boolean }[];
  newLectures?: { id: string; title: string; subjectName: string; createdAt: string }[];
  unreadAnnouncementsList?: { id: string; title: string; priority: string; at: string }[];
};

export function DashboardView() {
  const { user } = useApp();
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["dashboard"],
    queryFn: () => api<DashboardData>("/api/reports/dashboard"),
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-2xl" />
          ))}
        </div>
        <Skeleton className="h-64 rounded-2xl" />
      </div>
    );
  }
  if (error) return <ErrorState message={error instanceof Error ? error.message : "خطأ"} onRetry={refetch} />;
  if (!data) return null;

  const s = data.stats;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">أهلاً، {user?.fullName?.split(" ")[0]} 👋</h1>
        <p className="text-sm text-muted-foreground mt-1">
          {data.role === "STUDENT" || data.role === "STUDENT_ADMIN"
            ? `${s.stageName ?? ""} — ${s.branchName ?? ""}`
            : user?.roleName}
        </p>
      </div>

      {/* ===== أرقام المالك/العميد ===== */}
      {(data.role === "OWNER" || data.role === "DEAN") && (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <StatCard label="طلاب" value={s.students as number} icon={<Users className="w-5 h-5" />} tone="primary" />
            <StatCard label="تدريسيون" value={s.instructors as number} icon={<GraduationCap className="w-5 h-5" />} tone="accent" />
            <StatCard label="مواد" value={s.subjects as number} icon={<BookOpen className="w-5 h-5" />} tone="warning" />
            <StatCard label="مراحل / فروع" value={`${s.stages} / ${s.branches}`} icon={<Layers className="w-5 h-5" />} tone="neutral" />
            <StatCard label="نسبة الحضور العامة" value={s.overallPct != null ? `${s.overallPct}%` : "—"} icon={<Percent className="w-5 h-5" />} tone="primary" />
            <StatCard label="جلسات مفتوحة الآن" value={s.openSessions as number} icon={<CalendarCheck className="w-5 h-5" />} tone="accent" />
            <StatCard label="معرّضون للحرمان" value={s.atRiskCount as number} icon={<AlertTriangle className="w-5 h-5" />} tone="danger" hint="أكثر من 25% غياباً" />
            <StatCard label="الهيكل الأكاديمي" value="تصفح" icon={<School className="w-5 h-5" />} tone="neutral" onClick={() => navigate("/stages")} />
          </div>

          <div className="grid lg:grid-cols-2 gap-4">
            <SectionCard title="آخر التبليغات" icon={<Megaphone className="w-4 h-4" />} action={{ label: "الكل", path: "/announcements" }}>
              {data.announcements?.length ? (
                data.announcements.map((a) => (
                  <div key={a.id} className="flex items-center justify-between gap-2 py-2 border-b last:border-0">
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{a.pinned && "📌 "}{a.title}</p>
                      <p className="text-xs text-muted-foreground">{a.by} — {fmtDateTime(a.at)}</p>
                    </div>
                  </div>
                ))
              ) : (
                <EmptyLine />
              )}
            </SectionCard>

            <SectionCard title="آخر تعديلات الحضور" icon={<History className="w-4 h-4" />} action={{ label: "سجل التدقيق", path: "/admin-audit" }}>
              {data.recentEdits?.length ? (
                data.recentEdits.map((e) => (
                  <div key={e.id} className="py-2 border-b last:border-0">
                    <p className="text-sm font-medium">{e.by}</p>
                    <p className="text-xs text-muted-foreground truncate">{e.reason} — {fmtDateTime(e.at)}</p>
                  </div>
                ))
              ) : (
                <EmptyLine />
              )}
            </SectionCard>
          </div>

          <SectionCard title="طلاب معرّضون للحرمان" icon={<AlertTriangle className="w-4 h-4" />}>
            {data.atRisk?.length ? (
              <div className="grid sm:grid-cols-2 gap-2">
                {data.atRisk.map((r) => (
                  <div key={r.id} className="flex items-center justify-between rounded-xl border border-red-200 bg-red-50 dark:bg-red-950/30 px-3 py-2">
                    <div>
                      <p className="text-sm font-semibold">{r.name}</p>
                      <p className="text-xs text-muted-foreground">{r.uid}</p>
                    </div>
                    <div className="text-end">
                      <p className="text-sm font-bold text-destructive">{r.pct}%</p>
                      <p className="text-[10px] text-muted-foreground">غياب {r.absent}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyLine text="لا يوجد طلاب معرّضون للحرمان" />
            )}
          </SectionCard>
        </>
      )}

      {/* ===== لوحة التدريسي ===== */}
      {data.role === "INSTRUCTOR" && (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
            <StatCard label="موادي" value={s.subjectsCount as number} icon={<BookOpen className="w-5 h-5" />} tone="primary" />
            <StatCard label="جلسات اليوم" value={s.todaySessionsCount as number} icon={<CalendarCheck className="w-5 h-5" />} tone="accent" />
            <StatCard label="تنبيهات حرمان" value={s.atRiskCount as number} icon={<AlertTriangle className="w-5 h-5" />} tone="danger" />
          </div>

          <SectionCard title="جلساتي اليوم" icon={<DoorOpen className="w-4 h-4" />} action={{ label: "كل الجلسات", path: "/attendance" }}>
            {data.todaySessions?.length ? (
              data.todaySessions.map((t) => (
                <div key={t.id} className="flex items-center justify-between gap-2 py-2.5 border-b last:border-0">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold truncate">{t.subjectName}</p>
                    <p className="text-xs text-muted-foreground">
                      {fmtDateTime(t.startsAt)} {t.room && `— ${t.room}`}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${t.status === "OPEN" ? "bg-emerald-100 text-emerald-800" : t.status === "CLOSED" ? "bg-muted text-muted-foreground" : "bg-sky-100 text-sky-800"}`}>
                      {t.status === "OPEN" ? "مفتوحة" : t.status === "CLOSED" ? "مغلقة" : "مجدولة"}
                    </span>
                    <Button size="sm" onClick={() => navigate(`/scan/${t.id}`)}>
                      ابدأ الحضور
                    </Button>
                  </div>
                </div>
              ))
            ) : (
              <EmptyLine text="لا توجد جلسات اليوم" />
            )}
          </SectionCard>

          <div className="grid lg:grid-cols-2 gap-4">
            <SectionCard title="موادي المسندة" icon={<BookOpen className="w-4 h-4" />}>
              {data.mySubjects?.map((m) => (
                <button key={m.id} onClick={() => navigate(`/subjects/${m.id}`)} className="w-full flex items-center justify-between py-2 border-b last:border-0 hover:bg-muted/40 rounded px-1 transition-colors text-start">
                  <span className="text-sm font-medium">{m.nameAr}</span>
                  <span className="text-xs text-muted-foreground">{m.code} — {m.branchName}</span>
                </button>
              ))}
            </SectionCard>
            <SectionCard title="آخر محاضراتي" icon={<Video className="w-4 h-4" />}>
              {data.recentLectures?.length ? (
                data.recentLectures.map((l) => (
                  <button key={l.id} onClick={() => navigate(`/subjects/${(l as { subjectId?: string }).subjectId ?? ""}`)} className="w-full py-2 border-b last:border-0 text-start hover:bg-muted/40 rounded px-1">
                    <p className="text-sm font-medium truncate">{l.title}</p>
                    <p className="text-xs text-muted-foreground">{l.subjectName} — {fmtDateTime(l.createdAt)}</p>
                  </button>
                ))
              ) : (
                <EmptyLine />
              )}
            </SectionCard>
          </div>
        </>
      )}

      {/* ===== لوحة الطالب ===== */}
      {(data.role === "STUDENT" || data.role === "STUDENT_ADMIN") && (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <StatCard label="نسبة حضوري" value={s.myAttendancePct != null ? `${s.myAttendancePct}%` : "—"} icon={<Percent className="w-5 h-5" />} tone="primary" />
            <StatCard label="تبليغات غير مقروءة" value={s.unreadAnnouncements as number} icon={<Megaphone className="w-5 h-5" />} tone="accent" />
            <StatCard label="محاضرات جديدة" value={s.newLecturesCount as number} icon={<BookOpen className="w-5 h-5" />} tone="warning" />
            <StatCard label="باركودي" value="عرض" icon={<QrCode className="w-5 h-5" />} tone="primary" onClick={() => navigate("/my-qr")} />
          </div>

          <div className="grid lg:grid-cols-2 gap-4">
            <SectionCard title="محاضرات جديدة لمرحلتي" icon={<BookOpen className="w-4 h-4" />} action={{ label: "المراحل", path: "/stages" }}>
              {data.newLectures?.length ? (
                data.newLectures.map((l) => (
                  <div key={l.id} className="py-2 border-b last:border-0">
                    <p className="text-sm font-medium truncate">{l.title}</p>
                    <p className="text-xs text-muted-foreground">{l.subjectName} — {fmtDateTime(l.createdAt)}</p>
                  </div>
                ))
              ) : (
                <EmptyLine />
              )}
            </SectionCard>
            <SectionCard title="تبليغات لم تقرأها" icon={<Megaphone className="w-4 h-4" />} action={{ label: "الكل", path: "/announcements" }}>
              {data.unreadAnnouncementsList?.length ? (
                data.unreadAnnouncementsList.map((a) => (
                  <div key={a.id} className="py-2 border-b last:border-0">
                    <p className="text-sm font-medium truncate">{a.priority === "URGENT" && "🔴 "}{a.title}</p>
                    <p className="text-xs text-muted-foreground">{fmtDateTime(a.at)}</p>
                  </div>
                ))
              ) : (
                <EmptyLine text="لا توجد تبليغات جديدة" />
              )}
            </SectionCard>
          </div>
        </>
      )}
    </div>
  );
}

function SectionCard({
  title, icon, children, action,
}: {
  title: string; icon: React.ReactNode; children: React.ReactNode; action?: { label: string; path: string };
}) {
  return (
    <Card className="rounded-2xl border-border/60 shadow-sm">
      <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
        <CardTitle className="text-base flex items-center gap-2">
          <span className="text-primary">{icon}</span>
          {title}
        </CardTitle>
        {action && (
          <Button variant="ghost" size="sm" className="text-xs h-8" onClick={() => navigate(action.path)}>
            {action.label}
          </Button>
        )}
      </CardHeader>
      <CardContent className="pt-0">{children}</CardContent>
    </Card>
  );
}

function EmptyLine({ text = "لا توجد بيانات بعد" }: { text?: string }) {
  return <p className="py-6 text-center text-sm text-muted-foreground">{text}</p>;
}
