// ثوابت النظام — القيم المسموحة والنصوص العربية
// (SQLite لا يدعم Enums لذا هذه الثوابت هي مصدر الحقيقة مع تحقق Zod)

export type Scope = "NONE" | "OWN" | "ASSIGNED" | "BRANCH" | "STAGE" | "ALL";
export const SCOPES: Scope[] = ["NONE", "OWN", "ASSIGNED", "BRANCH", "STAGE", "ALL"];
export const SCOPE_LABELS: Record<Scope, string> = {
  NONE: "—",
  OWN: "سجلاته فقط",
  ASSIGNED: "مواده المسندة",
  BRANCH: "فرعه فقط",
  STAGE: "مرحلته فقط",
  ALL: "الكل",
};

// ===== حالة الحضور =====
export const ATTENDANCE_STATUSES = ["PRESENT", "ABSENT", "LATE", "EXCUSED"] as const;
export type AttendanceStatus = (typeof ATTENDANCE_STATUSES)[number];
export const STATUS_LABELS: Record<AttendanceStatus, string> = {
  PRESENT: "حاضر",
  ABSENT: "غائب",
  LATE: "متأخر",
  EXCUSED: "مجاز",
};
export const STATUS_SYMBOLS: Record<AttendanceStatus, string> = {
  PRESENT: "✓",
  ABSENT: "غ",
  LATE: "ت",
  EXCUSED: "م",
};
export const STATUS_COLORS: Record<AttendanceStatus, string> = {
  PRESENT: "bg-emerald-100 text-emerald-800 border-emerald-200",
  ABSENT: "bg-red-100 text-red-800 border-red-200",
  LATE: "bg-amber-100 text-amber-800 border-amber-200",
  EXCUSED: "bg-sky-100 text-sky-800 border-sky-200",
};

// ===== طرق التسجيل =====
export const ATTENDANCE_METHODS = ["QR_DYNAMIC", "QR_STATIC", "MANUAL", "EXCEL_IMPORT", "SYSTEM"] as const;
export type AttendanceMethod = (typeof ATTENDANCE_METHODS)[number];
export const METHOD_LABELS: Record<AttendanceMethod, string> = {
  QR_DYNAMIC: "QR متغيّر",
  QR_STATIC: "باركود ثابت",
  MANUAL: "يدوي",
  EXCEL_IMPORT: "استيراد Excel",
  SYSTEM: "النظام",
};

// ===== حالة الجلسة =====
export const SESSION_STATUSES = ["SCHEDULED", "OPEN", "CLOSED"] as const;
export type SessionStatus = (typeof SESSION_STATUSES)[number];
export const SESSION_STATUS_LABELS: Record<SessionStatus, string> = {
  SCHEDULED: "مجدولة",
  OPEN: "مفتوحة",
  CLOSED: "مغلقة",
};

// ===== الجمهور والأولوية ونوع المحاضرة =====
export const AUDIENCE_TYPES = ["ALL", "STAGE", "BRANCH", "SUBJECT"] as const;
export type AudienceType = (typeof AUDIENCE_TYPES)[number];
export const AUDIENCE_LABELS: Record<AudienceType, string> = {
  ALL: "الكل",
  STAGE: "مرحلة",
  BRANCH: "فرع تدريسي",
  SUBJECT: "مادة",
};

export const PRIORITIES = ["NORMAL", "IMPORTANT", "URGENT"] as const;
export type Priority = (typeof PRIORITIES)[number];
export const PRIORITY_LABELS: Record<Priority, string> = {
  NORMAL: "عادية",
  IMPORTANT: "مهمة",
  URGENT: "عاجلة",
};

export const LECTURE_TYPES = ["THEORY", "PRACTICAL"] as const;
export type LectureType = (typeof LECTURE_TYPES)[number];
export const LECTURE_TYPE_LABELS: Record<LectureType, string> = {
  THEORY: "نظري",
  PRACTICAL: "عملي",
};

export const ROLE_KEYS = ["OWNER", "DEAN", "INSTRUCTOR", "STUDENT_ADMIN", "STUDENT"] as const;
export type RoleKey = (typeof ROLE_KEYS)[number];
export const ROLE_LABELS: Record<string, string> = {
  OWNER: "مالك النظام",
  DEAN: "عميد الكلية",
  INSTRUCTOR: "تدريسي",
  STUDENT_ADMIN: "طالب مسؤول",
  STUDENT: "طالب",
};

// ===== تعريف الصلاحيات (المفتاح، المجموعة، الاسم العربي) =====
export type PermissionDef = { key: string; group: string; nameAr: string };
export const PERMISSION_DEFS: PermissionDef[] = [
  { key: "permissions.manage", group: "الإدارة", nameAr: "إدارة الصلاحيات" },
  { key: "users.manage", group: "الإدارة", nameAr: "إدارة المستخدمين" },
  { key: "structure.manage", group: "الإدارة", nameAr: "إدارة الهيكل الأكاديمي" },
  { key: "lectures.read", group: "المحاضرات", nameAr: "عرض المحاضرات" },
  { key: "lectures.create", group: "المحاضرات", nameAr: "إضافة محاضرة" },
  { key: "lectures.update", group: "المحاضرات", nameAr: "تعديل محاضرة" },
  { key: "lectures.delete", group: "المحاضرات", nameAr: "حذف محاضرة" },
  { key: "attendance.session.manage", group: "الحضور", nameAr: "إدارة جلسات الحضور" },
  { key: "attendance.scan", group: "الحضور", nameAr: "مسح الباركود" },
  { key: "attendance.view", group: "الحضور", nameAr: "عرض الحضور" },
  { key: "attendance.edit", group: "الحضور", nameAr: "تعديل الحضور" },
  { key: "attendance.export", group: "الحضور", nameAr: "تصدير الحضور (Excel)" },
  { key: "attendance.import", group: "الحضور", nameAr: "استيراد الحضور (Excel)" },
  { key: "announcements.read", group: "التبليغات", nameAr: "قراءة التبليغات" },
  { key: "announcements.create", group: "التبليغات", nameAr: "إنشاء تبليغ" },
  { key: "announcements.update", group: "التبليغات", nameAr: "تعديل تبليغ" },
  { key: "announcements.delete", group: "التبليغات", nameAr: "حذف تبليغ" },
  { key: "reports.view", group: "التقارير", nameAr: "عرض التقارير" },
  { key: "qr.own.view", group: "الطالب", nameAr: "عرض باركوده الشخصي" },
  { key: "audit.view", group: "السجلات", nameAr: "عرض سجل التدقيق" },
];

// ===== المصفوفة الافتراضية (Seed) — القسم 7 من البرومبت =====
export const DEFAULT_MATRIX: Record<string, Record<string, Scope>> = {
  OWNER: {
    "permissions.manage": "ALL", "users.manage": "ALL", "structure.manage": "ALL",
    "lectures.read": "ALL", "lectures.create": "ALL", "lectures.update": "ALL", "lectures.delete": "ALL",
    "attendance.session.manage": "ALL", "attendance.scan": "ALL", "attendance.view": "ALL",
    "attendance.edit": "ALL", "attendance.export": "ALL", "attendance.import": "ALL",
    "announcements.read": "ALL", "announcements.create": "ALL", "announcements.update": "ALL",
    "announcements.delete": "ALL", "reports.view": "ALL", "qr.own.view": "NONE", "audit.view": "ALL",
  },
  DEAN: {
    "users.manage": "ALL", "structure.manage": "ALL",
    "lectures.read": "ALL", "lectures.create": "ALL", "lectures.update": "ALL", "lectures.delete": "ALL",
    "attendance.session.manage": "ALL", "attendance.scan": "ALL", "attendance.view": "ALL",
    "attendance.edit": "ALL", "attendance.export": "ALL", "attendance.import": "ALL",
    "announcements.read": "ALL", "announcements.create": "ALL", "announcements.update": "ALL",
    "announcements.delete": "ALL", "reports.view": "ALL", "audit.view": "ALL",
  },
  INSTRUCTOR: {
    "lectures.read": "ASSIGNED", "lectures.create": "ASSIGNED", "lectures.update": "ASSIGNED", "lectures.delete": "ASSIGNED",
    "attendance.session.manage": "ASSIGNED", "attendance.scan": "ASSIGNED", "attendance.view": "ASSIGNED",
    "attendance.edit": "ASSIGNED", "attendance.export": "ASSIGNED", "attendance.import": "ASSIGNED",
    "announcements.read": "ALL", "announcements.create": "ASSIGNED", "announcements.update": "OWN", "announcements.delete": "OWN",
    "reports.view": "ASSIGNED",
  },
  STUDENT_ADMIN: {
    "lectures.read": "STAGE", "lectures.create": "STAGE", "lectures.update": "OWN", "lectures.delete": "OWN",
    "announcements.read": "ALL", "announcements.create": "STAGE", "announcements.update": "OWN", "announcements.delete": "OWN",
    "qr.own.view": "OWN",
  },
  STUDENT: {
    "lectures.read": "STAGE", "attendance.view": "OWN", "announcements.read": "ALL", "qr.own.view": "OWN",
  },
};

// حد الغياب المئوي الافتراضي (تنبيه الحرمان)
export const ABSENCE_LIMIT_PCT = 25;
// المنطقة الزمنية للتطبيق
export const APP_TIMEZONE = process.env.APP_TIMEZONE || "Asia/Baghdad";
// حد رفع الملفات
export const MAX_FILE_SIZE = 25 * 1024 * 1024; // 25MB
export const ALLOWED_UPLOAD_MIME = [
  "application/pdf",
  "application/vnd.ms-powerpoint",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/gif",
];
