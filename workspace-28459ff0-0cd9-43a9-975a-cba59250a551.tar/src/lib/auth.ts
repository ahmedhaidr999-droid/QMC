// المصادقة — جلسة JWT في كوكي HttpOnly (jose + bcryptjs)
import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";

const SESSION_COOKIE = "college_session";
const SESSION_DAYS = 7;

function getSecret() {
  return new TextEncoder().encode(process.env.AUTH_SECRET || "dev-secret-change-me");
}

export type AuthUser = {
  id: string;
  email: string;
  fullName: string;
  photoUrl: string | null;
  roleKey: string;
  roleId: string;
  roleName: string;
  universityId: string | null;
  mustChangePassword: boolean;
  isActive: boolean;
  stageId: string | null;
  branchId: string | null;
  academicYear: string | null;
  assignedSubjectIds: string[];
};

// إنشاء جلسة (توكن موقّع يحتوي معرّف المستخدم فقط — البيانات تُقرأ من قاعدة البيانات دائماً)
export async function createSession(userId: string) {
  const token = await new SignJWT({ sub: userId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_DAYS}d`)
    .sign(getSecret());
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_DAYS * 24 * 60 * 60,
    secure: process.env.NODE_ENV === "production",
  });
}

export async function destroySession() {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
}

// قراءة المستخدم الحالي من الكوكي + قاعدة البيانات (لا نثوق بالتوكن وحده)
export async function getSessionUser(): Promise<AuthUser | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, getSecret());
    const userId = payload.sub;
    if (!userId) return null;
    return loadUser(userId);
  } catch {
    return null;
  }
}

export async function loadUser(userId: string): Promise<AuthUser | null> {
  const user = await db.user.findUnique({
    where: { id: userId },
    include: {
      role: true,
      studentProfile: true,
      teaching: { select: { subjectId: true } },
    },
  });
  if (!user) return null;
  return {
    id: user.id,
    email: user.email,
    fullName: user.fullName,
    photoUrl: user.photoUrl,
    roleKey: user.role.key,
    roleId: user.role.id,
    roleName: user.role.nameAr,
    universityId: user.universityId,
    mustChangePassword: user.mustChangePassword,
    isActive: user.isActive,
    stageId: user.studentProfile?.stageId ?? null,
    branchId: user.studentProfile?.branchId ?? null,
    academicYear: user.studentProfile?.academicYear ?? null,
    assignedSubjectIds: user.teaching.map((t) => t.subjectId),
  };
}

// تجزئة كلمة المرور والتحقق منها
export async function hashPassword(plain: string) {
  return bcrypt.hash(plain, 12);
}
export async function verifyPassword(plain: string, hash: string) {
  return bcrypt.compare(plain, hash);
}
