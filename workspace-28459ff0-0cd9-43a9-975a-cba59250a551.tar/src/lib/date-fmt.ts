// تنسيق التواريخ بمنطقة التطبيق (آسيا/بغداد) — التخزين UTC والعرض محلي
import { APP_TIMEZONE } from "@/lib/constants";

const dateFmt = new Intl.DateTimeFormat("ar-IQ-u-nu-latn", {
  timeZone: APP_TIMEZONE,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});
const timeFmt = new Intl.DateTimeFormat("ar-IQ-u-nu-latn", {
  timeZone: APP_TIMEZONE,
  hour: "2-digit",
  minute: "2-digit",
  hour12: true,
});
const weekFmt = new Intl.DateTimeFormat("ar", { timeZone: APP_TIMEZONE, weekday: "long" });

export function fmtDate(d: Date | string): string {
  return dateFmt.format(new Date(d));
}
export function fmtShort(d: Date | string): string {
  // dd/MM للرؤوس المختصرة في المصفوفة
  const parts = dateFmt.formatToParts(new Date(d));
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  return `${get("day")}/${get("month")}`;
}
export function fmtTime(d: Date | string): string {
  return timeFmt.format(new Date(d));
}
export function fmtWeekday(d: Date | string): string {
  return weekFmt.format(new Date(d));
}
export function fmtDateTime(d: Date | string): string {
  return `${fmtDate(d)} ${fmtTime(d)}`;
}
