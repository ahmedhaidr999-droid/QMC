// أدوات مشتركة لمسارات API — أخطاء موحّدة وحد للطلبات وسجل التدقيق
import { ZodError } from "zod";
import { getSessionUser, type AuthUser } from "@/lib/auth";
import { can, type Resource } from "@/lib/rbac";
import { db } from "@/lib/db";

// خطأ HTTP مع رسالة عربية
export class HttpError extends Error {
  status: number;
  code?: string;
  constructor(status: number, message: string, code?: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

// غلاف موحّد لمعالجات المسارات: يلتقط الأخطاء ويعيد JSON عربي
export async function handle(fn: () => Promise<Response>): Promise<Response> {
  try {
    return await fn();
  } catch (err) {
    if (err instanceof HttpError) {
      return Response.json({ error: err.message, code: err.code }, { status: err.status });
    }
    if (err instanceof ZodError) {
      const first = err.issues[0];
      return Response.json(
        { error: `بيانات غير صالحة: ${first?.message ?? ""}`, code: "VALIDATION" },
        { status: 400 }
      );
    }
    console.error("[API ERROR]", err);
    return Response.json({ error: "حدث خطأ غير متوقع في الخادم", code: "INTERNAL" }, { status: 500 });
  }
}

// يتطلب تسجيل دخول فقط
export async function requireAuth(): Promise<AuthUser> {
  const user = await getSessionUser();
  if (!user) throw new HttpError(401, "غير مسجّل الدخول");
  if (!user.isActive) throw new HttpError(403, "الحساب معطّل");
  // إجبار تغيير كلمة المرور عند أول دخول — يُسمح فقط بمسارات المصادقة
  if (user.mustChangePassword) throw new HttpError(403, "يجب تغيير كلمة المرور أولاً", "MUST_CHANGE_PASSWORD");
  return user;
}

// يتطلب صلاحية على مورد معيّن — الحماية الحقيقية هنا في السيرفر
export async function requirePermission(key: string, res: Resource = {}): Promise<AuthUser> {
  const user = await requireAuth();
  if (!(await can(user, key, res))) throw new HttpError(403, "ليست لديك صلاحية");
  return user;
}

// عنوان IP للعميل
export function getClientIp(req: Request): string {
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0].trim();
  return req.headers.get("x-real-ip") ?? "unknown";
}

// ===== حد الطلبات (Rate Limiting) في الذاكرة =====
const buckets = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(key: string, opts: { max: number; windowSec: number }): void {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || now > bucket.resetAt) {
    buckets.set(key, { count: 1, resetAt: now + opts.windowSec * 1000 });
    return;
  }
  bucket.count += 1;
  if (bucket.count > opts.max) {
    const wait = Math.ceil((bucket.resetAt - now) / 1000);
    throw new HttpError(429, `عدد كبير من المحاولات، انتظر ${wait} ثانية`, "RATE_LIMITED");
  }
}

// كتابة سجل تدقيق لكل تعديل حساس
export async function writeAudit(params: {
  actorId: string;
  action: string;
  entity: string;
  entityId?: string;
  before?: unknown;
  after?: unknown;
  reason?: string;
  ip?: string;
}) {
  await db.auditLog.create({
    data: {
      actorId: params.actorId,
      action: params.action,
      entity: params.entity,
      entityId: params.entityId,
      before: params.before === undefined ? null : JSON.stringify(safeJson(params.before)),
      after: params.after === undefined ? null : JSON.stringify(safeJson(params.after)),
      reason: params.reason,
      ip: params.ip,
    },
  });
}

function safeJson(v: unknown): unknown {
  try {
    JSON.stringify(v);
    return v;
  } catch {
    return String(v);
  }
}
