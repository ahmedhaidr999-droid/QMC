// توكن QR المتغيّر للطالب (خوارزمية مشابهة لـ TOTP)
// window = floor(unixSeconds / 30) ، mac = HMAC_SHA256(qrSecret, studentId.window) مقتطع
import { createHmac, timingSafeEqual, randomBytes } from "crypto";

const STEP = 30; // ثانية

const currentWindow = (t = Date.now()) => Math.floor(t / 1000 / STEP);

function sign(secret: string, studentId: string, w: number) {
  return createHmac("sha256", secret).update(`${studentId}.${w}`).digest("base64url").slice(0, 22);
}

// توليد سر QR جديد للطالب (32 بايت عشوائي)
export function generateQrSecret() {
  return randomBytes(32).toString("base64url");
}

// بناء المحتوى المعروض داخل QR تطبيق الطالب
export function makeStudentToken(studentId: string, secret: string) {
  const w = currentWindow();
  return `QR1:${studentId}.${w}.${sign(secret, studentId, w)}`;
}

export type ParsedToken = { studentId: string; w: number; mac: string };

export function parseToken(raw: string): ParsedToken | null {
  const parts = raw.split(".");
  if (parts.length !== 3) return null;
  const [studentId, w, mac] = parts;
  if (!studentId || !w || !mac || Number.isNaN(Number(w))) return null;
  return { studentId, w: Number(w), mac };
}

// التحقق: نقبل النافذة الحالية ± 1 فقط (تسامح مع فرق الساعة) بمقارنة ثابتة الزمن
export function isValidMac(secret: string, studentId: string, w: number, mac: string) {
  if (Math.abs(currentWindow() - w) > 1) return false;
  const expected = Buffer.from(sign(secret, studentId, w));
  let given: Buffer;
  try {
    given = Buffer.from(mac);
  } catch {
    return false;
  }
  return expected.length === given.length && timingSafeEqual(expected, given);
}

// الثواني المتبقية قبل تجدد QR (للعدّاد التنازلي في الواجهة)
export function secondsUntilNextWindow() {
  return STEP - (Math.floor(Date.now() / 1000) % STEP);
}
