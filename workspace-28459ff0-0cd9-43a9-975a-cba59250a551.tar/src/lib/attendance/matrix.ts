// بناء مصفوفة الحضور (الصفوف = الطلاب، الأعمدة = الجلسات)
import type { AttendanceStatus } from "@/lib/constants";

export type MatrixStudent = { id: string; fullName: string; universityId?: string | null };
export type MatrixSession = { id: string; date: string | Date };
export type MatrixRecord = { studentId: string; sessionId: string; status: AttendanceStatus };

export type MatrixRow = {
  no: number;
  id: string;
  name: string;
  universityId?: string | null;
  cells: AttendanceStatus[];
  cellSymbols: string[];
  present: number;
  absent: number;
  excused: number;
  late: number;
  attendancePct: number;
  atRisk: boolean;
};

const SYMBOL: Record<AttendanceStatus, string> = {
  PRESENT: "✓",
  ABSENT: "غ",
  LATE: "ت",
  EXCUSED: "م",
};

export function buildMatrix(
  students: MatrixStudent[],
  sessions: MatrixSession[],
  records: MatrixRecord[],
  absenceLimitPct = 25
): MatrixRow[] {
  const index = new Map(records.map((r) => [`${r.studentId}:${r.sessionId}`, r.status]));
  return students.map((s, i) => {
    const cells = sessions.map((ss) => index.get(`${s.id}:${ss.id}`) ?? "ABSENT");
    const present = cells.filter((x) => x === "PRESENT" || x === "LATE").length;
    const late = cells.filter((x) => x === "LATE").length;
    const excused = cells.filter((x) => x === "EXCUSED").length;
    const absent = cells.filter((x) => x === "ABSENT").length;
    // المجاز لا يُحتسب غياباً
    const counted = Math.max(cells.length - excused, 1);
    const attendancePct = cells.length === 0 ? 100 : Math.round((present / counted) * 100);
    return {
      no: i + 1,
      id: s.id,
      name: s.fullName,
      universityId: s.universityId ?? null,
      cells,
      cellSymbols: cells.map((x) => SYMBOL[x]),
      present,
      absent,
      excused,
      late,
      attendancePct,
      atRisk: (absent / counted) * 100 > absenceLimitPct,
    };
  });
}
