// نظام الصلاحيات الديناميكي (RBAC) — كل التحقق في السيرفر
import { db } from "@/lib/db";
import type { AuthUser } from "@/lib/auth";
import type { Scope } from "@/lib/constants";

export type { Scope } from "@/lib/constants";

// المورد الذي نتحقق منه (املأ فقط ما يلزم)
export type Resource = {
  ownerId?: string;
  subjectId?: string;
  branchId?: string;
  stageId?: string;
};

// كاش في الذاكرة لمنح كل دور (يُبطل عند تحديث الصلاحيات)
const grantsCache = new Map<string, { data: Record<string, Scope>; at: number }>();
const GRANTS_TTL = 30_000;

export function invalidateRbacCache() {
  grantsCache.clear();
}

async function loadGrants(roleId: string): Promise<Record<string, Scope>> {
  const hit = grantsCache.get(roleId);
  if (hit && Date.now() - hit.at < GRANTS_TTL) return hit.data;
  const rows = await db.rolePermission.findMany({
    where: { roleId },
    include: { permission: true },
  });
  const data = Object.fromEntries(rows.map((r) => [r.permission.key, r.scope as Scope]));
  grantsCache.set(roleId, { data, at: Date.now() });
  return data;
}

// نطاق صلاحية المستخدم (مع تجاوز استثنائي على مستوى المستخدم إن وجد)
export async function getScope(user: AuthUser, key: string): Promise<Scope> {
  const [grants, override] = await Promise.all([
    loadGrants(user.roleId),
    db.userPermissionOverride.findFirst({ where: { userId: user.id, permission: { key } } }),
  ]);
  return (override?.scope as Scope) ?? grants[key] ?? "NONE";
}

// التحقق النهائي: هل يملك المستخدم الصلاحية على هذا المورد؟
export async function can(user: AuthUser, key: string, res: Resource = {}): Promise<boolean> {
  const scope = await getScope(user, key);
  switch (scope) {
    case "ALL": return true;
    case "NONE": return false;
    case "OWN": return !!res.ownerId && res.ownerId === user.id;
    case "ASSIGNED": return !!res.subjectId && user.assignedSubjectIds.includes(res.subjectId);
    case "BRANCH": return !!res.branchId && res.branchId === user.branchId;
    case "STAGE": return !!res.stageId && res.stageId === user.stageId;
  }
}

// هل يملك الصلاحية بأي نطاق؟ (لعرض عنصر في القائمة)
export async function hasAny(user: AuthUser, key: string): Promise<boolean> {
  return (await getScope(user, key)) !== "NONE";
}

// فلتر Prisma عند جلب المواد (يمنع تسريب بيانات خارج النطاق)
export async function subjectWhere(user: AuthUser, key: string) {
  const scope = await getScope(user, key);
  switch (scope) {
    case "ALL": return {};
    case "ASSIGNED": return { id: { in: user.assignedSubjectIds } };
    case "BRANCH": return { branchId: user.branchId ?? "__none__" };
    case "STAGE": return { branch: { stageId: user.stageId ?? "__none__" } };
    default: return { id: "__none__" };
  }
}

// فلتر Prisma عند جلب جلسات الحضور (مشتق من نطاق المواد)
export async function sessionWhere(user: AuthUser, key: string) {
  const scope = await getScope(user, key);
  switch (scope) {
    case "ALL": return {};
    case "ASSIGNED": return { subjectId: { in: user.assignedSubjectIds } };
    case "BRANCH": return { subject: { branchId: user.branchId ?? "__none__" } };
    case "STAGE": return { subject: { branch: { stageId: user.stageId ?? "__none__" } } };
    default: return { id: "__none__" };
  }
}
