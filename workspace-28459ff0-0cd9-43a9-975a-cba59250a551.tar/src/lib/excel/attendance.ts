// تصدير واستيراد الحضور بصيغة Excel (exceljs) — ملف RTL بألوان الحالات
import ExcelJS from "exceljs";
import { buildMatrix, type MatrixRecord, type MatrixSession, type MatrixStudent } from "@/lib/attendance/matrix";
import { fmtShort } from "@/lib/date-fmt";

// ألوان التعبئة لكل حالة
const FILLS: Record<string, string> = {
  PRESENT: "FFDCFCE7", // أخضر فاتح
  ABSENT: "FFFEE2E2", // أحمر فاتح
  LATE: "FFFFEDD5", // برتقالي فاتح
  EXCUSED: "FFE0F2FE", // أزرق فاتح
};

export type ExportInput = {
  subjectName: string;
  students: MatrixStudent[];
  sessions: MatrixSession[];
  records: MatrixRecord[];
};

// توليد ملف xlsx لمصفوفة الحضور
export async function exportAttendanceXlsx({ subjectName, students, sessions, records }: ExportInput): Promise<Buffer> {
  const rows = buildMatrix(students, sessions, records);
  const wb = new ExcelJS.Workbook();
  wb.creator = "نظام إدارة الكلية";
  const ws = wb.addWorksheet("الحضور", {
    views: [{ rightToLeft: true, state: "frozen", xSplit: 2, ySplit: 2 }],
  });

  // صف العنوان
  ws.mergeCells(1, 1, 1, 3 + sessions.length);
  const titleCell = ws.getCell(1, 1);
  titleCell.value = `سجل الحضور — ${subjectName}`;
  titleCell.font = { bold: true, size: 14, color: { argb: "FF166534" } };
  titleCell.alignment = { horizontal: "center", vertical: "middle" };
  ws.getRow(1).height = 24;

  // صف الرؤوس
  const headerRow = ws.getRow(2);
  headerRow.values = [
    "#",
    "اسم الطالب",
    "الرقم الجامعي",
    ...sessions.map((s) => fmtShort(s.date)),
    "حاضر",
    "غائب",
    "النسبة %",
  ];
  headerRow.eachCell((c) => {
    c.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF16A34A" } };
    c.font = { color: { argb: "FFFFFFFF" }, bold: true };
    c.alignment = { horizontal: "center", vertical: "middle" };
  });
  headerRow.height = 20;

  ws.columns = [
    { width: 5 },
    { width: 30 },
    { width: 14 },
    ...sessions.map(() => ({ width: 9 })),
    { width: 8 },
    { width: 8 },
    { width: 10 },
  ];

  // صفوف الطلاب
  rows.forEach((r, i) => {
    const row = ws.getRow(3 + i);
    row.values = [
      r.no,
      r.name,
      r.universityId ?? "",
      ...r.cellSymbols, // ✓ غ ت م
      r.present,
      r.absent,
      r.attendancePct,
    ];
    // تلوين خلايا الحالات
    r.cells.forEach((st, j) => {
      const cell = row.getCell(4 + j);
      const argb = FILLS[st] ?? "FFFFFFFF";
      cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb } };
      cell.alignment = { horizontal: "center" };
      cell.font = { bold: st === "ABSENT" };
    });
    // تحذير الحرمان
    if (r.atRisk) {
      const nameCell = row.getCell(2);
      nameCell.font = { bold: true, color: { argb: "FFDC2626" } };
      row.getCell(3 + r.cells.length + 2).font = { bold: true, color: { argb: "FFDC2626" } };
    }
    row.getCell(1).alignment = { horizontal: "center" };
  });

  // صف إحصائي نهائي: نسبة الحضور لكل يوم
  const statRow = ws.getRow(3 + rows.length + 1);
  statRow.getCell(2).value = "نسبة الحضور اليوم";
  statRow.getCell(2).font = { bold: true };
  sessions.forEach((_, j) => {
    const colRecords = records.filter((r) => r.sessionId === sessions[j].id);
    const present = colRecords.filter((r) => r.status === "PRESENT" || r.status === "LATE").length;
    const pct = colRecords.length ? Math.round((present / colRecords.length) * 100) : 0;
    const cell = statRow.getCell(4 + j);
    cell.value = pct;
    cell.alignment = { horizontal: "center" };
    cell.font = { bold: true };
  });
  statRow.getCell(2).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE0F2FE" } };

  const out = await wb.xlsx.writeBuffer();
  return Buffer.from(out);
}

// ===== الاستيراد: تحليل الملف وقراءة الرموز =====
export type ImportRow = { universityId: string; name: string; cells: (string | null)[] };

export async function parseAttendanceImport(buffer: Buffer): Promise<{
  sessions: string[]; // تواريخ الرؤوس كما وردت
  rows: ImportRow[];
}> {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buffer as unknown as ArrayBuffer);
  const ws = wb.worksheets[0];
  if (!ws) throw new Error("ملف غير صالح");

  // الرؤوس من الصف الثاني (الصف الأول عنوان مدمج)
  const header = ws.getRow(2).values as unknown[];
  const clean = (header as (string | number | null)[])
    .map((v, i) => ({ v: v == null ? "" : String(v).trim(), i }))
    .filter((x) => x.v !== "" && x.i >= 1);

  // نحدد الأعمدة: أول عمودين/ثلاثة معلومات الطالب ثم أعمدة التواريخ ثم الإحصاءات
  const dateCols: string[] = [];
  let nameCol = -1;
  let uidCol = -1;
  for (const { v, i } of clean) {
    if (v === "اسم الطالب") nameCol = i;
    else if (v === "الرقم الجامعي") uidCol = i;
    else if (/^\d{1,2}\/\d{1,2}$/.test(v)) dateCols.push(v);
  }
  if (nameCol === -1) throw new Error("لم يتم العثور على عمود «اسم الطالب»");

  const rows: ImportRow[] = [];
  ws.eachRow((row, rowNo) => {
    if (rowNo <= 2) return;
    const name = String(row.getCell(nameCol).value ?? "").trim();
    if (!name || name === "نسبة الحضور اليوم") return;
    const universityId = uidCol > 0 ? String(row.getCell(uidCol).value ?? "").trim() : "";
    const cells: (string | null)[] = dateCols.map(() => null);
    // نقرأ قيم الأعمدة بالترتيب حسب الفهارس الأصلية لأعمدة التواريخ
    const dateIdxs = clean.filter((c) => /^\d{1,2}\/\d{1,2}$/.test(c.v)).map((c) => c.i);
    dateIdxs.forEach((colIdx, j) => {
      const raw = row.getCell(colIdx).value;
      cells[j] = raw == null ? null : String(raw).trim();
    });
    rows.push({ universityId, name, cells });
  });

  return { sessions: dateCols, rows };
}
