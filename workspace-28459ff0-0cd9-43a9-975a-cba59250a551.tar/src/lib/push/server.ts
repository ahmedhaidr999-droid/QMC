// إرسال إشعارات Web Push + إشعارات داخل التطبيق
import webpush from "web-push";
import { db } from "@/lib/db";
import type { Announcement } from "@prisma/client";

const publicKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY || "";
const privateKey = process.env.VAPID_PRIVATE_KEY || "";
const subject = process.env.VAPID_SUBJECT || "mailto:admin@college.edu";

let configured = false;
function ensureConfig() {
  if (!configured && publicKey && privateKey) {
    webpush.setVapidDetails(subject, publicKey, privateKey);
    configured = true;
  }
  return !!(publicKey && privateKey);
}

// تحديد المستلمين حسب الجمهور
export async function resolveAudience(a: {
  audienceType: string;
  stageId?: string | null;
  branchId?: string | null;
  subjectId?: string | null;
}): Promise<string[]> {
  const where =
    a.audienceType === "ALL"
      ? {}
      : a.audienceType === "STAGE"
        ? { studentProfile: { stageId: a.stageId! } }
        : a.audienceType === "BRANCH"
          ? { studentProfile: { branchId: a.branchId! } }
          : { studentProfile: { branch: { subjects: { some: { id: a.subjectId! } } } } };
  // نضيف التدريسيين أيضاً لتبليغات المادة
  if (a.audienceType === "SUBJECT") {
    const [students, instructors] = await Promise.all([
      db.user.findMany({ where: { isActive: true, ...where }, select: { id: true } }),
      db.subjectInstructor.findMany({ where: { subjectId: a.subjectId! }, select: { userId: true } }),
    ]);
    return [...new Set([...students.map((u) => u.id), ...instructors.map((i) => i.userId)])];
  }
  const users = await db.user.findMany({ where: { isActive: true, ...where }, select: { id: true } });
  return users.map((u) => u.id);
}

// إنشاء إشعارات داخل التطبيق (احتياطي دائم)
export async function createInAppNotifications(userIds: string[], payload: { title: string; body: string; url: string }) {
  if (userIds.length === 0) return;
  await db.notification.createMany({
    data: userIds.map((userId) => ({
      userId,
      title: payload.title,
      body: payload.body,
      url: payload.url,
    })),
  });
}

// إرسال Web Push لقائمة مستخدمين (فشل الإرسال لا يوقف العملية)
export async function sendPushToUsers(userIds: string[], payload: { title: string; body: string; url: string; tag?: string }) {
  if (userIds.length === 0) return;
  if (!ensureConfig()) return; // المفاتيح غير مضبوطة → نكتفي بالإشعارات الداخلية
  const subs = await db.pushSubscription.findMany({ where: { userId: { in: userIds } } });
  const CONCURRENCY = 20;
  for (let i = 0; i < subs.length; i += CONCURRENCY) {
    const batch = subs.slice(i, i + CONCURRENCY);
    await Promise.allSettled(
      batch.map(async (s) => {
        try {
          await webpush.sendNotification(
            { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
            JSON.stringify({ ...payload, tag: payload.tag ?? "college" }),
            { TTL: 60 * 60 * 24 }
          );
        } catch (e: unknown) {
          const status = (e as { statusCode?: number }).statusCode;
          // اشتراك منتهٍ → احذفه
          if (status === 404 || status === 410) {
            await db.pushSubscription.delete({ where: { id: s.id } }).catch(() => {});
          }
        }
      })
    );
  }
}

// بث تبليغ كامل: إشعارات داخلية + Push
export async function broadcastAnnouncement(a: Announcement, url = "#/announcements") {
  const userIds = await resolveAudience(a);
  const payload = { title: `📢 ${a.title}`, body: a.body.slice(0, 120), url, tag: `ann-${a.id}` };
  await createInAppNotifications(userIds, payload);
  await sendPushToUsers(userIds, payload).catch(() => {});
  return userIds.length;
}
