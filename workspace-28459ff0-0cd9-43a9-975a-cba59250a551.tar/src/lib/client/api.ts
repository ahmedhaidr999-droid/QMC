"use client";
// عميل API موحّد — كل الاستدعاءات تمر من هنا مع معالجة الأخطاء العربية
export class ApiError extends Error {
  status: number;
  code?: string;
  constructor(status: number, message: string, code?: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export async function api<T = unknown>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    ...init,
    headers: {
      ...(init?.body && !(init.body instanceof FormData) ? { "Content-Type": "application/json" } : {}),
      ...init?.headers,
    },
  });
  let data: unknown = null;
  try {
    data = await res.json();
  } catch {
    // ملف ثنائي أو فارغ
  }
  if (!res.ok) {
    const err = data as { error?: string; code?: string } | null;
    throw new ApiError(res.status, err?.error ?? "حدث خطأ في الاتصال", err?.code);
  }
  return data as T;
}

// ===== أنواع مشتركة =====
export type Scope = "NONE" | "OWN" | "ASSIGNED" | "BRANCH" | "STAGE" | "ALL";
export type AttendanceStatus = "PRESENT" | "ABSENT" | "LATE" | "EXCUSED";

export type AuthUserDTO = {
  id: string;
  email: string;
  fullName: string;
  photoUrl: string | null;
  roleKey: string;
  roleId: string;
  roleName: string;
  universityId: string | null;
  mustChangePassword: boolean;
  isActive: boolean;
  stageId: string | null;
  branchId: string | null;
  academicYear: string | null;
  assignedSubjectIds: string[];
};

export type MeResponse = { user: AuthUserDTO | null; scopes: Record<string, Scope>; unread: number };
