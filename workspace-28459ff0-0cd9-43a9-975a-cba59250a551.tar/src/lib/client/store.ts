"use client";
// متجر الحالة (Zustand) — الجلسة + النطاقات + الإشعارات + الموجّه
import { create } from "zustand";
import { api, type AuthUserDTO, type Scope, type MeResponse } from "./api";

type AppState = {
  user: AuthUserDTO | null;
  scopes: Record<string, Scope>;
  unread: number;
  loadingMe: boolean;
  // جلب الجلسة الحالية
  fetchMe: () => Promise<AuthUserDTO | null>;
  // تسجيل الدخول
  login: (email: string, password: string) => Promise<AuthUserDTO>;
  logout: () => Promise<void>;
  setUnread: (n: number) => void;
  hasScope: (key: string) => boolean;
};

export const useApp = create<AppState>((set, get) => ({
  user: null,
  scopes: {},
  unread: 0,
  loadingMe: true,

  fetchMe: async () => {
    try {
      const me = await api<MeResponse>("/api/auth/me");
      set({ user: me.user, scopes: me.scopes ?? {}, unread: me.unread ?? 0, loadingMe: false });
      return me.user;
    } catch {
      set({ user: null, scopes: {}, unread: 0, loadingMe: false });
      return null;
    }
  },

  login: async (email, password) => {
    const { user } = await api<{ user: AuthUserDTO }>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
    await get().fetchMe();
    return user;
  },

  logout: async () => {
    await api("/api/auth/logout", { method: "POST" }).catch(() => {});
    set({ user: null, scopes: {}, unread: 0 });
    if (typeof window !== "undefined") window.location.hash = "#/dashboard";
  },

  setUnread: (n) => set({ unread: n }),

  hasScope: (key) => (get().scopes[key] ?? "NONE") !== "NONE",
}));

// ===== الموجّه (Hash Router) =====
// التنقل عبر: #/dashboard ، #/stages/<id> ، #/subjects/<id> ...
export function navigate(path: string) {
  if (typeof window === "undefined") return;
  window.location.hash = path.startsWith("#") ? path : `#${path}`;
}

import { useEffect, useState } from "react";

export function useHashRoute() {
  const read = () => {
    const raw = window.location.hash.replace(/^#/, "");
    // فصل الاستعلام (?subject=...) عن المسار
    const [pathPart] = raw.split("?");
    const path = pathPart.startsWith("/") ? pathPart : `/${pathPart}`;
    return path;
  };
  const [path, setPath] = useState<string>(typeof window === "undefined" ? "/dashboard" : read());

  useEffect(() => {
    const onChange = () => {
      setPath(read());
      window.scrollTo({ top: 0 });
    };
    window.addEventListener("hashchange", onChange);
    if (!window.location.hash) window.location.hash = "#/dashboard";
    return () => window.removeEventListener("hashchange", onChange);
  }, []);

  const segments = path.split("/").filter(Boolean);
  return { path, segments };
}

// قراءة باراميترات الاستعلام من الـ hash (#/reports?subject=xyz)
export function hashQuery(): Record<string, string> {
  if (typeof window === "undefined") return {};
  const raw = window.location.hash.replace(/^#/, "");
  const q = raw.split("?")[1] ?? "";
  return Object.fromEntries(new URLSearchParams(q));
}
