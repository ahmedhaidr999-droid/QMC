# Task ID: 2-b — attendance-views-builder

## المهمة
واجهات الحضور والباركود — استبدال 5 stubs بتنفيذ كامل في
`src/components/app/views/attendance/` (SessionsView, ScannerView, ReportsView, MyQrView, MyAttendanceView)
— لم يُعدَّل أي ملف آخر إطلاقاً.

## ما نُفّذ

### 1) SessionsView (`#/attendance`)
- قائمة الجلسات من `GET /api/attendance/sessions` (مرتبة تنازلياً من الخادم) — بطاقة لكل جلسة: المادة +
  المرحلة/الفرع + `fmtDate`/`fmtTime` + القاعة (MapPin) + العدد المسجلين (Users) + التأخير بعد N دقيقة.
- شارة الحالة: مجدولة sky / مفتوحة emerald (مع نبض) / مغلقة muted.
- زر «إنشاء جلسة» لمن يملك `hasScope("attendance.session.manage")` → Dialog: اختيار المادة (Select من
  `GET /api/subjects`) + تاريخ date + startTime/endTime (type=time) + القاعة + lateAfterMin رقم —
  افتراضي تاريخ اليوم بتوقيت بغداد عبر `Intl en-CA`. تحقق قبل الإرسال (النهاية بعد البداية) + toast.
- أزرار لكل جلسة: «الماسح» → `navigate("/scan/{id}")`، «فتح الجلسة» (لغير OPEN) مع toast عدد الطلاب
  المسجلين من `res.count`، «إغلاق» (لـ OPEN فقط).
- فلترة بالمادة (Select) — مفتاح استعلام `["attendance-sessions", subjectFilter]` والإبطال بالبادئة.
- LoadingRows / EmptyState (مع زر إنشاء أول جلسة) / ErrorState مع onRetry.

### 2) ScannerView (`#/scan/{sessionId}`) — الأهم
- `GET /api/attendance/sessions/{id}` (session + records) — شريط علوي: المادة/التاريخ fmtDateTime/القاعة/
  العدد/شارة الحالة + بانر إرشادي للجلسات غير المفتوحة.
- **كاميرا الهاتف**: زر «بدء المسح بالكاميرا» → `getUserMedia({video:{facingMode:"environment"}})`،
  فيديو ملء العرض `aspect-video rounded-2xl overflow-hidden bg-black` مع إطار تصويب، وحلقة
  `requestAnimationFrame` ترسم كل إطار على canvas مخفي (مصغّر لحد 640px للسرعة) ثم `jsQR` بـ
  `inversionAttempts:"dontInvert"`.
- **Debounce 1.5s** عبر `lastScanAtRef`: لا إرسال لأي قراءة (نفس QR أو جديدة) قبل 1.5 ثانية من الأخيرة.
- **الأصوات (Web Audio API)**: نجاح = oscillator 880Hz لـ 150ms + `navigator.vibrate(80)`، مكرر = نغمة
  منخفضة 300Hz مزدوجة، خطأ = square 180Hz لـ 320ms — AudioContext كسول يُغلق عند إلغاء التثبيت.
- **بطاقة النتيجة** أسفل الكاميرا (framer-motion AnimatePresence): نجاح = اسم + رقم جامعي + شارة
  (حاضر emerald / متأخر amber)، مكرر = رمادية «مكرر — {الاسم}»، خطأ = حمراء برسالة السيرفر
  (SESSION_CLOSED/EXPIRED_OR_FORGED/...) — تظهر 3 ثوانٍ ثم تنكمش إلى قائمة «آخر الممسوحين».
- **حقل مخفي مركّز دائماً** لقارئ USB: input شفاف 1px مع `inputMode="none"` (يمنع كيبورد الهاتف)،
  Enter يرسل القيمة كـ scan ثم يُفرَّغ؛ إعادة التركيز onBlur مع حراسة أثناء فتح الحوارات (dialogOpenRef).
- **تسجيل يدوي**: Dialog بحث محلي في records بالاسم/الرقم الجامعي (الغائبون أولاً) → POST
  `{action:"manual", studentId}` → نفس معالجة النتيجة.
- **آخر الممسوحين**: قائمة محلية (≤20) تُطابق records المعاد جلبها بعد كل عملية ناجحة لاستخراج
  studentId/markedById؛ زر «تراجع» (Undo2) لكل عنصر يظهر فقط إن كان `markedById === user.id` أو
  `hasScope("attendance.edit")` → POST `{action:"undo", studentId}`.
- **إحصاءات حية**: حاضر/متأخر/غائب/مجاز من records.
- زر «إغلاق الجلسة» عند OPEN (AlertDialog تأكيد) + إبطال كاش قائمة الجلسات.
- فشل الكاميرا/عدم وجودها: رسالة لطيفة «الكاميرا غير متاحة — استخدم الإدخال اليدوي أو حقل القارئ» مع
  بقاء الحقل المخفي والتسجيل اليدوي يعملان + زر إعادة المحاولة.
- تنظيف كامل عند unmount: `stream.getTracks().forEach(t=>t.stop())` + cancelAnimationFrame + مسح المؤقتات.

### 3) ReportsView (`#/reports`)
- اختيار المادة من `GET /api/subjects` (الافتراضي: `?subject=` من window.location.search أو أول مادة).
- فلاتر: من-إلى (date ×2) + بحث اسم/رقم جامعي (useDeferredValue للـ debounce).
- `GET /api/reports/attendance` → جدول المصفوفة: رؤوس الجلسات `fmtShort`، خلية كل حالة ملونة بـ
  STATUS_COLORS + الرمز (✓ غ ت م)، أعمدة نهائية حاضر/غائب/النسبة% (bold ملونة)، دليل رموز أعلى الجدول.
- صفوف atRisk: خلفية حمراء خفيفة + أيقونة تحذير + تنبيه أعلى الصفحة «يوجد {n} طالباً معرّضاً للحرمان».
- تمرير أفقي مع **تثبيت أول عمودين** (الاسم sticky right-0 والرقم الجامعي sticky right-44 بعرضين ثابتين
  وخلفيات bg تتبع حالة atRisk).
- **تصدير** (hasScope attendance.export): `window.open("/api/export/attendance?subjectId=...")`.
- **استيراد** (hasScope attendance.import): Dialog بملف xlsx + سبب إلزامي (≥3 أحرف) → «معاينة» (multipart
  mode=preview) → جدول الفروقات (الطالب/الجلسة/كان→صار بشارات ملونة) + قائمة أخطاء → «تطبيق التغييرات»
  بAlertDialog تأكيد → mode=apply → toast بالعدد المطبق + إبطال كاش التقرير.

### 4) MyQrView (`#/my-qr`)
- `GET /api/my/qr` → `QRCode.toDataURL(token, {width:280, margin:1, color:{dark:"#0f172a"}})` + نسخة
  420 للتكبير؛ opacity transition أثناء إعادة الجلب.
- **عدّاد دائري SVG** (حلقة progress + رقم ثوانٍ) مشتق من `dataUpdatedAt` (ساعة setInterval) — عند
  الصفر `refetch()` تلقائياً فيتجدد QR (بلا setState داخل effect — متوافق مع قاعدة
  react-hooks/set-state-in-effect).
- بطاقة الطالب (الاسم + الرقم الجامعي) + زر «تكبير» → Dialog بخلفية بيضاء وQR 420 ونص «أظهر هذا الكود
  للمسؤول عند المدخل» + تلميح رفع السطوع يدوياً.
- **البطاقة المطبوعة**: canvas بباركود Code128 من staticCode (`JsBarcode` height 60, fontSize 16,
  displayValue) + QR ثابت مطبوع + زر «طباعة البطاقة» يفتح نافذة جديدة ببطاقة أنيقة RTL (رأس أخضر باسم
  النظام + الاسم + الرقم + الباركود + QR + تنبيه عدم المشاركة) ثم `print()`.
- تنويه: «الكود يتجدد تلقائياً كل 30 ثانية لحمايتك من مشاركته».

### 5) MyAttendanceView (`#/my-attendance`)
- بطاقة لكل مادة: الاسم + «معرّض للحرمان» حمراء عند atRisk + المرحلة/الفرع + نسبة كبيرة ملونة
  (أخضر ≥75 / برتقالي 50-75 / أحمر <50) + شريط تقدم بنفس اللون + 4 رقاقات إحصاء (حاضر/متأخر/غائب/مجاز)
  + جدول الجلسات (max-h-72 تمرير عمودي): التاريخ + الوقت + StatusBadge + الملاحظة.
- EmptyState «لا يوجد سجل حضور بعد» عند الفراغ.

## الاختبارات (فعلية)
- curl بعد الدخول بكوكي inst1/student2: sessions/session-detail/subjects/reports/export/import-preview
  (multipart بملف xlsx حقيقي) = 200 — وscan: نجاح (`ok:true duplicate:false`) ثم مكرر ثم undo = كلها تعمل.
- متصفح حقيقي (agent-browser): دخول inst1 → جلسات (5 بطاقات + فلترة + حوار إنشاء) → الماسح (حقل USB +
  بانر الحالة + حوار يدوي قائمة مصنفة غائبين أولاً) → تسجيل يدوي لعلي (بطاقة + إحصاءات 2/0/2/1 + آخر
  الممسوحين) → تراجع (1/0/3/1) → تقارير (مصفوفة كاملة + تنبيه حرمان + حوار استيراد) — دخول student2 →
  باركودي (QR + عداد 13s + تكبير + البطاقة canvas وimg = حقيقيان) → حضوري (بطاقة مادة 50% + جدول).
  لا أخطاء console في أي صفحة، و`GET /` = 200، وeslint لمجلد attendance = صفر أخطاء.

## جودة
- "use client" + TypeScript صارم بلا any ولا TODO — عربية كاملة — تجاوب 360px+ — ui-bits المشتركة +
  shadcn — toast لكل عملية — أهداف لمس ≥44px — لا ألوان indigo/بنفسجي.

## الحسابات المرجعية
- inst1@college.edu/Inst@123 — student2@college.edu/Student@123 (الطالب student1 مسؤول ولا يملك
  attendance.view OWN افتراضياً)
