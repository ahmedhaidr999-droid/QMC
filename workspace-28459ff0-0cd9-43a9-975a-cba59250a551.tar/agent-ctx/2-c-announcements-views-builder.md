# Task ID: 2-c — announcements-views-builder

## المهمة
واجهة التبليغات `#/announcements` — استبدال stub بتنفيذ كامل في:
`src/components/app/views/announcements/AnnouncementsView.tsx` (بدون props، `export function AnnouncementsView()`)
— لم يُعدَّل أي ملف آخر.

## ما نُفّذ
- **قائمة التبليغات** (`GET /api/announcements`، مفتاح كاش `["announcements"]`): بطاقة `rounded-2xl shadow-sm py-0` لكل تبليغ تحوي:
  - العنوان (bold) مع 📌 إذا pinned + `PriorityBadge` (عادية/مهمة/عاجلة) + شارة «جديد» زرقاء فاتحة (sky) عند `!isRead` + حد/خلفية sky خفيفة للبطاقة غير المقروءة.
  - النص `line-clamp-3` قابل للتوسيع بالنقر (stopPropagation + تبديل محلي عبر `expandedIds`).
  - سطر معلومات: الناشر (createdByName) + `fmtDateTime(publishedAt)` + جمهور الاستهداف كنص عربي (الكل / مرحلة: X / فرع: X / مادة: X).
- **عرض كامل**: نقر البطاقة (كليك أو Enter/Space — role=button) يفتح Dialog بالنص الكامل + الأولوية + تاريخ الانتهاء إن وجد، وعند الفتح يُستدعى `POST /api/announcements/{id}/read` مع تحسين `isRead` محلياً عبر `qc.setQueryData`.
- **فلاتر**: أزرار سريعة (الكل/غير المقروءة/المثبّتة مع الأعداد) + Select للأولوية (كل الأولويات/عادية/مهمة/عاجلة) + EmptyState مخصص عند فراغ نتيجة الفلاتر مع زر «إزالة التصفية».
- **إنشاء** (لمن يملك `hasScope("announcements.create")`): زر «تبليغ جديد» → Dialog بنموذج: العنوان (إلزامي)، النص Textarea (إلزامي)، الأولوية RadioGroup (NORMAL/IMPORTANT/URGENT بالتسميات العربية)، تثبيت Switch، الجمهور RadioGroup (الكل/مرحلة/فرع تدريسي/مادة) مع قوائم متتالية: مرحلة (`GET /api/stages`) ← فرع (`GET /api/branches?stageId=`) ← مادة (`GET /api/subjects?branchId=`) — كل قائمة تُجلب عند الحاجة فقط (enabled) وتُصفَّر التبعيات عند تغيير السابقة. نجاح: `toast.success("تم النشر لـ {n} مستخدماً")` من `recipients` + إبطال كاش + إغلاق. خطأ: `toast.error(e.message)` (مثل «ليست لديك صلاحية على هذا الجمهور»). ملاحظة صغيرة داخل النموذج عن حدود جمهور التدريسي/الطالب المسؤول.
- **تعديل/حذف**: DropdownMenu بنقاط ثلاث على البطاقة (stopPropagation) يظهر فقط لصاحب التبليغ (`createdById === user.id`) أو OWNER/DEAN ولمن يملك hasScope("announcements.update"/"announcements.delete"). التعديل يفتح نفس النموذج معبأ (PATCH: title/body/priority/pinned — الجمهور للقراءة فقط لأن الـ PATCH لا يغيّره)، الحذف بتأكيد AlertDialog.
- **حالات كاملة**: LoadingRows (تحميل)، EmptyState «لا توجد تبليغات بعد»، ErrorState مع onRetry.
- **نمط خالٍ من الأخطاء**: بُنية النموذج كمكوّن `AnnouncementForm` يُركَّب فقط عند فتح الـ Dialog (حالة ابتدائية من props بلا useEffect) لتجاوز قاعدة `react-hooks/set-state-in-effect` في ESLint الجديد.

## ملاحظات تقنية
- React Query: `useQuery`/`useMutation` + `qc.invalidateQueries({queryKey:["announcements"]})`، و`staleTime` دقيقة لقوائم الجمهور.
- استخدام ui-bits المشتركة (PageHeader, EmptyState, ErrorState, LoadingRows, PriorityBadge) و sonner للـ toasts.
- TypeScript صارم بلا `any`، لا TODO، عربية كاملة، تجاوب من 360px (أهداف لمس ≥44px على الهاتف: h-11 sm:h-9).
- تحقق `bunx eslint` و`tsc --noEmit`: صفر أخطاء/تحذيرات لهذا الملف. `GET /` = 200 وdev.log نظيف.
- اختبار API فعلي بـ curl (كوكي owner): إنشاء (recipients) → قراءة (ok) → PATCH → DELETE كلها تعمل بنفس أشكال الـ payloads المستخدمة في الواجهة، ورسالة 403 للتدريسي خارج نطاقه تُعرض كما هي.

## الحسابات المرجعية
- owner@college.edu/Owner@123 — dean/Dean@123 — inst1/Inst@123 — student1/StAdmin@123
