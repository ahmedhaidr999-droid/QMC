# سجل عمل — Task 2-a: academic-views-builder

## المهمة
استبدال stubs الهيكل الأكاديمي الثلاثة بتنفيذ كامل:
1. `src/components/app/views/academic/StagesView.tsx`
2. `src/components/app/views/academic/SubjectsView.tsx`
3. `src/components/app/views/academic/SubjectView.tsx`

## قراءات أولية
- worklog.md + docs/api-contract.md + ملفات البنية (ui-bits, api client, store, constants, date-fmt, page.tsx router)
- فحص فعلي بالـ curl لأشكال: /api/stages, /api/branches?stageId=, /api/subjects?branchId=, /api/subjects/{id}, /api/lectures?subjectId=, /api/attendance/sessions?subjectId=, /api/admin/users?role=INSTRUCTOR|STUDENT, /api/files

## ⚠️ إصلاحات اضطرارية خارج نطاق الملفات (hotfixes)
المهمة قالت «API موجودة وتعمل» لكن الفحص أظهر 3 أخطاء 500 تخالف عقد الـ API نفسه، وتكسر متطلبات صريحة في مهمتي (قائمة المحاضرات + صفحة المادة + تنزيل الملفات). الإصلاحات جراحية بلا تغيير أشكال الاستجابة:

| الملف | الخطأ | الإصلاح |
|---|---|---|
| `src/app/api/lectures/route.ts` | Prisma: علاقة `createdBy` غير معرفة على نموذج Lecture (include يفشل) | حذف الـ include + جلب المنشئين دفعة بـ `user.findMany` + خريطة `creatorMap` |
| `src/app/api/lectures/[id]/route.ts` | نفس خطأ العلاقة في loadLecture | حذف الـ include + جلب المنشئ في GET وتمريره لـ serialize |
| `src/app/api/subjects/[id]/route.ts` | `_count.select.students` غير موجود على Subject | حذف `students: true` (studentsCount يُحسب بسطر مستقل أصلاً) |
| `src/app/api/files/[id]/route.ts` | `findUnique({where:{url}})` على حقل غير فريد | `findFirst` بنفس الشرط |

## حزمة مضافة
- `remark-gfm` (لدعم جداول Markdown في عارض/معاينة المحاضرات)

## التنفيذ
### StagesView
- وضعان بنفس المكوّن (بدون hooks في الجذر): قائمة مراحل / صفحة مرحلة بفروعها
- بطاقات قابلة للنقر (زر شامل + صف أدوات إداري منفصل تحته — HTML سليم بلا تداخل تفاعلي)
- CRUD: مرحلة (اسم + رقم 1-10 Select) وفرع (اسم) مع تعديل/حذف + AlertDialog تأكيد + رسائل خطأ السيرفر تظهر بـ toast
- Breadcrumb قابل للنقر في الوضعين، Skeleton/Empty/Error لكل استعلام

### SubjectsView
- Breadcrumb رباعي + StatCards (مواد/طلاب الفرع)
- بطاقة مادة: code badge + الاسم + الفصل + أسماء التدريسيين + محاضرات/جلسات → `/subjects/{id}`
- DropdownMenu للإدارة: تعديل / إسناد التدريسيين / حذف
- نافذة الإسناد: جلب INSTRUCTORs (enabled عند فتحها فقط) + بحث + checkbox + PATCH `instructorIds`

### SubjectView
- رأس + 4 StatCards + Tabs ثلاثة
- **المحاضرات**: عارض Dialog max-w-3xl بـ ReactMarkdown+remarkGfm وتنسيق يدوي (h1-h3 bold، جداول بحدود ومقارنة thead، pre بخلفية muted وdir=ltr، inline code مميز، قوائم ps-6) — محرر (Textarea + تبويب معاينة حية) + رفع ملفات multipart داخل التعديل + Switch نشر — أزرار مقيدة بـ lectures.create/update/delete
- **الجلسات**: بطاقات موجزة + إنشاء جلسة (input date/time/time + قاعة + دقائق) لمن يملك attendance.session.manage + فتح الماسح (attendance.scan) → `/scan/{id}` + المصفوفة → `/reports?subject=`
- **الطلاب**: studentsCount + زر عرض الطلاب (users.manage) — Dialog بجلب STUDENTs وفلترة branchName + بحث محلي
- أنماط React: كل الحوارات تُركَّب شرطياً عند الفتح (حالة ابتدائية من props — صفر useEffect-sync) لتجاوز react-hooks/set-state-in-effect

## الاختبار
- curl: دورة كاملة (إنشاء مرحلة9/فرع/مادة/محاضرة برابط فارغ/ملف/جلسة → PATCH محاضرة → تنزيل 200 → حذف متسلسل مع التحقق من رسائل الحماية «لا يمكن حذف مرحلة تضم طلاباً» و«لا يمكن حذف مادة لديها جلسات حضور»)
- رفض صحيح: رفع ملف text/plain يعطي 400 «نوع الملف غير مدعوم» ويظهر بـ toast
- agent-browser (جلسة معزولة، دخول owner): تنقل كامل المراحل→فرع→مادة، التبويبات الثلاثة، عارض المحاضرة يعرض Markdown، إنشاء محاضرة بجداول/أكواد + معاينة، رفع PDF + ظهوره بحجمه + تنزيل 200، حذف بتأكيد، إنشاء جلسة تظهر «مجدولة» بمواعيد بغداد، قائمة طلاب الفرع (2 طالب) — صفر أخطاء console
- `bun run lint`: صفر أخطاء في ملفاتي (المتبقي: PwaBits.tsx لوكيل آخر) — `tsc --noEmit`: صفر أخطاء في ملفاتي
- GET / = 200 و dev.log نظيف — حُذفت كل بيانات الاختبار (جلسة/ملف/محاضرة) وأعيدت القاعدة لحالتها قبل الاختبار

## ملاحظات للوكلاء اللاحقين
- الـ endpoints الأكاديمية كلها تعمل الآن مطابقة للعقد
- `navigate("/reports?subject={id}")` يمرر المادة عبر hash — ReportsView (وكيل 2-b) يقرأ ?subject=
- أسماء مفاتيح الكاش: ["stages"]، ["branches", stageId]، ["branches","all"]، ["subjects", branchId]، ["subject", id]، ["lectures", id]، ["sessions", id]، ["admin-users", role]
